// يُشغَّل بعد cap sync: صلاحيات + كود الأذان الأصلي (Service/Receiver/Plugin) + أصوات الأذان + أيقونة الإشعار
import {readFile,writeFile,cp,mkdir,readdir} from 'node:fs/promises';import {existsSync} from 'node:fs';
const cfg=JSON.parse(await readFile('capacitor.config.json','utf8'));const PKG=cfg.appId;
const man='android/app/src/main/AndroidManifest.xml';let x=await readFile(man,'utf8');

/* 1) الصلاحيات */
for(const p of ['POST_NOTIFICATIONS','SCHEDULE_EXACT_ALARM','RECEIVE_BOOT_COMPLETED','VIBRATE','WAKE_LOCK','USE_FULL_SCREEN_INTENT','FOREGROUND_SERVICE','FOREGROUND_SERVICE_MEDIA_PLAYBACK']){
  if(!x.includes('android.permission.'+p+'"'))x=x.replace('<application','<uses-permission android:name="android.permission.'+p+'" />\n    <application');}

/* 2) النشاط الرئيسي يظهر فوق القفل ويُشعل الشاشة */
if(!x.includes('android:showWhenLocked'))x=x.replace(/<activity\b/,'<activity android:showWhenLocked="true" android:turnScreenOn="true"');

/* 3) المستقبِل + الخدمة */
if(!x.includes(PKG+'.AdhanService')){
  x=x.replace('</application>',
`    <receiver android:name="${PKG}.AdhanReceiver" android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
            </intent-filter>
        </receiver>
        <service android:name="${PKG}.AdhanService" android:exported="false" android:foregroundServiceType="mediaPlayback" />
    </application>`);}
await writeFile(man,x);

/* 4) ملفات جافا (يُستبدل __PKG__ بمعرّف التطبيق) */
const jdir='android/app/src/main/java/'+PKG.split('.').join('/');await mkdir(jdir,{recursive:true});
for(const f of await readdir('android-native/java')){
  if(!f.endsWith('.java'))continue;
  await writeFile(jdir+'/'+f,(await readFile('android-native/java/'+f,'utf8')).replaceAll('__PKG__',PKG));}

/* 5) أصوات الأذان وأيقونة الإشعار */
const raw='android/app/src/main/res/raw';await mkdir(raw,{recursive:true});
if(existsSync('android-res/raw'))for(const f of await readdir('android-res/raw'))if(/\.(mp3|ogg|wav)$/i.test(f))await cp('android-res/raw/'+f,raw+'/'+f.toLowerCase());
if(existsSync('android-res/layout')){await mkdir('android/app/src/main/res/layout',{recursive:true});await cp('android-res/layout','android/app/src/main/res/layout',{recursive:true});}
if(existsSync('android-res/drawable')){await mkdir('android/app/src/main/res/drawable',{recursive:true});await cp('android-res/drawable','android/app/src/main/res/drawable',{recursive:true});}
console.log('android patched ('+PKG+')');
