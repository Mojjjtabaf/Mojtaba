import {rm,mkdir,cp} from 'node:fs/promises';import {existsSync} from 'node:fs';
await rm('www',{recursive:true,force:true});await mkdir('www',{recursive:true});
for(const f of ['index.html','manifest.json','sw.js','css','js','data','icons','audio','fonts'])if(existsSync(f))await cp(f,'www/'+f,{recursive:true});
console.log('www ready');
