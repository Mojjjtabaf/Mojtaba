/* Service Worker: يخزّن هيكل التطبيق مسبقاً، ويخزّن الخطوط وواجهات القرآن/الحديث عند أول استخدام متصل */
const V='ikhlas-v33',SHELL=['./','css/adhan-screen.css','js/features/adhan-screen.js','js/features/custom-adhan.js','js/features/viewport.js','css/responsive.css','css/harmony.css','css/dev.css','js/features/dev.js','js/features/dev-boot.js','css/glass.css','css/polish.css','data/library-more.js','js/features/library2.js','js/assistant.js', 'index.html','css/dock.css','js/features/dock.js', 'manifest.json', 'icons/icon.svg', 'css/icons.css', 'css/style.css', 'js/icons.js','js/quran-local.js','js/dynamic-sky.js','js/sky-scene.js','css/sky-scene.css','css/sky.css','css/features.css','js/features/bookmarks.js','js/features/tools.js','js/features/onboarding.js','data/adhan.js','js/assistant.js','js/native-adhan.js', 'js/part01.js', 'js/part03.js', 'js/part04.js', 'js/part05.js', 'js/part06.js', 'js/part07.js', 'js/part09.js', 'js/part10.js', 'js/part11.js', 'js/part12.js', 'js/part13.js', 'js/part14.js', 'js/part15.js', 'js/part16.js', 'js/part17.js',  'js/part20.js', 'js/part21.js', 'js/part22.js', 'js/part23.js', 'js/part24.js', 'js/part25.js', 'js/part26.js', 'js/part27.js', 'js/part28.js', 'js/part29.js', 'js/prayer-calc.js', 'data/adhkar.js', 'data/library.js','data/library-plus.js','css/plus.css','js/features/plus.js','js/features/settings-plus.js','css/personal.css','data/parent-duas.js','js/features/personal.js','css/nav.css','js/features/nav.js','css/live-glass.css','css/crystal.css','js/features/crystal.js','css/smooth.css','js/features/smooth.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET'||r.headers.has('range'))return;
  const u=new URL(r.url);
  if(u.origin===location.origin){
    /* من الكاش فوراً ثم تحديث في الخلفية، فتصل التعديلات في الفتحة التالية */
    e.respondWith(caches.match(r,{ignoreSearch:true}).then(h=>{
      const net=fetch(r).then(x=>{if(x.ok&&x.status===200){const c=x.clone();caches.open(V).then(k=>k.put(r,c)).catch(()=>{});}return x;});
      return h?(net.catch(()=>{}),h):net.catch(()=>caches.match('index.html'));
    }));
    return;
  }
  // خارجي (خطوط، api.alquran.cloud، hadith، ملفات صوت): من الشبكة ثم يُحفظ؛ دون شبكة يُعاد المحفوظ
  e.respondWith(fetch(r).then(x=>{if(x.status===200||x.type==='opaque'){const c=x.clone();caches.open(V).then(k=>k.put(r,c)).catch(()=>{});}return x;}).catch(()=>caches.match(r)));
});
