/**
 * 🛠️ محرك التوافقية وحماية الشاشة (Native Notch & Safe Boot)
 * برمجة: مجتبى صديق | الإصدار 6.0.0.1
 */
(function applyNativeFixes() {
    'use strict';

    // 1. إصلاح تداخل شريط الحالة (النوتش) في شاشات الأندرويد الحديثة
    const style = document.createElement('style');
    style.innerHTML = `
        /* إبعاد الهيدر عن كاميرا الهاتف العلوية */
        .main-header {
            padding-top: calc(22px + env(safe-area-inset-top, 25px)) !important;
        }
        /* إبعاد القائمة السفلية عن شريط سحب الأندرويد السفلي */
        .bottom-nav {
            padding-bottom: env(safe-area-inset-bottom, 15px) !important;
            height: calc(var(--nav-height) + env(safe-area-inset-bottom, 15px)) !important;
        }
        /* حماية القارئ القرآني عند ملء الشاشة */
        .reader-header {
            padding-top: env(safe-area-inset-top, 25px) !important;
        }
    `;
    document.head.appendChild(style);

    // 2. ضمان عمل التطبيق وعدم انهياره إذا تأخر تحميل Capacitor
    window.addEventListener('DOMContentLoaded', () => {
        // فحص وجود مكتبة الخلفية وتفعيلها بهدوء لمنع تجميد واجهة المستخدم
        setTimeout(() => {
            if (window.cordova && window.cordova.plugins && window.cordova.plugins.backgroundMode) {
                try {
                    cordova.plugins.backgroundMode.enable();
                    cordova.plugins.backgroundMode.on('activate', function() {
                        cordova.plugins.backgroundMode.disableWebViewOptimizations(); 
                    });
                    console.log("🛡️ تم تفعيل حماية الخلفية بنجاح.");
                } catch (e) {
                    console.warn("تعذر تفعيل وضع الخلفية:", e);
                }
            }
        }, 1500);
    });

})();
