window.addEventListener('DOMContentLoaded', () => {
    // ننتظر قليلاً لضمان أن المحركات السابقة قد انتهت من بناء الواجهة
    setTimeout(() => {
        const journeyCard = document.getElementById('journey-entry-card'); // بطاقة رحلة النور
        const timeMachineCard = document.getElementById('tm-entry-card'); // بطاقة آلة الزمن
        
        // إذا كانت البطاقتان موجودتين، قم بنقل آلة الزمن لتكون أسفل رحلة النور مباشرة
        if (journeyCard && timeMachineCard) {
            journeyCard.insertAdjacentElement('afterend', timeMachineCard);
            console.log("✅ تم ترتيب البطاقات: آلة الزمن أسفل رحلة النور.");
        }
    }, 1500); // تأخير 1.5 ثانية لضمان الأداء المستقر
});
