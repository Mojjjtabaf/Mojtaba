// ===================================================
// ✨ IKHLAS PREMIUM SPIRITUAL SYSTEM
// ===================================================

(function(){

// ======================
// نجوم الإنجاز
// ======================

window.showAchievement=function(text="بارك الله فيك 🌟"){

const box=document.createElement("div");

box.innerHTML=`
<div style="
position:fixed;
top:50%;
left:50%;
transform:translate(-50%,-50%);
background:rgba(0,0,0,.75);
backdrop-filter:blur(20px);
padding:20px 30px;
border-radius:20px;
color:white;
font-weight:700;
font-size:1.1rem;
z-index:99999;
box-shadow:0 0 40px rgba(255,215,0,.3);
">
${text}
</div>
`;

document.body.appendChild(box);

for(let i=0;i<25;i++){

const star=document.createElement("div");

star.innerHTML="⭐";

star.style.cssText=`
position:fixed;
left:${50+(Math.random()*20-10)}%;
top:${50+(Math.random()*20-10)}%;
font-size:${16+Math.random()*18}px;
z-index:99998;
pointer-events:none;
`;

document.body.appendChild(star);

star.animate([
{
transform:"translate(0,0)",
opacity:1
},
{
transform:`
translate(
${(Math.random()-0.5)*500}px,
${(Math.random()-0.5)*500}px
)
`,
opacity:0
}
],{
duration:1800
});

setTimeout(()=>star.remove(),1800);

}

setTimeout(()=>box.remove(),2200);

};

// ======================
// نجوم تفاعلية
// ======================

document.addEventListener("click",e=>{

if(window.innerWidth<500){

const star=document.createElement("div");

star.innerHTML="✨";

star.style.cssText=`
position:fixed;
left:${e.clientX}px;
top:${e.clientY}px;
font-size:22px;
pointer-events:none;
z-index:99999;
`;

document.body.appendChild(star);

star.animate([
{
transform:"scale(.5)",
opacity:1
},
{
transform:"translateY(-80px) scale(2)",
opacity:0
}
],{
duration:1200
});

setTimeout(()=>star.remove(),1200);

}

});

// ======================
// شاشة الأذان السينمائية
// ======================

window.showAdhanScreen=function(prayer="الصلاة"){

const overlay=document.createElement("div");

overlay.innerHTML=`
<div id="adhanCinema"
style="
position:fixed;
inset:0;
background:
radial-gradient(
circle,
rgba(13,148,136,.15),
rgba(0,0,0,.95)
);
display:flex;
flex-direction:column;
align-items:center;
justify-content:center;
z-index:999999;
color:white;
">

<div style="
font-size:5rem;
margin-bottom:20px;
animation:pulse 2s infinite;
">🕌</div>

<div style="
font-size:2rem;
font-weight:900;
margin-bottom:10px;
">
حان الآن وقت
</div>

<div style="
font-size:3rem;
color:#fbbf24;
font-weight:900;
">
${prayer}
</div>

<div style="
margin-top:25px;
font-size:1rem;
opacity:.8;
">
حي على الصلاة • حي على الفلاح
</div>

</div>
`;

document.body.appendChild(overlay);

setTimeout(()=>{
overlay.remove();
},15000);

};

// ======================
// شجرة النور الحقيقية
// ======================

let treeLevel=
parseInt(
localStorage.getItem("ikhlasTree")||"0"
);

window.growTree=function(points=1){

treeLevel+=points;

localStorage.setItem(
"ikhlasTree",
treeLevel
);

updateTree();

if(treeLevel%10===0){

showAchievement(
"🌳 نمت شجرة النور"
);

}

};

window.updateTree=function(){

const leaves=
document.querySelectorAll(
".tree-leaf"
);

leaves.forEach((leaf,index)=>{

if(index<treeLevel){

leaf.style.opacity="1";

leaf.style.fill="#10b981";

leaf.style.transform=
"scale(1.1)";

}else{

leaf.style.opacity=".25";

}

});

const txt=
document.getElementById(
"tree-status-text"
);

if(txt){

txt.textContent=
`شجرة النور • مستوى ${treeLevel}`;

}

};

setTimeout(updateTree,1000);

// ======================
// أمثلة تلقائية
// ======================

window.completeDhikr=function(){

growTree(1);

showAchievement(
"🤲 تم إكمال الذكر بنجاح"
);

};

window.completeMorningAdhkar=function(){

growTree(5);

showAchievement(
"🌅 اكتملت أذكار الصباح"
);

};

window.completeKhatmahDay=function(){

growTree(10);

showAchievement(
"📖 أحسنت! تم إنجاز ورد اليوم"
);

};

})();
