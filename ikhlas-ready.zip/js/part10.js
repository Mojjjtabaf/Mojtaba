/**
 * ⏱️ الختمة الذكية الموقوتة v2 (Smart Khatmah)
 * - حفظ موضع الوقوف بالآية، واستئناف الجلسة من حيث توقفت
 * - عدّاد الوقت لا يُعاد ضبطه عند الانتقال بين السور
 * - نظام امتيازات تُفتح بمقدار ما تقرأ: ثيمات، تفسير، تكرار، حفظ، قفز بين السور، درع السلسلة
 * - هدف يومي وسلسلة أيام وتقدّم الختمة الكاملة (6236 آية)
 */
(function initSmartKhatmahPlugin() {
    'use strict';

    const KEY = 'SmartKhatmahV2';
    const NAMES = ["الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"];
    const AY = [7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6];
    const TOTAL = AY.reduce((a, b) => a + b, 0); // 6236
    const BASMALA = 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ';
    const DUA = 'اللهم ارحمني بالقرآن واجعله لي إماماً ونوراً وهدى ورحمة، اللهم ذكّرني منه ما نسيت وعلّمني منه ما جهلت وارزقني تلاوته آناء الليل وأطراف النهار.';

    // ===== الامتيازات =====
    const PERKS = [
        { id: 'theme',  at: 50,   icon: '🎨', name: 'ثيمات القراءة',     desc: 'ليلي وورقي وزمردي لراحة العين' },
        { id: 'long',   at: 150,  icon: '⏳', name: 'جلسات أطول',        desc: 'جلسات 45 و60 و90 دقيقة' },
        { id: 'tafsir', at: 300,  icon: '📖', name: 'التفسير الميسّر',    desc: 'يظهر تحت كل آية أثناء التدفق' },
        { id: 'repeat', at: 600,  icon: '🔁', name: 'وضع التكرار',        desc: 'كرّر كل آية مرتين أو ثلاثاً للتثبيت' },
        { id: 'memo',   at: 1000, icon: '🧠', name: 'وضع الحفظ',          desc: 'إخفاء بعض الكلمات ثم إظهارها لاختبار حفظك' },
        { id: 'jump',   at: 2000, icon: '🧭', name: 'القفز إلى أي سورة',  desc: 'ابدأ جلستك من أي سورة تريدها' },
        { id: 'shield', streak: 7, icon: '🛡️', name: 'درع السلسلة',       desc: 'يحمي سلسلة أيامك من يوم فائت واحد' }
    ];
    const RANKS = [
        { at: 0, t: 'قارئ جديد' }, { at: 100, t: 'مداوم' }, { at: 500, t: 'أنيس القرآن' },
        { at: 1500, t: 'صاحب الورد' }, { at: 3000, t: 'من أهل القرآن' }, { at: TOTAL, t: 'خاتم القرآن' }
    ];
    const THEMES = {
        'default': { name: 'الافتراضي', bg: '', fg: '' },
        night:   { name: 'ليلي',   bg: '#0b1220', fg: '#e2e8f0' },
        paper:   { name: 'ورقي',   bg: '#f6ecd6', fg: '#3b2a14' },
        emerald: { name: 'زمردي',  bg: '#062e26', fg: '#d1fae5' }
    };

    // ===== الحالة المحفوظة =====
    const defState = () => ({
        pos: { surah: 1, ayah: 1 }, totalAyahs: 0, totalSeconds: 0, days: {}, streak: 0, bestStreak: 0,
        lastDay: '', freeze: 0, khatmat: 0, fontScale: 1,
        prefs: { time: 10, mode: 'ayah', speed: 3, goal: 10, tafsir: false, repeat: 1, memo: false, theme: 'default', jump: 0 }
    });
    let st = defState();
    function loadState() {
        let saved = null;
        try { saved = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) {}
        st = Object.assign(defState(), saved || {});
        st.prefs = Object.assign(defState().prefs, (saved && saved.prefs) || {});
        st.pos = Object.assign({ surah: 1, ayah: 1 }, st.pos || {});
        if (!saved) { // ترحيل من النسخة القديمة
            const old = parseInt(localStorage.getItem('SmartKhatmahSurah'));
            if (old >= 1 && old <= 114) st.pos = { surah: old, ayah: 1 };
        }
        normalizePos(false);
    }
    function saveState() { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {} }

    const dayKey = (shift = 0) => new Date(Date.now() + shift * 864e5).toLocaleDateString('en-CA');
    const todaySecs = () => st.days[dayKey()] || 0;
    function normalizePos(count) {
        if (st.pos.surah < 1 || st.pos.surah > 114) st.pos = { surah: 1, ayah: 1 };
        while (st.pos.ayah > AY[st.pos.surah - 1]) {
            st.pos.ayah = 1; st.pos.surah++;
            if (st.pos.surah > 114) { st.pos.surah = 1; if (count) st.khatmat++; }
        }
        if (st.pos.ayah < 1) st.pos.ayah = 1;
    }
    const isUnlocked = p => p.at !== undefined ? st.totalAyahs >= p.at : st.bestStreak >= p.streak;
    const perk = id => PERKS.find(p => p.id === id);
    const can = id => isUnlocked(perk(id));
    const unlockedIds = () => PERKS.filter(isUnlocked).map(p => p.id);
    const ayahsBefore = s => AY.slice(0, s - 1).reduce((a, b) => a + b, 0);
    const khatmaPct = () => ((ayahsBefore(st.pos.surah) + st.pos.ayah - 1) / TOTAL * 100);
    const rank = () => RANKS.reduce((a, r) => st.totalAyahs >= r.at ? r : a, RANKS[0]);

    function markDay() { // اليوم يُحسب إذا قرأت دقيقة على الأقل
        const today = dayKey();
        if (st.lastDay === today || todaySecs() < 60) return;
        if (st.lastDay === dayKey(-1)) st.streak++;
        else if (st.lastDay === dayKey(-2) && st.freeze > 0) { st.freeze--; st.streak++; }
        else st.streak = 1;
        st.lastDay = today;
        if (st.streak > st.bestStreak) st.bestStreak = st.streak;
        if (st.streak > 0 && st.streak % 7 === 0) st.freeze = 1;
    }
    function liveStreak() { // السلسلة الحالية كما يراها المستخدم اليوم
        if (!st.lastDay) return 0;
        if (st.lastDay === dayKey() || st.lastDay === dayKey(-1)) return st.streak;
        if (st.lastDay === dayKey(-2) && st.freeze > 0) return st.streak;
        return 0;
    }

    // ===== الأنماط =====
    function injectStyles() {
        if (document.getElementById('smart-khatmah-css')) return;
        const style = document.createElement('style');
        style.id = 'smart-khatmah-css';
        style.textContent = `
            .smart-khatmah-text{font-family:var(--font-quran);line-height:1.7;color:var(--text-main);text-shadow:0 4px 20px var(--theme-glow);transition:font-size .2s}
            body.dark-mode .smart-khatmah-text{color:#fff;text-shadow:0 4px 20px rgba(45,212,191,.4)}
            #smart-khatmah-overlay.sk-themed .smart-khatmah-text{color:var(--text-main);text-shadow:none}
            .arabic-text-animate{animation:textPopUp .4s cubic-bezier(.175,.885,.32,1.275) forwards}
            @keyframes textPopUp{0%{opacity:0;transform:translateY(16px) scale(.94)}100%{opacity:1;transform:none}}
            #sk-tafsir{font-size:.95rem;line-height:1.8;color:var(--text-muted);text-align:center;padding:0 24px 8px;min-height:1.5em;max-height:22vh;overflow-y:auto}
            .sk-bar{display:flex;justify-content:center;align-items:center;gap:10px;padding:10px 16px calc(14px + env(safe-area-inset-bottom,0));flex-wrap:wrap}
            .sk-bar button{min-width:46px;height:46px;border-radius:14px;border:1px solid var(--glass-border);background:var(--glass-bg);color:var(--text-main);font:800 1rem inherit;cursor:pointer}
            .sk-sum{position:absolute;inset:0;background:var(--glass-bg-solid);display:none;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:24px;text-align:center;overflow-y:auto;z-index:5}
            .sk-sum.show{display:flex}
            .sk-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;width:100%;max-width:380px}
            .sk-stat{background:var(--glass-bg);border:1px solid var(--glass-border);border-radius:14px;padding:10px 4px;font-size:.75rem;color:var(--text-muted)}
            .sk-stat b{display:block;font-size:1.3rem;color:var(--primary)}
            .sk-row{display:flex;flex-direction:column;gap:6px;font-size:.85rem;font-weight:700}
            .sk-row select{padding:10px;border-radius:12px;border:1px solid var(--glass-border);background:var(--glass-bg-solid);color:var(--text-main);font-family:inherit}
            .sk-lock{opacity:.55;font-size:.78rem;font-weight:700;padding:8px 10px;border:1px dashed var(--glass-border);border-radius:12px;color:var(--text-muted)}
            .sk-perk{display:flex;gap:10px;align-items:center;padding:10px 0;border-bottom:1px solid var(--glass-border)}
            .sk-perk.off{opacity:.6}
            .sk-perk .ic{font-size:1.6rem}
            .sk-mini{height:5px;border-radius:5px;background:rgba(128,128,128,.2);overflow:hidden;margin-top:5px}
            .sk-mini i{display:block;height:100%;background:linear-gradient(90deg,var(--primary),var(--accent))}
            #smart-khatmah-launcher{position:fixed;inset:0;z-index:2500;display:none;align-items:flex-end;justify-content:center;background:rgba(10,15,25,.45);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);opacity:0;transition:opacity .25s}
            #smart-khatmah-launcher.open{display:flex;opacity:1}
            .sk-sheet{width:100%;max-width:560px;max-height:90vh;max-height:90dvh;display:flex;flex-direction:column;background:var(--glass-bg-solid);border-radius:28px 28px 0 0;box-shadow:0 -20px 50px -20px rgba(0,0,0,.45);padding:0 18px calc(18px + env(safe-area-inset-bottom,0px));animation:skSheetUp .32s cubic-bezier(.2,.9,.3,1)}
            @keyframes skSheetUp{from{transform:translateY(40px);opacity:0}to{transform:none;opacity:1}}
            .sk-sheet-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:16px 2px 12px;flex:none}
            .sk-sheet-head h2{font-size:1.05rem;font-weight:900;color:var(--text-main);margin:0}
            .sk-sheet #sk-body{overflow-y:auto;overscroll-behavior:contain;padding-bottom:6px}
            body.sk-sheet-open{overflow:hidden}
            .sk-sheet #sk-body>.btn-primary{position:sticky;bottom:0;z-index:3;box-shadow:0 -14px 16px -6px var(--glass-bg-solid)}
            .qa-btn{margin-bottom:0!important;cursor:pointer;display:flex!important;flex-direction:column;align-items:center;justify-content:flex-start;text-align:center;gap:5px;padding:14px 6px!important;min-width:0}
            .qa-ico{font-size:1.7rem;line-height:1}
            .qa-title{font-weight:800;font-size:.84rem;line-height:1.3}
            .qa-sub{font-size:.7rem;color:var(--text-muted);line-height:1.35;overflow-wrap:anywhere}
            .sk-chip{display:inline-flex;gap:4px;align-items:center;padding:5px 10px;border-radius:14px;background:var(--glass-bg);border:1px solid var(--glass-border);font-size:.75rem;font-weight:800}
        `;
        document.head.appendChild(style);
    }

    // ===== الواجهة =====
    function injectUI() {
        if (!document.getElementById('smart-khatmah-launcher')) {
            document.body.insertAdjacentHTML('beforeend', `
                <div id="smart-khatmah-launcher" role="dialog" aria-modal="true" aria-label="الختمة الذكية الموقوتة" onclick="if(event.target===this)window.closeSmartKhatmahSheet()">
                    <div class="sk-sheet">
                        <div class="sk-sheet-head">
                            <h2>⏱️ الختمة الذكية الموقوتة</h2>
                            <button class="btn-icon" onclick="window.closeSmartKhatmahSheet()" aria-label="إغلاق">
                                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                            </button>
                        </div>
                        <div id="sk-body"></div>
                    </div>
                </div>`);
        }
        if (!document.getElementById('smart-khatmah-overlay')) {
            document.body.insertAdjacentHTML('beforeend', `
                <div id="smart-khatmah-overlay" class="quran-reader-overlay" style="z-index:3000;background:var(--glass-bg-solid);display:none;flex-direction:column;position:fixed;inset:0">
                    <div class="reader-header" style="justify-content:space-between;background:transparent;border-bottom:none">
                        <button class="btn-icon" onclick="window.stopSmartKhatmah()" aria-label="إنهاء" style="background:rgba(239,68,68,.1);color:#ef4444;border-color:#ef4444">
                            <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                        </button>
                        <div style="text-align:center">
                            <div id="sk-timer-display" style="font-size:1.8rem;font-weight:900;color:var(--primary);font-variant-numeric:tabular-nums">00:00</div>
                            <div style="font-size:.75rem;color:var(--text-muted);font-weight:700">الوقت المتبقي</div>
                        </div>
                        <button class="btn-icon" id="sk-pause-btn" onclick="window.togglePauseSmartKhatmah()" aria-label="إيقاف مؤقت">⏸</button>
                    </div>
                    <div style="padding:0 20px">
                        <div style="display:flex;justify-content:space-between;font-size:.75rem;margin-bottom:4px;font-weight:700;color:var(--accent)">
                            <span id="sk-surah-name">جاري التحضير...</span>
                            <span id="sk-ayah-progress-text">0 / 0</span>
                        </div>
                        <div class="progress-bar-container" style="height:4px;margin-bottom:10px"><div class="progress-bar-fill" id="sk-ayah-progress-bar" style="width:0%"></div></div>
                    </div>
                    <div onclick="window.togglePauseSmartKhatmah()" style="flex:1;display:flex;align-items:center;justify-content:center;padding:24px;text-align:center;overflow-y:auto">
                        <div id="sk-display-text" class="smart-khatmah-text">${BASMALA}</div>
                    </div>
                    <div id="sk-tafsir"></div>
                    <div class="sk-bar">
                        <button onclick="window.skStep(-1)" aria-label="السابق">⏮</button>
                        <button onclick="window.skFont(-0.1)" aria-label="تصغير">A−</button>
                        <button onclick="window.skFont(0.1)" aria-label="تكبير">A+</button>
                        <button onclick="window.skStep(1)" aria-label="التالي">⏭</button>
                    </div>
                    <div class="sk-sum" id="sk-summary"></div>
                </div>`);
        }
        renderLauncher();
    }

    function renderLauncher() {
        updateQuickSummary();
        const box = document.getElementById('sk-body');
        if (!box) return;
        const p = st.prefs, nr = RANKS.find(r => r.at > st.totalAyahs), r = rank();
        const rankPct = nr ? Math.round((st.totalAyahs - r.at) / (nr.at - r.at) * 100) : 100;
        const goalMin = Math.round(todaySecs() / 60), goalPct = Math.min(100, Math.round(todaySecs() / (p.goal * 60) * 100));
        const opt = (v, l, cur) => `<option value="${v}"${String(cur) === String(v) ? ' selected' : ''}>${l}</option>`;
        const lock = pk => `<div class="sk-lock">🔒 ${pk.icon} ${pk.name} — ${pk.at !== undefined ? `يُفتح عند قراءة ${pk.at} آية (${st.totalAyahs}/${pk.at})` : `يُفتح عند سلسلة ${pk.streak} أيام`}</div>`;
        const times = [5, 10, 20, 30].concat(can('long') ? [45, 60, 90] : []);

        let extras = '';
        extras += can('theme') ? `<label class="sk-row">🎨 ثيم القراءة<select onchange="window.skPref('theme',this.value)">${Object.keys(THEMES).map(k => opt(k, THEMES[k].name, p.theme)).join('')}</select></label>` : lock(perk('theme'));
        extras += can('tafsir') ? `<label style="display:flex;gap:8px;align-items:center;font-size:.85rem;font-weight:700"><input type="checkbox" ${p.tafsir ? 'checked' : ''} onchange="window.skPref('tafsir',this.checked)"> 📖 إظهار التفسير الميسّر (يعمل مع نمط آية بآية)</label>` : lock(perk('tafsir'));
        extras += can('repeat') ? `<label class="sk-row">🔁 تكرار الآية<select onchange="window.skPref('repeat',+this.value)">${opt(1, 'بدون تكرار', p.repeat)}${opt(2, '×2', p.repeat)}${opt(3, '×3', p.repeat)}</select></label>` : lock(perk('repeat'));
        extras += can('memo') ? `<label style="display:flex;gap:8px;align-items:center;font-size:.85rem;font-weight:700"><input type="checkbox" ${p.memo ? 'checked' : ''} onchange="window.skPref('memo',this.checked)"> 🧠 وضع الحفظ (إخفاء كلمات ثم إظهارها)</label>` : lock(perk('memo'));
        extras += can('jump') ? `<label class="sk-row">🧭 ابدأ من<select onchange="window.skPref('jump',+this.value)">${opt(0, `موضع وقوفي: ${NAMES[st.pos.surah - 1]} آية ${st.pos.ayah}`, p.jump)}${NAMES.map((n, i) => opt(i + 1, `${i + 1}. ${n}`, p.jump)).join('')}</select></label>` : lock(perk('jump'));

        const perkRows = PERKS.map(pk => {
            const on = isUnlocked(pk), need = pk.at !== undefined ? pk.at : pk.streak, cur = pk.at !== undefined ? st.totalAyahs : st.bestStreak;
            return `<div class="sk-perk ${on ? '' : 'off'}"><div class="ic">${on ? pk.icon : '🔒'}</div><div style="flex:1"><div style="font-weight:800;font-size:.9rem">${pk.name} ${on ? '✅' : ''}</div><div style="font-size:.75rem;color:var(--text-muted)">${pk.desc}</div>${on ? '' : `<div class="sk-mini"><i style="width:${Math.min(100, cur / need * 100)}%"></i></div><div style="font-size:.7rem;color:var(--text-muted);margin-top:2px">${cur}/${need} ${pk.at !== undefined ? 'آية' : 'أيام'}</div>`}</div></div>`;
        }).join('');

        box.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px">
                <div><div style="font-weight:900;font-size:1.05rem;color:var(--primary)">${r.t}${st.khatmat ? ` · ${st.khatmat} ختمة 👑` : ''}</div>
                <div style="font-size:.72rem;color:var(--text-muted)">${st.totalAyahs} آية مقروءة${nr ? ` · التالي: ${nr.t}` : ''}</div></div>
                <div style="display:flex;gap:6px"><span class="sk-chip">🔥 ${liveStreak()}</span>${st.freeze ? '<span class="sk-chip">🛡️</span>' : ''}</div>
            </div>
            <div class="sk-mini" style="margin:0 0 12px"><i style="width:${rankPct}%"></i></div>
            <div style="font-size:.82rem;font-weight:700;margin-bottom:4px">📍 موضع وقوفك: سورة ${NAMES[st.pos.surah - 1]} · آية ${st.pos.ayah}</div>
            <div class="sk-mini" style="margin:0 0 4px"><i style="width:${khatmaPct().toFixed(1)}%"></i></div>
            <div style="font-size:.72rem;color:var(--text-muted);margin-bottom:12px">تقدّم الختمة الكاملة ${khatmaPct().toFixed(1)}%</div>
            <div style="font-size:.82rem;font-weight:700;margin-bottom:4px">🎯 هدف اليوم: ${goalMin} / ${p.goal} دقيقة ${goalPct >= 100 ? '✅' : ''}</div>
            <div class="sk-mini" style="margin:0 0 14px"><i style="width:${goalPct}%"></i></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
                <label class="sk-row">⏳ المدة<select onchange="window.skPref('time',+this.value)">${times.map(t => opt(t, t === 30 ? 'نصف ساعة' : t + ' دقيقة', p.time)).join('')}</select></label>
                <label class="sk-row">👁️ النمط<select onchange="window.skPref('mode',this.value)">${opt('ayah', 'آية بآية', p.mode)}${opt('word', 'كلمة بكلمة', p.mode)}</select></label>
                <label class="sk-row">🎯 هدفك اليومي<select onchange="window.skPref('goal',+this.value)">${[5, 10, 15, 20, 30, 60].map(g => opt(g, g + ' دقيقة', p.goal)).join('')}</select></label>
                <label class="sk-row">⚡ السرعة<input type="range" min="1" max="5" value="${p.speed}" onchange="window.skPref('speed',+this.value)" style="accent-color:var(--primary);margin-top:10px"></label>
            </div>
            <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:14px">${extras}</div>
            <button class="btn-primary" onclick="window.startSmartKhatmah()">🚀 ${st.totalAyahs ? 'واصل الختمة' : 'ابدأ الختمة الذكية'}</button>
            <button class="btn-secondary" style="width:100%;margin-top:8px" onclick="document.getElementById('sk-perks').style.display=document.getElementById('sk-perks').style.display==='none'?'block':'none'">🎁 امتيازاتي</button>
            <div id="sk-perks" style="display:none;margin-top:8px">${perkRows}</div>`;
    }
    // ===== زر الوصول السريع + لوحة الختمة الذكية =====
    function updateQuickSummary() {
        const el = document.getElementById('sk-quick-summary');
        if (!el) return;
        el.textContent = st.totalAyahs ? `واصل: ${NAMES[st.pos.surah - 1]} ${st.pos.ayah}` : 'ابدأ الآن';
    }
    window.openSmartKhatmah = function () {
        const el = document.getElementById('smart-khatmah-launcher');
        if (!el) return;
        renderLauncher();
        el.classList.add('open');
        document.body.classList.add('sk-sheet-open');
    };
    window.closeSmartKhatmahSheet = function () {
        const el = document.getElementById('smart-khatmah-launcher');
        if (el) el.classList.remove('open');
        document.body.classList.remove('sk-sheet-open');
    };
    document.addEventListener('keydown', e => {
        if ((e.key === 'Enter' || e.key === ' ') && e.target && e.target.id === 'qa-smart-khatmah') { e.preventDefault(); window.openSmartKhatmah(); }
    });
    window.skPref = function (k, v) {
        st.prefs[k] = v;
        if (k === 'mode' && v === 'word') st.prefs.repeat = 1;
        saveState();
        if (k === 'goal' || k === 'jump') renderLauncher();
    };
    window.skFont = function (d) {
        st.fontScale = Math.min(1.6, Math.max(0.7, +(st.fontScale + d).toFixed(2)));
        saveState();
        if (S) applyFont(S.cur);
    };

    // ===== المحرك =====
    let S = null;                       // الجلسة الحالية
    const surahCache = new Map(), tafsirCache = new Map();
    let wakeLock = null;
    const $ = id => document.getElementById(id);
    const nz = s => s.replace(/[\u064B-\u065F\u0670\u0640\u06D6-\u06ED]/g, '').replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه');

    async function getSurah(n) {
        if (surahCache.has(n)) return surahCache.get(n);
        const res = await fetch(`https://api.alquran.cloud/v1/surah/${n}`);
        const json = await res.json();
        surahCache.set(n, json.data);
        return json.data;
    }
    function stripBasmala(text, surah, ayah) {
        if (surah === 1 || ayah !== 1) return text;
        const w = text.split(' ');
        return (w.length > 4 && nz(w.slice(0, 4).join(' ')).startsWith('بسم الله الرحمن الرحيم')) ? w.slice(4).join(' ') : text;
    }
    function buildQueue(data, startAyah, mode, repeat) {
        const q = [], n = data.number;
        if (startAyah === 1 && n !== 1 && n !== 9) q.push({ text: BASMALA, ayah: 0, count: false, kind: 'basmala' });
        data.ayahs.forEach(a => {
            if (a.numberInSurah < startAyah) return;
            const text = stripBasmala(a.text, n, a.numberInSurah), no = a.numberInSurah;
            if (mode === 'ayah') {
                const reps = Math.max(1, repeat);
                for (let i = 0; i < reps; i++) q.push({ text: `${text} ﴿${no}﴾`, ayah: no, count: i === reps - 1, kind: 'ayah', raw: text });
            } else {
                text.split(' ').forEach(w => q.push({ text: w, ayah: no, count: false, kind: 'word' }));
                q.push({ text: `﴿${no}﴾`, ayah: no, count: true, kind: 'marker' });
            }
        });
        return q;
    }
    function delayFor(it) {
        const per = [0, 950, 750, 600, 470, 350][st.prefs.speed] || 600;
        const words = it.text.split(' ').length;
        let d;
        if (it.kind === 'basmala') d = 2500;
        else if (it.kind === 'word') d = 250 + per * 0.7;
        else if (it.kind === 'marker') d = 600;
        else d = 1400 + words * per;
        if (st.prefs.memo && can('memo') && it.kind === 'ayah') d *= 1.35;
        return d;
    }
    function applyFont(it) {
        const el = $('sk-display-text'); if (!el) return;
        let base = (S && S.mode === 'word') ? 4.5 : 2.2;
        const words = it ? it.text.split(' ').length : 0;
        if (S && S.mode === 'ayah') base *= words > 80 ? 0.6 : words > 40 ? 0.75 : 1;
        el.style.fontSize = (base * st.fontScale) + 'rem';
    }
    function applyTheme() {
        const ov = $('smart-khatmah-overlay'), t = THEMES[can('theme') ? st.prefs.theme : 'default'] || THEMES['default'];
        ov.classList.toggle('sk-themed', !!t.bg);
        ov.style.background = t.bg || 'var(--glass-bg-solid)';
        ov.style.setProperty('--text-main', t.fg || '');
        if (!t.fg) ov.style.removeProperty('--text-main');
    }
    function setTimerUI() {
        const m = String(Math.floor(S.remaining / 60)).padStart(2, '0'), s = String(S.remaining % 60).padStart(2, '0');
        $('sk-timer-display').innerText = `${m}:${s}`;
    }
    async function lockScreen() {
        try { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {}
    }
    function unlockScreen() { try { if (wakeLock) wakeLock.release(); } catch (e) {} wakeLock = null; }

    window.startSmartKhatmah = async function (extraMinutes) {
        if (window.closeSmartKhatmahSheet) window.closeSmartKhatmahSheet();
        if (S && S.active) return;
        const p = st.prefs;
        if (p.jump > 0 && can('jump')) { st.pos = { surah: p.jump, ayah: 1 }; p.jump = 0; }
        normalizePos(true);
        const minutes = extraMinutes || Math.min(p.time, can('long') ? 90 : 30);
        S = { active: false, paused: false, remaining: minutes * 60, queue: [], idx: 0, surah: st.pos.surah, mode: p.mode,
              sessionAyahs: 0, sessionSecs: 0, perksBefore: unlockedIds(), tick: null, next: null, reveal: null, cur: null, startPos: { ...st.pos }, startAyahs: st.totalAyahs };
        applyTheme();
        $('sk-summary').classList.remove('show');
        $('sk-surah-name').innerText = 'جاري تحضير الآيات...';
        $('sk-display-text').innerText = '⏳';
        $('sk-tafsir').innerText = '';
        $('smart-khatmah-overlay').style.display = 'flex';
        setTimerUI();
        try {
            const data = await getSurah(S.surah);
            S.queue = buildQueue(data, st.pos.ayah, S.mode, can('repeat') ? p.repeat : 1);
            S.data = data;
            S.active = true;
            getSurah(S.surah % 114 + 1).catch(() => {});
            lockScreen();
            startTimer();
            if (window.triggerHapticPro) window.triggerHapticPro([50, 100, 50]);
            step();
        } catch (e) {
            S.active = false;
            $('sk-display-text').style.fontSize = '1.3rem';
            $('sk-display-text').innerText = 'تعذّر تحميل السورة. تأكد من الاتصال بالإنترنت ثم أعد المحاولة.';
        }
    };

    function startTimer() {
        clearInterval(S.tick);
        S.tick = setInterval(() => {
            if (!S || S.paused || !S.active) return;
            S.remaining--; S.sessionSecs++; st.totalSeconds++;
            const k = dayKey(); st.days[k] = (st.days[k] || 0) + 1;
            markDay();
            setTimerUI();
            if (S.sessionSecs % 5 === 0) saveState();
            if (S.remaining <= 0) finish();
        }, 1000);
    }

    async function step() {
        if (!S || !S.active || S.paused) return;
        clearTimeout(S.next); clearTimeout(S.reveal);
        if (S.idx >= S.queue.length) { // انتهت السورة: ننتقل للتالية دون المساس بالعدّاد
            S.active = false;
            st.pos = { surah: S.surah + 1, ayah: 1 };
            normalizePos(true);
            S.surah = st.pos.surah;
            saveState();
            try {
                const data = await getSurah(S.surah);
                S.data = data; S.queue = buildQueue(data, 1, S.mode, can('repeat') ? st.prefs.repeat : 1); S.idx = 0;
                getSurah(S.surah % 114 + 1).catch(() => {});
                S.active = true;
                if (S.remaining > 0) step();
            } catch (e) {
                S.paused = true; S.active = true;
                $('sk-pause-btn').innerText = '▶';
                $('sk-display-text').innerText = 'انقطع الاتصال. اضغط ▶ للمتابعة.';
            }
            return;
        }
        const it = S.queue[S.idx++];
        S.cur = it;
        show(it);
        if (it.count) {
            st.totalAyahs++; S.sessionAyahs++;
            st.pos = { surah: S.surah, ayah: it.ayah + 1 };
            saveState();
        }
        S.next = setTimeout(step, delayFor(it));
    }

    function show(it) {
        const el = $('sk-display-text');
        $('sk-surah-name').innerText = 'سورة ' + NAMES[S.surah - 1];
        applyFont(it);
        el.classList.remove('arabic-text-animate'); void el.offsetWidth;
        const memo = st.prefs.memo && can('memo') && it.kind === 'ayah';
        if (memo) {
            const words = it.raw.split(' ');
            const masked = words.map((w, i) => (i > 0 && Math.random() < 0.3) ? '＿＿' : w).join(' ');
            el.innerText = `${masked} ﴿${it.ayah}﴾`;
            S.reveal = setTimeout(() => { el.innerText = it.text; }, delayFor(it) * 0.6);
        } else el.innerText = it.text;
        el.classList.add('arabic-text-animate');
        const total = AY[S.surah - 1];
        if (it.ayah > 0) {
            $('sk-ayah-progress-bar').style.width = (it.ayah / total * 100) + '%';
            $('sk-ayah-progress-text').innerText = `${it.ayah} / ${total}`;
        }
        // التفسير
        const tf = $('sk-tafsir');
        if (st.prefs.tafsir && can('tafsir') && it.ayah > 0 && (it.kind === 'ayah' || it.kind === 'marker')) {
            const key = `${S.surah}:${it.ayah}`;
            const put = t => { if (S && S.cur === it) tf.innerText = t || ''; };
            if (tafsirCache.has(key)) put(tafsirCache.get(key));
            else { tf.innerText = ''; fetch(`https://api.alquran.cloud/v1/ayah/${key}/ar.muyassar`).then(r => r.json()).then(j => { const t = j && j.data && j.data.text; tafsirCache.set(key, t); put(t); }).catch(() => {}); }
        } else tf.innerText = '';
    }

    window.skStep = function (dir) {
        if (!S || !S.active) return;
        clearTimeout(S.next); clearTimeout(S.reveal);
        if (dir < 0) S.idx = Math.max(0, S.idx - 2);
        if (S.paused) { S.paused = false; $('sk-pause-btn').innerText = '⏸'; }
        step();
    };

    window.togglePauseSmartKhatmah = function () {
        if (!S || !S.active) return;
        S.paused = !S.paused;
        $('sk-pause-btn').innerText = S.paused ? '▶' : '⏸';
        if (S.paused) {
            clearTimeout(S.next); clearTimeout(S.reveal);
            if (S.cur && S.cur.kind === 'ayah') $('sk-display-text').innerText = S.cur.text; // نكشف النص عند الإيقاف
            saveState();
        } else step();
        if (window.triggerHapticPro) window.triggerHapticPro(20);
    };

    function teardown() {
        if (!S) return;
        S.active = false;
        clearInterval(S.tick); clearTimeout(S.next); clearTimeout(S.reveal);
        unlockScreen();
        saveState();
    }

    function finish() {
        if (!S || !S.active) return;
        teardown();
        if (window.triggerHapticPro) window.triggerHapticPro([100, 200, 100]);
        const newPerks = PERKS.filter(pk => isUnlocked(pk) && !S.perksBefore.includes(pk.id));
        const goalDone = todaySecs() >= st.prefs.goal * 60;
        const mins = Math.max(1, Math.round(S.sessionSecs / 60));
        $('sk-summary').innerHTML = `
            <div style="font-size:3rem">🌙</div>
            <h2 style="font-family:'Aref Ruqaa',serif;font-size:2rem;color:var(--primary)">تقبّل الله طاعتك</h2>
            <div class="sk-grid">
                <div class="sk-stat"><b>${S.sessionAyahs}</b>آية</div>
                <div class="sk-stat"><b>${mins}</b>دقيقة</div>
                <div class="sk-stat"><b>${liveStreak()}🔥</b>سلسلة</div>
            </div>
            <div style="font-size:.85rem;font-weight:700">📍 وقفت عند: سورة ${NAMES[st.pos.surah - 1]} · آية ${st.pos.ayah} (${khatmaPct().toFixed(1)}% من الختمة)</div>
            ${goalDone ? '<div class="sk-chip">🎯 أتممت هدف اليوم</div>' : ''}
            ${newPerks.map(pk => `<div class="sk-chip" style="border-color:#f59e0b;background:rgba(245,158,11,.12)">🎁 امتياز جديد: ${pk.icon} ${pk.name}</div>`).join('')}
            <p style="font-size:.85rem;line-height:1.9;color:var(--text-muted);max-width:380px">${DUA}</p>
            <button class="btn-primary" style="max-width:380px" onclick="window.startSmartKhatmah(5)">➕ تابع 5 دقائق أخرى</button>
            <button class="btn-secondary" style="max-width:380px;width:100%" onclick="window.stopSmartKhatmah()">إغلاق</button>`;
        $('sk-summary').classList.add('show');
    }

    window.stopSmartKhatmah = function () {
        teardown();
        const ov = $('smart-khatmah-overlay');
        if (ov) ov.style.display = 'none';
        const sm = $('sk-summary'); if (sm) sm.classList.remove('show');
        S = null;
        renderLauncher();
    };

    document.addEventListener('visibilitychange', () => {
        if (!S || !S.active) return;
        if (document.hidden) { if (!S.paused) window.togglePauseSmartKhatmah(); saveState(); }
        else if (!wakeLock) lockScreen();
    });

    // ===== الإقلاع =====
    function bootPlugin() {
        try { loadState(); injectStyles(); injectUI(); console.log('⏱️ تم تفعيل الختمة الذكية v2.'); }
        catch (e) { console.error('Smart Khatmah Error:', e); }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bootPlugin);
    else bootPlugin();
})();
