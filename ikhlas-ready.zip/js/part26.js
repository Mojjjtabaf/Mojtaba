(function initIslamicTimeMachine() {
    'use strict';
    // ===== آلة الزمن الإسلامية v2 =====
    const LS_KEY = 'Ikhlas_TimeMachine_Data';
    const $ = id => document.getElementById(id);
    const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

    // العصور: req = {era, n} => تُفتح بعد اكتشاف n أحداث من العصر المطلوب
    const TM_ERAS = [
        { id:"e1", name:"عصر الأنبياء", icon:"👤", req:null, desc:"فجر البشرية ورسالات التوحيد." },
        { id:"e2", name:"عصر النبوة", icon:"🕌", req:null, desc:"مولد النور والبعثة المحمدية." },
        { id:"e3", name:"عصر الغزوات", icon:"⚔️", req:{era:"e2",n:2}, desc:"الدفاع عن الدين وتأسيس الدولة." },
        { id:"e4", name:"الخلافة الراشدة", icon:"👑", req:{era:"e3",n:2}, desc:"عصر العدل والفتوحات الكبرى." },
        { id:"e5", name:"الدولة الأموية", icon:"🏛", req:{era:"e4",n:2}, desc:"امتداد الدولة من الصين للأندلس." },
        { id:"e6", name:"الدولة العباسية", icon:"📚", req:{era:"e5",n:2}, desc:"عصر الترجمة وبناء بغداد." },
        { id:"e7", name:"الأندلس", icon:"🌍", req:{era:"e5",n:2}, desc:"حضارة الغرب الإسلامي." },
        { id:"e8", name:"صلاح الدين وما بعده", icon:"🦅", req:{era:"e6",n:2}, desc:"تحرير القدس وردّ الصليبيين والمغول." },
        { id:"e9", name:"الدولة العثمانية", icon:"🕋", req:{era:"e8",n:2}, desc:"فتح القسطنطينية وعمارة سنان." },
        { id:"e10", name:"علماء المسلمين", icon:"🧠", req:null, desc:"عباقرة أضاؤوا العالم." }
    ];

    // [id, era, عنوان، شخصية، قصة، هل تعلم، سؤال، خيارات، رقم الصحيح، أثر المتحف]
    const E = (id,era,title,character,story,fact,question,options,correct,artifact) =>
        ({id,era,title,character,story,fact,question,options,correct,artifact});
    const TM_EVENTS_DB = [
        E("n1","e1","سفينة النجاة","نوح عليه السلام","دعا نوح قومه إلى التوحيد زمناً طويلاً فلم يؤمن معه إلا قليل، ثم أمره الله ببناء الفلك ونجّاه ومن آمن معه.","ذكر القرآن أنه لبث فيهم ألف سنة إلا خمسين عاماً (سورة العنكبوت).","كم لبث نوح عليه السلام في قومه يدعوهم؟",["950 سنة","500 سنة","120 سنة","300 سنة"],0,"⛵ لوح من الفلك"),
        E("n2","e1","برداً وسلاماً","إبراهيم عليه السلام","حطّم إبراهيم أصنام قومه وحاجّهم بالحجة، فأشعلوا له ناراً عظيمة وألقوه فيها، فنجّاه الله منها.","قال الله: ﴿قلنا يا نار كوني برداً وسلاماً على إبراهيم﴾ (سورة الأنبياء).","ماذا أمر الله النار أن تكون على إبراهيم؟",["برداً وسلاماً","رماداً","خامدة","بعيدة عنه"],0,"🔥 جمرة ساكنة"),
        E("n3","e1","الرؤيا الصادقة","يوسف عليه السلام","رأى يوسف وهو صغير رؤيا عجيبة، ثم ابتُلي بالجبّ والسجن حتى مكّنه الله في الأرض.","قصة يوسف وصفها القرآن بأنها ﴿أحسن القصص﴾.","كم كوكباً رأى يوسف في رؤياه؟",["أحد عشر","سبعة","اثنا عشر","تسعة"],0,"🌟 كوكب الرؤيا"),
        E("n4","e1","انفلاق البحر","موسى عليه السلام","خرج موسى ببني إسرائيل ليلاً هرباً من فرعون، فلما بلغوا البحر أوحى الله إليه أن يضربه بعصاه فانفلق.","نجّى الله موسى وقومه وأغرق فرعون وجنوده (سورة الشعراء).","بماذا ضرب موسى البحر فانفلق؟",["بعصاه","بيده","بثوبه","بحجر"],0,"🪄 عصا موسى"),

        E("p1","e2","غار حراء","محمد ﷺ","كان النبي ﷺ يتعبّد في غار حراء، حتى جاءه جبريل عليه السلام بالوحي لأول مرة.","نزل الوحي على النبي ﷺ وهو في الأربعين من عمره.","أول كلمة نزلت من القرآن الكريم هي: ...",["اقرأ","الحمد","سبحان","الله"],0,"📜 صحيفة الوحي"),
        E("p2","e2","دار الأرقم","الأرقم بن أبي الأرقم","كانت دار الأرقم مقرّاً هادئاً تجمّع فيه المسلمون الأوائل يتعلّمون من النبي ﷺ بعيداً عن أذى قريش.","أسلم في دار الأرقم عدد من كبار الصحابة، ومنهم عمر بن الخطاب رضي الله عنه.","أين كانت دار الأرقم بن أبي الأرقم؟",["عند جبل الصفا في مكة","في المدينة المنورة","في الطائف","في جدة"],0,"🏠 مفتاح الدار"),
        E("p3","e2","الهجرة النبوية","محمد ﷺ وأبو بكر","خرج النبي ﷺ مع أبي بكر الصديق مهاجرَين من مكة، واختبآ في غار ثور ثلاث ليال قبل مواصلة الطريق.","اعتُمدت الهجرة بدايةً للتقويم الهجري في عهد عمر بن الخطاب رضي الله عنه.","إلى أي مدينة هاجر النبي ﷺ؟",["المدينة المنورة (يثرب)","الطائف","دمشق","الحبشة"],0,"🐪 ناقة القصواء"),

        E("g1","e3","يوم الفرقان","محمد ﷺ","في السنة الثانية للهجرة التقى المسلمون بجيش قريش عند آبار بدر، فنصرهم الله وهم قلّة.","كان المسلمون في بدر نحو 313 رجلاً، ووقعت المعركة في 17 رمضان.","في أي سنة هجرية وقعت غزوة بدر؟",["2 هـ","1 هـ","3 هـ","5 هـ"],0,"⚔️ سيف بدر"),
        E("g2","e3","درس أُحد","الرماة يوم أُحد","وضع النبي ﷺ خمسين رامياً على جبل وأمرهم بلزوم مكانهم، فلما تركوه انقلبت المعركة مؤقتاً.","تعلّم المسلمون في أُحد أهمية الطاعة والثبات على أمر القائد.","على أي جبل وضع النبي ﷺ الرماة يوم أُحد؟",["جبل الرماة (عينين)","جبل النور","جبل ثور","جبل عرفة"],0,"🏹 قوس الرماة"),
        E("g3","e3","حفر الخندق","سلمان الفارسي","حاصرت الأحزاب المدينة، فأشار سلمان الفارسي رضي الله عنه بحفر خندق حولها.","كان الخندق أسلوباً لم يعتده العرب في الحرب، وفشل الأحزاب أمامه.","من أشار على النبي ﷺ بحفر الخندق؟",["سلمان الفارسي","خالد بن الوليد","عمر بن الخطاب","أبو ذر"],0,"⛏️ معول الخندق"),

        E("r1","e4","عام الرمادة","عمر بن الخطاب","أصاب الحجاز جدب شديد، فبذل عمر رضي الله عنه جهده لإطعام الناس وتوزيع الأقوات.","اسودّت الأرض من قلة المطر فسُمّي عام الرمادة، ويُروى أنه استمر نحو تسعة أشهر.","استمر عام الرمادة خمس سنوات متواصلة.",["صح","خطأ"],1,"🌾 كيس الطحين"),
        E("r2","e4","جمع القرآن","أبو بكر الصديق","بعد استشهاد عدد كبير من القرّاء في اليمامة، أمر أبو بكر رضي الله عنه بجمع القرآن في صحف.","كُلّف بالجمع زيد بن ثابت رضي الله عنه، وكان من كتّاب الوحي.","من كلّفه أبو بكر بجمع القرآن؟",["زيد بن ثابت","علي بن أبي طالب","ابن مسعود","أبو هريرة"],0,"📖 الصحف الأولى"),
        E("r3","e4","معركة اليرموك","خالد بن الوليد","التقى المسلمون بجيوش الروم على نهر اليرموك، وكانت معركة حاسمة في فتح الشام.","وقعت اليرموك سنة 15 هـ، وكان لخالد بن الوليد دور بارز في خطتها.","أي معركة حاسمة وقعت سنة 15 هـ ضد الروم؟",["اليرموك","القادسية","حطين","بدر"],0,"🚩 راية اليرموك"),

        E("u1","e5","قبة الصخرة","عبد الملك بن مروان","أمر الخليفة الأموي عبد الملك ببناء قبة الصخرة في بيت المقدس، وهي من أقدم الآثار الإسلامية الباقية.","اكتمل بناؤها سنة 72 هـ (691م) تقريباً.","من الخليفة الذي بنى قبة الصخرة؟",["عبد الملك بن مروان","معاوية بن أبي سفيان","هارون الرشيد","عمر بن عبد العزيز"],0,"🕌 نقش القبة"),
        E("u2","e5","عبور المضيق","طارق بن زياد","عبر طارق بن زياد المضيق إلى شبه الجزيرة الإيبيرية بجيشه، وانتصر في معركة وادي لكّة.","سُمّي جبل طارق نسبةً إليه، وكان ذلك سنة 92 هـ (711م).","من قائد فتح الأندلس عام 92 هـ؟",["طارق بن زياد","موسى بن نصير وحده","عقبة بن نافع","محمد بن القاسم"],0,"⛰️ خريطة الفتح"),
        E("u3","e5","الخليفة الزاهد","عمر بن عبد العزيز","تولّى الخلافة فردّ المظالم وعدل بين الناس، وقلّل نفقات القصر.","يُلقّب بـ«خامس الخلفاء الراشدين» لعدله وزهده.","بأي لقب يُعرف عمر بن عبد العزيز؟",["خامس الخلفاء الراشدين","صقر قريش","سيف الله","أمير الأطباء"],0,"⚖️ ميزان العدل"),

        E("b1","e6","مدينة السلام","أبو جعفر المنصور","أسس الخليفة المنصور بغداد ودعاها مدينة السلام، وصمّمها مدورة.","بدأ بناء بغداد سنة 145 هـ (762م) على نهر دجلة.","من مؤسس مدينة بغداد؟",["أبو جعفر المنصور","هارون الرشيد","المأمون","المعتصم"],0,"🏙️ مخطط بغداد"),
        E("b2","e6","بيت الحكمة","المأمون","اهتم الخليفة المأمون بترجمة علوم الأمم ودعم العلماء في بغداد.","عمل في بيت الحكمة علماء كالخوارزمي وبنو موسى.","أي خليفة اشتهر بدعمه بيت الحكمة والترجمة؟",["المأمون","المتوكل","الواثق","المهدي"],0,"⚗️ أسطرلاب"),
        E("b3","e6","فتح عمّورية","المعتصم بالله","بلغ المعتصم أن امرأة مسلمة استغاثت به، فجهّز جيشاً وفتح مدينة عمّورية.","كان الفتح سنة 223 هـ، وخلّده الشاعر أبو تمام.","أي مدينة فتحها المعتصم بعد استغاثة المرأة؟",["عمّورية","القسطنطينية","روما","أنطاكية"],0,"🛡️ درع المعتصم"),

        E("a1","e7","صقر قريش","عبد الرحمن الداخل","نجا عبد الرحمن من ملاحقة العباسيين، وعبر إلى الأندلس وأسس فيها إمارة أموية.","حكم الأندلس نحو 33 عاماً، وجعل قرطبة عاصمة.","ما عاصمة الأمويين في الأندلس؟",["قرطبة","غرناطة","إشبيلية","طليطلة"],0,"🦅 خاتم الإمارة"),
        E("a2","e7","معركة الزلّاقة","يوسف بن تاشفين","استنجد ملوك الطوائف بالمرابطين حين هدّد ألفونسو السادس الأندلس، فانتصروا في الزلّاقة.","وقعت المعركة سنة 479 هـ وأخّرت سقوط الأندلس زمناً طويلاً.","من قائد المرابطين في معركة الزلّاقة؟",["يوسف بن تاشفين","عبد الرحمن الناصر","المنصور بن أبي عامر","ابن رشد"],0,"🗡️ سيف المرابطين"),

        E("s1","e8","معركة حطين","صلاح الدين الأيوبي","جمع صلاح الدين المسلمين ونازل الصليبيين عند حطين قرب طبرية، فانتصر نصراً كبيراً.","كانت حطين سنة 583 هـ (1187م).","في أي سنة هجرية وقعت معركة حطين؟",["583 هـ","450 هـ","620 هـ","700 هـ"],0,"🦅 لواء حطين"),
        E("s2","e8","فتح بيت المقدس","صلاح الدين الأيوبي","بعد حطين سار صلاح الدين إلى القدس ودخلها وعامل أهلها بالرحمة.","دخل القدس في رجب سنة 583 هـ (أكتوبر 1187م).","في أي شهر هجري دخل صلاح الدين القدس؟",["رجب","رمضان","محرم","ذو الحجة"],0,"🔑 مفتاح القدس"),
        E("s3","e8","عين جالوت","سيف الدين قطز","بعد اجتياح المغول للعالم الإسلامي، تصدّى لهم المماليك في فلسطين.","كانت عين جالوت سنة 658 هـ وأوقفت زحف المغول غرباً.","من قاد المسلمين في عين جالوت؟",["سيف الدين قطز","نور الدين زنكي","صلاح الدين","المعتصم"],0,"🥁 طبل المعركة"),

        E("o1","e9","فتح القسطنطينية","محمد الفاتح","بعد حصار طويل ونقل السفن برّاً، فتح السلطان محمد الثاني القسطنطينية.","تم الفتح سنة 857 هـ (1453م) وعمره 21 عاماً، تحقيقاً لبشارة نبوية.","كم كان عمر محمد الفاتح عند فتح القسطنطينية؟",["21 سنة","35 سنة","45 سنة","60 سنة"],0,"🏰 مفتاح القسطنطينية"),
        E("o2","e9","عمارة سنان","المعماري سنان","برع سنان في العمارة العثمانية وأشرف على مئات المباني.","من أشهر أعماله مسجد السليمانية في إسطنبول ومسجد السليمية في أدرنة.","من المعماري صاحب مسجد السليمانية؟",["سنان","ابن خلدون","ابن بطوطة","ابن الهيثم"],0,"📐 مخطط القبة"),

        E("c1","e10","أمير الأطباء","ابن سينا","ألّف ابن سينا موسوعته الطبية التي دُرّست في أوروبا قروناً.","حفظ القرآن صغيراً، وكتابه «القانون في الطب» مرجع عالمي.","ما اسم كتاب ابن سينا الطبي الشهير؟",["القانون في الطب","الحاوي","المناظر","الجبر والمقابلة"],0,"🩺 مخطوطة القانون"),
        E("c2","e10","أبو الجبر","الخوارزمي","وضع الخوارزمي أسس علم الجبر في كتابه «الجبر والمقابلة».","من اسمه اشتُقّ مصطلح «الخوارزميات» (Algorithm).","من العالم الذي اشتُقّ من اسمه مصطلح Algorithm؟",["الخوارزمي","ابن رشد","الرازي","البيروني"],0,"🔢 لوح الحساب"),
        E("c3","e10","علم البصريات","ابن الهيثم","أجرى ابن الهيثم تجارب على الضوء والرؤية في كتابه «المناظر».","يُعدّ من رواد المنهج التجريبي، وشرح أن الرؤية تكون بانعكاس الضوء إلى العين.","من مؤلف كتاب «المناظر» في البصريات؟",["ابن الهيثم","ابن النفيس","الفارابي","جابر بن حيان"],0,"🔭 عدسة ضوئية"),
        E("c4","e10","جامعة القرويين","فاطمة الفهرية","أسست فاطمة الفهرية مسجد القرويين في فاس، وصار مركزاً علمياً كبيراً.","تأسّس سنة 245 هـ (859م) وتُعدّ من أقدم الجامعات العاملة.","من أسّست جامعة القرويين؟",["فاطمة الفهرية","السيدة خديجة","رابعة العدوية","شجرة الدر"],0,"🎓 باب القرويين")
    ];

    // أحداث أضافها المطوّر من «وضع المطوّر ← أسئلة» (آلة الزمن)
    try {
        if (localStorage.getItem('ikh-dev-off') !== '1') {
            const dd = JSON.parse(localStorage.getItem('ikh-dev-data') || '{}');
            (Array.isArray(dd.qt) ? dd.qt : []).forEach(x => {
                if (!x || !x.id || !x.title || !x.question || !Array.isArray(x.options) || x.options.length < 2) return;
                if (!TM_ERAS.some(e => e.id === x.era) || TM_EVENTS_DB.some(e => e.id === x.id)) return;
                const ci = Math.min(Math.max(+x.correct || 0, 0), x.options.length - 1);
                TM_EVENTS_DB.push(E(x.id, x.era, x.title, x.character || '', x.story || '', x.fact || '', x.question,
                    x.options.map(String), ci, x.artifact || '📜 أثر'));
            });
        }
    } catch (e) {}

    const TM_LEVELS = [
        {exp:0,title:"المستكشف المبتدئ"},{exp:50,title:"الرحالة المتأمل"},{exp:150,title:"الباحث التاريخي"},
        {exp:300,title:"المؤرخ الإسلامي"},{exp:500,title:"الحافظ الأمين"},{exp:800,title:"عالم الزمان"},
        {exp:1200,title:"سفير التاريخ"},{exp:2000,title:"أسطورة الزمن"}
    ];

    // ===== الحالة =====
    const defState = () => ({xp:0,streak:0,best:0,discoveredEvents:[],missed:[],discoveredCharacters:[],museumArtifacts:[],newspaperLogs:[]});
    let S = defState(), cur = null, busy = false, lastEra = null;

    function load() {
        try { S = Object.assign(defState(), JSON.parse(localStorage.getItem(LS_KEY) || '{}')); } catch(e) { S = defState(); }
        S.discoveredEvents = S.discoveredEvents.filter(id => TM_EVENTS_DB.some(e => e.id === id));
    }
    function save() { try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch(e) {} }
    function log(text) {
        S.newspaperLogs.unshift({date:new Date().toLocaleDateString('ar-EG'), text});
        S.newspaperLogs.length = Math.min(S.newspaperLogs.length, 60);
    }
    const eraDone = id => TM_EVENTS_DB.filter(e => e.era === id && S.discoveredEvents.includes(e.id)).length;
    const eraTotal = id => TM_EVENTS_DB.filter(e => e.era === id).length;
    const isLocked = era => era.req && eraDone(era.req.era) < era.req.n;
    const level = () => TM_LEVELS.reduce((a,l) => S.xp >= l.exp ? l : a, TM_LEVELS[0]);
    const nextLevel = () => TM_LEVELS.find(l => l.exp > S.xp);
    const shuffle = a => { a = a.slice(); for (let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a; };

    // ===== الأنماط =====
    function injectStyles() {
        if ($('tm-styles')) return;
        const st = document.createElement('style'); st.id = 'tm-styles';
        st.textContent = `
        #tm-overlay{position:fixed;inset:0;height:100dvh;background:#050510;z-index:99999;display:none;flex-direction:column;color:#fff;overflow:hidden;font-family:'Tajawal',sans-serif;direction:rtl;padding-bottom:env(safe-area-inset-bottom,0)}
        #tm-overlay.active{display:flex;animation:tmFadeIn .5s ease}
        .tm-space-bg{position:absolute;inset:0;background:radial-gradient(circle at center,#1b0f3a 0%,#050510 100%);z-index:-2}
        .tm-stars{position:absolute;inset:0;z-index:-1;opacity:.7;background-image:radial-gradient(2px 2px at 20px 30px,#eee,transparent),radial-gradient(2px 2px at 60px 90px,#fff,transparent),radial-gradient(1.5px 1.5px at 120px 50px,#fde047,transparent),radial-gradient(2px 2px at 170px 130px,#fff,transparent);background-size:200px 200px;animation:starsMove 300s linear infinite}
        .tm-nav{display:flex;justify-content:space-between;align-items:center;padding:calc(12px + env(safe-area-inset-top,0)) 16px 12px;background:rgba(255,255,255,.05);backdrop-filter:blur(15px);border-bottom:1px solid rgba(255,255,255,.1)}
        .tm-nav-btn{background:rgba(255,255,255,.12);border:0;color:#fff;padding:8px 14px;border-radius:20px;font:700 .9rem 'Tajawal',sans-serif;cursor:pointer;display:flex;gap:5px;align-items:center}
        .tm-nav-btn:active{background:rgba(255,255,255,.25)}
        .tm-xpbar{height:5px;background:rgba(255,255,255,.15);border-radius:5px;margin-top:5px;overflow:hidden;width:120px}
        .tm-xpbar i{display:block;height:100%;background:linear-gradient(90deg,#fde047,#f59e0b);transition:width .6s}
        .tm-screen{display:none;flex:1;overflow-y:auto}
        .tm-home{align-items:center;justify-content:center;position:relative;flex-direction:column}
        .tm-portal-ring{width:290px;height:290px;border-radius:50%;border:2px dashed rgba(255,215,0,.5);position:absolute;animation:spinPortal 20s linear infinite;box-shadow:0 0 50px rgba(138,43,226,.5)}
        .tm-portal-ring::before{content:'';position:absolute;inset:-10px;border:2px solid rgba(0,255,255,.3);border-radius:50%;animation:spinPortalReverse 15s linear infinite}
        .tm-portal-core{width:240px;height:240px;border-radius:50%;background:radial-gradient(circle,rgba(255,255,255,.8),rgba(138,43,226,.6) 40%,transparent 80%);animation:pulseCore 3s ease-in-out infinite alternate;display:flex;align-items:center;justify-content:center;cursor:pointer;text-align:center}
        .tm-portal-text{font-family:'Aref Ruqaa',serif;font-size:2.2rem;text-shadow:0 0 20px #000}
        .tm-stats{position:absolute;bottom:6%;display:flex;gap:18px;font-size:.85rem;opacity:.85}
        .tm-eras{flex-wrap:wrap;justify-content:center;gap:14px;padding:20px 14px;align-content:flex-start}
        .tm-era-card{width:calc(50% - 10px);max-width:170px;background:rgba(25,20,40,.6);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.1);border-radius:20px;padding:16px 10px;text-align:center;cursor:pointer;position:relative;transition:.3s}
        .tm-era-card:active{transform:scale(.97)}
        .tm-era-card.done{border-color:#10b981}
        .tm-era-card.locked{opacity:.55;filter:grayscale(.8)}
        .tm-era-icon{font-size:2.6rem;margin-bottom:6px}
        .tm-era-title{font-weight:800;font-size:.9rem;color:#fde047}
        .tm-era-desc{font-size:.7rem;margin-top:4px;opacity:.75}
        .tm-era-prog{font-size:.75rem;margin-top:8px;font-weight:700}
        .tm-era-prog i{display:block;height:4px;border-radius:4px;background:rgba(255,255,255,.15);margin-top:4px;overflow:hidden}
        .tm-era-prog b{display:block;height:100%;background:#10b981}
        .tm-era-lock{font-size:.7rem;margin-top:6px;color:#fca5a5}
        .tm-event{flex-direction:column;padding:16px}
        .tm-glass-box{background:rgba(20,20,35,.75);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.1);border-radius:24px;padding:22px;margin-bottom:16px}
        .tm-story-title{font-family:'Aref Ruqaa',serif;font-size:1.8rem;color:#fde047;text-align:center;margin-bottom:12px;border-bottom:1px dashed rgba(255,255,255,.2);padding-bottom:8px}
        .tm-story-text{font-size:1.05rem;line-height:1.9;color:#e2e8f0}
        .tm-options-grid{display:flex;flex-direction:column;gap:10px;margin-top:16px}
        .tm-tf{flex-direction:row}.tm-tf .tm-option-btn{flex:1;text-align:center}
        .tm-option-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.2);color:#fff;padding:14px;border-radius:14px;font:700 1rem 'Tajawal',sans-serif;cursor:pointer;text-align:right;transition:.3s}
        .tm-option-btn.correct{background:rgba(16,185,129,.4);border-color:#10b981}
        .tm-option-btn.wrong{background:rgba(239,68,68,.4);border-color:#ef4444}
        .tm-warp{position:fixed;inset:0;background:#fff;z-index:100000;opacity:0;pointer-events:none}
        .tm-warp.active{pointer-events:all;animation:warpFlash 1.2s ease forwards}
        .tm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(105px,1fr));gap:12px}
        .tm-artifact{background:rgba(255,215,0,.1);border:1px solid rgba(255,215,0,.3);border-radius:14px;padding:12px;text-align:center;font-size:.85rem}
        .tm-artifact.empty{opacity:.35;border-style:dashed}
        .tm-news-item{padding:10px 0;border-bottom:1px solid rgba(255,255,255,.1);font-size:.9rem}
        .tm-news-date{color:#fde047;font-size:.7rem;font-weight:700}
        .tm-toast{position:absolute;bottom:calc(24px + env(safe-area-inset-bottom,0));left:50%;transform:translateX(-50%);background:rgba(0,0,0,.85);border:1px solid #fde047;padding:10px 18px;border-radius:14px;font-weight:700;font-size:.9rem;opacity:0;pointer-events:none;transition:opacity .3s;max-width:88%;text-align:center;z-index:5}
        .tm-toast.show{opacity:1}
        @keyframes tmFadeIn{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}
        @keyframes spinPortal{to{transform:rotate(360deg)}}
        @keyframes spinPortalReverse{to{transform:rotate(-360deg)}}
        @keyframes pulseCore{from{transform:scale(.95);box-shadow:0 0 20px rgba(255,255,255,.5)}to{transform:scale(1.05);box-shadow:0 0 60px rgba(255,255,255,.8)}}
        @keyframes starsMove{to{background-position:-4000px 2000px}}
        @keyframes warpFlash{0%{opacity:0}35%,65%{opacity:1}100%{opacity:0}}`;
        document.head.appendChild(st);
    }

    function injectHTML() {
        if ($('tm-overlay')) return;
        document.body.insertAdjacentHTML('beforeend', `
        <div id="tm-overlay" role="dialog" aria-label="آلة الزمن الإسلامية">
            <div class="tm-space-bg"></div><div class="tm-stars"></div>
            <div class="tm-nav">
                <button class="tm-nav-btn" onclick="window.closeTimeMachine()">✖ خروج</button>
                <div style="text-align:center">
                    <div id="tm-level-title" style="color:#fde047;font-weight:700;font-size:.9rem"></div>
                    <div style="font-size:.75rem;opacity:.85"><span id="tm-xp">0</span> XP</div>
                    <div class="tm-xpbar" style="margin-inline:auto"><i id="tm-xpfill"></i></div>
                </div>
                <div style="display:flex;gap:6px">
                    <button class="tm-nav-btn" onclick="window.showTMMuseum()" aria-label="المتحف">🏛</button>
                    <button class="tm-nav-btn" onclick="window.showTMNewspaper()" aria-label="الصحيفة">📰</button>
                </div>
            </div>
            <div id="tm-screen-home" class="tm-screen tm-home">
                <h2 style="position:absolute;top:8%;font-family:'Aref Ruqaa',serif;font-size:2rem;text-shadow:0 0 10px #fff">آلة الزمن الإسلامية</h2>
                <div class="tm-portal-ring"></div>
                <div class="tm-portal-core" onclick="window.travelToEras()"><div class="tm-portal-text">سافر عبر<br>الزمن</div></div>
                <div class="tm-stats" id="tm-stats"></div>
            </div>
            <div id="tm-screen-eras" class="tm-screen tm-eras"></div>
            <div id="tm-screen-event" class="tm-screen tm-event">
                <button class="tm-nav-btn" style="align-self:flex-start;margin-bottom:12px" onclick="window.travelToEras()">🔙 العصور</button>
                <div class="tm-glass-box" id="tm-story-box">
                    <div class="tm-story-title" id="tm-e-title"></div>
                    <div style="text-align:center;margin-bottom:12px;color:#10b981;font-weight:700">👤 <span id="tm-e-character"></span></div>
                    <div class="tm-story-text" id="tm-e-story"></div>
                    <button class="tm-nav-btn" style="width:100%;justify-content:center;margin-top:16px;background:rgba(255,215,0,.3)" onclick="window.tmShowQuestion()">🔍 اكتشف السر (السؤال)</button>
                </div>
                <div class="tm-glass-box" id="tm-question-box" style="display:none">
                    <h3 style="font-size:1.15rem;line-height:1.7" id="tm-e-question"></h3>
                    <div class="tm-options-grid" id="tm-e-options"></div>
                </div>
                <div class="tm-glass-box" id="tm-fact-box" style="display:none;border-color:#fde047">
                    <h3 id="tm-result" style="margin-bottom:8px"></h3>
                    <h3 style="color:#fde047;margin-bottom:8px">📖 هل تعلم؟</h3>
                    <p class="tm-story-text" id="tm-e-fact" style="font-size:1rem"></p>
                    <button class="tm-nav-btn" style="width:100%;justify-content:center;margin-top:16px;background:rgba(16,185,129,.5)" onclick="window.tmNext()">➡️ الحدث التالي</button>
                    <button class="tm-nav-btn" style="width:100%;justify-content:center;margin-top:8px" onclick="window.travelToEras()">🔙 العودة للعصور</button>
                </div>
            </div>
            <div id="tm-screen-extra" class="tm-screen tm-event">
                <button class="tm-nav-btn" style="align-self:flex-start;margin-bottom:12px" onclick="window.backToHome()">🔙 الرئيسية</button>
                <div class="tm-glass-box" id="tm-extra-content"></div>
            </div>
            <div class="tm-warp" id="tm-warp"></div>
            <div class="tm-toast" id="tm-toast"></div>
        </div>`);
        const home = $('view-home');
        if (home && !$('tm-entry-card')) {
            home.insertAdjacentHTML('afterbegin', `
            <div id="tm-entry-card" class="card ripple-effect" onclick="window.openTimeMachine()" style="background:linear-gradient(135deg,#1b0f3a,#050510);color:#fff;border:1px solid rgba(138,43,226,.3);padding:25px;margin-bottom:20px;cursor:pointer;position:relative;overflow:hidden">
                <div style="position:absolute;right:-20px;bottom:-20px;font-size:8rem;opacity:.1;transform:rotate(15deg)">🕰️</div>
                <h3 style="font-family:'Aref Ruqaa',serif;font-size:2rem;margin-bottom:5px;color:#fde047">آلة الزمن الإسلامية 🕰️</h3>
                <p style="font-size:.9rem;opacity:.9;max-width:80%">سافر عبر التاريخ الإسلامي، اكتشف الأحداث والشخصيات، واجمع آثار المتحف.</p>
            </div>`);
        }
    }

    // ===== المحرك =====
    function toast(msg) {
        const t = $('tm-toast'); t.textContent = msg; t.classList.add('show');
        clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove('show'), 2600);
    }
    function header() {
        const lv = level(), nx = nextLevel();
        $('tm-xp').textContent = S.xp;
        $('tm-level-title').textContent = lv.title;
        $('tm-xpfill').style.width = (nx ? Math.round((S.xp - lv.exp) / (nx.exp - lv.exp) * 100) : 100) + '%';
        $('tm-stats').innerHTML = `<span>📜 ${S.discoveredEvents.length}/${TM_EVENTS_DB.length}</span><span>🔥 ${S.streak}</span><span>🏆 ${S.best}</span>`;
    }
    function screen(id) {
        ['home','eras','event','extra'].forEach(n => $('tm-screen-' + n).style.display = 'none');
        $('tm-screen-' + id).style.display = 'flex';
        $('tm-screen-' + id).scrollTop = 0;
    }
    function warp(cb) {
        if (busy) return; busy = true;
        if (navigator.vibrate) navigator.vibrate([60, 40, 120]);
        const w = $('tm-warp'); w.classList.add('active');
        setTimeout(() => { cb(); header(); }, 500);
        setTimeout(() => { w.classList.remove('active'); busy = false; }, 1200);
    }

    window.openTimeMachine = () => { load(); header(); $('tm-overlay').classList.add('active'); screen('home'); };
    window.closeTimeMachine = () => $('tm-overlay').classList.remove('active');
    window.backToHome = () => { header(); screen('home'); };

    function renderEras() {
        $('tm-screen-eras').innerHTML = TM_ERAS.map(era => {
            const lock = isLocked(era), d = eraDone(era.id), t = eraTotal(era.id);
            const need = lock ? TM_ERAS.find(x => x.id === era.req.era).name : '';
            return `<div class="tm-era-card ${lock ? 'locked' : ''} ${d === t ? 'done' : ''}" onclick="window.enterEra('${era.id}')">
                <div class="tm-era-icon">${lock ? '🔒' : era.icon}</div>
                <div class="tm-era-title">${esc(era.name)}</div>
                <div class="tm-era-desc">${esc(era.desc)}</div>
                ${lock ? `<div class="tm-era-lock">أكمل ${era.req.n===2?'حدثين':era.req.n+' أحداث'} من «${esc(need)}» (${eraDone(era.req.era)}/${era.req.n})</div>`
                       : `<div class="tm-era-prog">${d}/${t}${d === t ? ' ✅' : ''}<i><b style="width:${t ? d / t * 100 : 0}%"></b></i></div>`}
            </div>`;
        }).join('');
    }
    window.travelToEras = () => {
        if ($('tm-screen-eras').style.display === 'flex' && !busy) { renderEras(); return; }
        warp(() => { renderEras(); screen('eras'); });
    };

    function pickEvent(eraId) {
        const pool = TM_EVENTS_DB.filter(e => e.era === eraId && !S.discoveredEvents.includes(e.id));
        if (!pool.length) return null;
        const fresh = pool.filter(e => !S.missed.includes(e.id));
        const src = fresh.length ? fresh : pool;
        return src[Math.floor(Math.random() * src.length)];
    }
    window.enterEra = eraId => {
        const era = TM_ERAS.find(e => e.id === eraId);
        if (isLocked(era)) { toast(`🔒 أكمل ${era.req.n===2?'حدثين':era.req.n+' أحداث'} من «${TM_ERAS.find(x => x.id === era.req.era).name}» أولاً`); return; }
        const ev = pickEvent(eraId);
        if (!ev) { toast('🎉 أكملت هذا العصر! جرّب عصراً آخر.'); return; }
        startEvent(ev, true);
    };
    function startEvent(ev, withWarp) {
        cur = ev; lastEra = ev.era;
        const show = () => {
            $('tm-story-box').style.display = 'block';
            $('tm-question-box').style.display = 'none';
            $('tm-fact-box').style.display = 'none';
            $('tm-e-title').textContent = ev.title;
            $('tm-e-character').textContent = ev.character;
            $('tm-e-story').textContent = ev.story;
            screen('event');
        };
        withWarp ? warp(show) : show();
    }
    window.tmShowQuestion = () => {
        $('tm-story-box').style.display = 'none';
        $('tm-question-box').style.display = 'block';
        $('tm-e-question').textContent = cur.question;
        const tf = cur.options.length === 2;
        const opts = tf ? cur.options.map((t, i) => ({t, i})) : shuffle(cur.options.map((t, i) => ({t, i})));
        const box = $('tm-e-options');
        box.className = 'tm-options-grid' + (tf ? ' tm-tf' : '');
        box.innerHTML = opts.map(o => `<button class="tm-option-btn" data-i="${o.i}">${esc(o.t)}</button>`).join('');
        box.querySelectorAll('button').forEach(b => b.onclick = () => answer(+b.dataset.i, b));
    };
    function answer(i, btn) {
        const ok = i === cur.correct;
        const btns = $('tm-e-options').querySelectorAll('button');
        btns.forEach(b => { b.style.pointerEvents = 'none'; if (+b.dataset.i === cur.correct) b.classList.add('correct'); });
        let res;
        if (ok) {
            const bonus = S.streak >= 2 ? 10 : 0;
            S.xp += 25 + bonus; S.streak++; S.best = Math.max(S.best, S.streak);
            S.missed = S.missed.filter(x => x !== cur.id);
            if (!S.discoveredEvents.includes(cur.id)) S.discoveredEvents.push(cur.id);
            if (!S.discoveredCharacters.includes(cur.character)) S.discoveredCharacters.push(cur.character);
            if (!S.museumArtifacts.includes(cur.id)) S.museumArtifacts.push(cur.id);
            log(`اكتشفت حدث «${cur.title}» وحصلت على ${cur.artifact}`);
            const era = TM_ERAS.find(e => e.id === cur.era);
            if (eraDone(era.id) === eraTotal(era.id)) log(`🏅 أتممت عصر «${era.name}»`);
            TM_ERAS.filter(e => e.req && e.req.era === cur.era && eraDone(cur.era) === e.req.n).forEach(e => { log(`🔑 فُتح عصر «${e.name}»`); toast(`🔑 فُتح عصر «${e.name}»`); });
            if (navigator.vibrate) navigator.vibrate([50, 50, 50]);
            res = `<span style="color:#10b981">✅ أحسنت! +${25 + bonus} XP${bonus ? ' (مكافأة التتابع 🔥)' : ''}<br>حصلت على أثر: ${esc(cur.artifact)}</span>`;
        } else {
            btn.classList.add('wrong'); S.streak = 0;
            if (!S.missed.includes(cur.id)) S.missed.push(cur.id);
            if (navigator.vibrate) navigator.vibrate(120);
            res = `<span style="color:#f87171">❌ الإجابة الصحيحة: <b style="color:#10b981">${esc(cur.options[cur.correct])}</b><br>ستعود إليك القصة لاحقاً لتنالها.</span>`;
        }
        save(); header();
        setTimeout(() => {
            $('tm-question-box').style.display = 'none';
            $('tm-result').innerHTML = res;
            $('tm-e-fact').textContent = cur.fact;
            $('tm-fact-box').style.display = 'block';
            $('tm-screen-event').scrollTop = 0;
        }, 1100);
    }
    window.tmNext = () => {
        const ev = pickEvent(lastEra);
        if (ev) startEvent(ev, true);
        else { toast('🎉 أكملت هذا العصر!'); window.travelToEras(); }
    };

    // ===== المتحف والصحيفة =====
    window.showTMMuseum = () => {
        const arts = TM_EVENTS_DB.map(e => S.museumArtifacts.includes(e.id)
            ? `<div class="tm-artifact">${esc(e.artifact)}<br><small style="opacity:.7">${esc(e.character)}</small></div>`
            : `<div class="tm-artifact empty">❔<br><small>أثر مجهول</small></div>`).join('');
        const chars = S.discoveredCharacters.length
            ? S.discoveredCharacters.map(c => `<div class="tm-artifact">👤<br><b>${esc(c)}</b></div>`).join('')
            : "<p style='text-align:center;opacity:.7'>لم تكتشف شخصيات بعد.</p>";
        $('tm-extra-content').innerHTML = `
            <h2 class="tm-story-title">🏛 المتحف</h2>
            <h3 style="margin:10px 0">الآثار (${S.museumArtifacts.length}/${TM_EVENTS_DB.length})</h3><div class="tm-grid">${arts}</div>
            <h3 style="margin:20px 0 10px">الشخصيات (${S.discoveredCharacters.length})</h3><div class="tm-grid">${chars}</div>`;
        screen('extra');
    };
    window.showTMNewspaper = () => {
        const news = S.newspaperLogs.length
            ? S.newspaperLogs.map(n => `<div class="tm-news-item"><span class="tm-news-date">${esc(n.date)}</span><br>${esc(n.text)}</div>`).join('')
            : "<p style='text-align:center;opacity:.7'>لا توجد أخبار في صحيفة الزمن بعد.</p>";
        $('tm-extra-content').innerHTML = `<h2 class="tm-story-title">📰 صحيفة الزمن</h2>${news}`;
        screen('extra');
    };

    // ===== الإقلاع =====
    function boot() {
        try { load(); injectStyles(); injectHTML(); } catch (e) { console.error('Time Machine Error:', e); }
    }
    document.readyState === 'loading' ? window.addEventListener('DOMContentLoaded', boot) : boot();
})();
