(function(){

const canvas=document.createElement("canvas");
canvas.id="spiritualSky";

Object.assign(canvas.style,{
position:"fixed",
top:"0",
left:"0",
width:"100%",
height:"100%",
zIndex:"-9999",
pointerEvents:"none"
});

document.body.prepend(canvas);

const ctx=canvas.getContext("2d");

function resize(){
canvas.width=window.innerWidth;
canvas.height=window.innerHeight;
}
resize();
window.addEventListener("resize",resize);

const stars=[];
for(let i=0;i<200;i++){
stars.push({
x:Math.random()*window.innerWidth,
y:Math.random()*window.innerHeight,
r:Math.random()*2,
a:Math.random(),
speed:0.005+Math.random()*0.02
});
}

const clouds=[];
for(let i=0;i<8;i++){
clouds.push({
x:Math.random()*window.innerWidth,
y:50+Math.random()*250,
size:120+Math.random()*180,
speed:0.1+Math.random()*0.3
});
}

function getScene(){

const h=new Date().getHours();

if(h>=2 && h<4) return "tahajjud";
if(h>=4 && h<6) return "fajr";
if(h>=6 && h<8) return "shurooq";
if(h>=8 && h<12) return "duha";
if(h>=12 && h<15) return "dhuhr";
if(h>=15 && h<18) return "asr";
if(h>=18 && h<20) return "maghrib";

return "isha";
}

function skyGradient(scene){

switch(scene){

case "tahajjud":
return ["#020617","#0f172a"];

case "fajr":
return ["#1e3a8a","#f9a8d4"];

case "shurooq":
return ["#fb923c","#fde68a"];

case "duha":
return ["#38bdf8","#e0f2fe"];

case "dhuhr":
return ["#60a5fa","#ffffff"];

case "asr":
return ["#f59e0b","#fef3c7"];

case "maghrib":
return ["#dc2626","#7c3aed"];

default:
return ["#020617","#1e293b"];
}
}

function drawSky(scene){

const g=ctx.createLinearGradient(
0,0,0,canvas.height
);

const colors=skyGradient(scene);

g.addColorStop(0,colors[0]);
g.addColorStop(1,colors[1]);

ctx.fillStyle=g;
ctx.fillRect(0,0,canvas.width,canvas.height);
}

function drawStars(scene){

let opacity=0;

if(scene==="tahajjud") opacity=1;
if(scene==="isha") opacity=1;
if(scene==="maghrib") opacity=.3;
if(scene==="fajr") opacity=.2;

if(opacity===0) return;

stars.forEach(s=>{

s.a+=s.speed;

ctx.beginPath();

ctx.fillStyle=
`rgba(255,255,255,${
opacity*(0.5+Math.sin(s.a)*0.5)
})`;

ctx.arc(s.x,s.y,s.r,0,Math.PI*2);

ctx.fill();

});
}

function drawMoon(scene){

if(
scene!=="isha" &&
scene!=="tahajjud" &&
scene!=="fajr"
)return;

ctx.beginPath();

ctx.fillStyle="#fff8dc";

ctx.arc(
canvas.width-120,
120,
40,
0,
Math.PI*2
);

ctx.fill();

ctx.beginPath();

ctx.fillStyle="rgba(0,0,0,.15)";

ctx.arc(
canvas.width-105,
110,
40,
0,
Math.PI*2
);

ctx.fill();
}

function drawSun(scene){

if(
scene==="isha" ||
scene==="tahajjud"
)return;

let y=120;

if(scene==="shurooq") y=180;
if(scene==="maghrib") y=250;

ctx.beginPath();

ctx.fillStyle="#FFD54F";

ctx.shadowBlur=50;
ctx.shadowColor="#FFD54F";

ctx.arc(
canvas.width-130,
y,
45,
0,
Math.PI*2
);

ctx.fill();

ctx.shadowBlur=0;
}

function drawClouds(scene){

if(
scene==="isha" ||
scene==="tahajjud"
)return;

clouds.forEach(c=>{

c.x+=c.speed;

if(c.x>canvas.width+200)
c.x=-300;

ctx.beginPath();

ctx.fillStyle=
"rgba(255,255,255,.15)";

ctx.ellipse(
c.x,
c.y,
c.size,
c.size*.35,
0,
0,
Math.PI*2
);

ctx.fill();

});
}

function animate(){

const scene=getScene();

drawSky(scene);

drawStars(scene);

drawClouds(scene);

drawSun(scene);

drawMoon(scene);

requestAnimationFrame(animate);
}

animate();

})();
