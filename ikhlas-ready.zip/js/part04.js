/**
 * 💎 محرك الهوية الزجاجية والانتقالات السينمائية (Glassmorphism & Cinematic Transitions)
 * الإصدار: 2026 | مخصص لتطبيق "إخلاص"
 * الوظيفة: تحويل الواجهة لزجاج عميق، مسحات ضوئية، وانتقالات صفحات احترافية.
 */
(function initGlassmorphismEngine() {
    'use strict';

    // =========================================================================
    // 1. حقن الأنماط الزجاجية العميقة والمؤثرات الضوئية
    // =========================================================================
    function injectAdvancedGlassCSS() {
        if (document.getElementById('advanced-glass-css')) return;
        
        const style = document.createElement('style');
        style.id = 'advanced-glass-css';
        style.innerHTML = `
            /* v22: الزجاج والبطاقات في css/smooth.css. هنا فقط دخول الشاشة بانزلاق خفيف دون opacity ودون will-change
               (opacity/will-change على الحاوية تجعل التمويه الخلفي للبطاقات يرى خلفية فارغة فيبدو الزجاج مسطّحاً ثم يقفز عند انتهاء الحركة) */
            .view-section { display: none; }
            .view-section.active { display: block; animation: vs-in .26s cubic-bezier(.2,.8,.2,1) both; }
            @keyframes vs-in { from { transform: translate3d(0, 10px, 0); } to { transform: none; } }
        `;
        document.head.appendChild(style);
    }

    // =========================================================================
    // 2. ترقية دالة الانتقال بين الصفحات (Cinematic SwitchView Override)
    // =========================================================================
    function upgradePageTransitions() {
        // التحقق من وجود دالة التنقل الأصلية لتجاوزها وترقيتها
        if (typeof window.switchView === 'function' && !window.isSwitchViewUpgraded) {
            const originalSwitchView = window.switchView;
            
            // إعادة تعريف الدالة بحقن ميكانيكية الـ Exit Animation
            window.switchView = function(viewId) {
                const cur = document.querySelector('.view-section.active');
                if (cur && cur.id === `view-${viewId}`) return;
                originalSwitchView(viewId);
            };
            
            window.isSwitchViewUpgraded = true; // منع التكرار
        }
    }

    // =========================================================================
    // التشغيل التلقائي للمحرك فور جهوزية الـ DOM
    // =========================================================================
    window.addEventListener('DOMContentLoaded', () => {
        try {
            injectAdvancedGlassCSS();
            // تأخير بسيط لضمان تحميل دالة switchView الأصلية قبل ترقيتها
            setTimeout(upgradePageTransitions, 100); 
            console.log("💎 تم تشغيل محرك الهوية الزجاجية والانتقالات السينمائية بنجاح.");
        } catch (err) {
            console.error("خطأ في تشغيل محرك الزجاج: ", err);
        }
    });

})();
