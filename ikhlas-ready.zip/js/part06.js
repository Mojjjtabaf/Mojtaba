/**
 * 🧭 محرك القبلة المتوهجة والاهتزاز الذكي (Glowing Qibla & Smart Haptics Engine)
 * الإصدار: 2026 | مخصص لتطبيق "إخلاص"
 */
(function initGlowingQiblaEngine() {
    'use strict';

    // 1. حقن الأنماط الفيزيائية للتوهج والنبض
    function injectQiblaCSS() {
        if (document.getElementById('qibla-glow-css')) return;
        
        const style = document.createElement('style');
        style.id = 'qibla-glow-css';
        style.innerHTML = `
            /* انتقال ناعم للبوصلة بأكملها */
            #compass-outer {
                transition: border-color 0.4s ease, box-shadow 0.4s ease, transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            }

            /* حالة التطابق التام مع زاوية الكعبة (التوهج والنبض) */
            #compass-outer.aligned-qibla {
                border-color: #10b981 !important; /* أخضر زمردي */
                box-shadow: 
                    0 0 60px rgba(16, 185, 129, 0.5), /* هالة خارجية مشعة */
                    inset 0 0 25px rgba(16, 185, 129, 0.3), /* توهج داخلي */
                    0 15px 35px rgba(0, 0, 0, 0.2) !important;
                animation: qibla-divine-pulse 1.5s infinite alternate ease-in-out;
            }

            @keyframes qibla-divine-pulse {
                0% { transform: scale(1); filter: brightness(1); }
                100% { transform: scale(1.04); filter: brightness(1.2); }
            }

            /* نص الحالة عند التطابق */
            .qibla-success-text {
                color: #10b981 !important;
                text-shadow: 0 2px 10px rgba(16, 185, 129, 0.3);
                transform: scale(1.05);
                transition: all 0.3s ease;
            }
        `;
        document.head.appendChild(style);
    }

    // 2. منطق البوصلة والربط بالمستشعرات
    function bindCompassSensors() {
        const btn = document.getElementById('enable-compass');
        if (btn) {
            btn.onclick = () => {
                // طلب إذن مستشعرات الحركة (إلزامي في iOS الحديث وأندرويد)
                if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
                    DeviceOrientationEvent.requestPermission().then(state => {
                        if (state === 'granted') { 
                            window.addEventListener('deviceorientation', processCompassData, true); 
                            btn.style.display = 'none'; 
                        }
                    });
                } else { 
                    window.addEventListener('deviceorientation', processCompassData, true); 
                    btn.style.display = 'none'; 
                }
            };
        }
    }

    // المتغيرات للتحكم في الاهتزاز ومنع التكرار المزعج
    let isCurrentlyAligned = false; 
    
    // 3. معالجة البيانات الفلكية وإطلاق النبضات
    function processCompassData(e) {
        let alpha = e.alpha; 
        
        // التوافق مع أجهزة آبل
        if (e.webkitCompassHeading) {
            alpha = 360 - e.webkitCompassHeading;
        }
        if (alpha === null) return; 

        // زاوية القبلة (افتراضياً 65 درجة أو يتم جلبها برمجياً حسب الإحداثيات)
        const qiblaAngle = 65; 
        
        const rose = document.getElementById('compass-rose');
        if (rose) rose.style.transform = `rotate3d(0, 0, 1, ${-alpha}deg)`;
        
        const pointer = document.getElementById('qibla-pointer');
        if (pointer) pointer.style.transform = `translate3d(-50%, -100%, 0) rotate3d(0, 0, 1, ${(qiblaAngle - alpha)}deg)`;
        
        // حساب الفارق بين اتجاه الهاتف وزاوية القبلة بذكاء (مع معالجة التفاف الدائرة 360)
        let diff = Math.abs(alpha - qiblaAngle);
        if (diff > 180) diff = 360 - diff; 
        
        const outerCompass = document.getElementById('compass-outer');
        const qiblaText = document.getElementById('qibla-text');
        
        // التوافق إذا كان الانحراف أقل من 4 درجات (دقة عالية)
        if (diff <= 4) {
            if (!isCurrentlyAligned) {
                // المستخدم وصل للقبلة الآن!
                isCurrentlyAligned = true;
                
                if (outerCompass) outerCompass.classList.add('aligned-qibla');
                
                if (qiblaText) {
                    qiblaText.innerHTML = '🟢 أنت الآن في مواجهة الكعبة المشرفة 🕋';
                    qiblaText.classList.add('qibla-success-text');
                }
                
                // إطلاق اهتزاز مميز (نبضتين سريعتين ثم نبضة تأكيدية)
                if (navigator.vibrate) {
                    navigator.vibrate([40, 50, 40, 50, 120]); 
                }
            }
        } else {
            // المستخدم انحرف عن القبلة
            if (isCurrentlyAligned) {
                isCurrentlyAligned = false;
                
                if (outerCompass) outerCompass.classList.remove('aligned-qibla');
                
                if (qiblaText) {
                    qiblaText.innerText = 'قم بتدوير الهاتف حتى يتطابق المؤشر مع القبلة';
                    qiblaText.classList.remove('qibla-success-text');
                }
            }
        }
    }

    // التشغيل
    window.addEventListener('DOMContentLoaded', () => {
        try {
            injectQiblaCSS();
            bindCompassSensors();
            console.log("🧭 تم إقلاع محرك القبلة المتوهجة والاهتزاز الذكي بنجاح.");
        } catch (err) {
            console.error("خطأ في تشغيل محرك القبلة: ", err);
        }
    });

})();
