/**
 * 📱 محرك النظام الأصلي (Native Capacitor Engine)
 * الإصدار 6.0.0.1 | كتابة وبرمجة: مجتبى صديق
 * لإدارة الصلاحيات الحقيقية، الموقع الدقيق، والإشعارات المجدولة في الخلفية
 */
(async function initNativeEngine() {
    'use strict';

    // التأكد من أن التطبيق يعمل داخل بيئة Capacitor (تطبيق أصلي) وليس في المتصفح
    const isNative = window.Capacitor && window.Capacitor.isNative;

    window.NativeCore = {
        // 1. طلب الصلاحيات بقوة النظام
        async requestPermissions() {
            if (!isNative) {
                console.log("التطبيق يعمل في المتصفح، سيتم استخدام صلاحيات الويب.");
                return;
            }

            try {
                // طلب صلاحية الإشعارات
                if (Capacitor.Plugins.LocalNotifications) {
                    await Capacitor.Plugins.LocalNotifications.requestPermissions();
                    console.log("🔔 تم طلب صلاحية الإشعارات الأصلية.");
                }
                
                // طلب صلاحية الموقع الدقيق
                if (Capacitor.Plugins.Geolocation) {
                    await Capacitor.Plugins.Geolocation.requestPermissions();
                    console.log("📍 تم طلب صلاحية الموقع الأصلي.");
                }
            } catch (e) {
                console.error("خطأ في طلب الصلاحيات الأصلية:", e);
            }
        },

        // 2. جلب الموقع عبر حساس الـ GPS الخاص بالهاتف
        async getCurrentLocation() {
            if (isNative && Capacitor.Plugins.Geolocation) {
                try {
                    const position = await Capacitor.Plugins.Geolocation.getCurrentPosition({
                        enableHighAccuracy: true
                    });
                    return { lat: position.coords.latitude, lng: position.coords.longitude };
                } catch (e) {
                    console.error("تعذر جلب الموقع الأصلي:", e);
                    return null;
                }
            }
            return null; // سيتم الاعتماد على دالة الويب السابقة كبديل إذا فشل
        },

        // 3. جدولة إشعار الأذان ليعمل في الخلفية (دقيق 100%)
        async scheduleAdhanNotification(id, title, body, dateObject) {
            if (!isNative || !Capacitor.Plugins.LocalNotifications) return;

            try {
                await Capacitor.Plugins.LocalNotifications.schedule({
                    notifications: [
                        {
                            id: id, // رقم فريد للإشعار (مثال: 1 للفجر، 2 للظهر)
                            title: title,
                            body: body,
                            schedule: { at: dateObject }, // كائن Date يمثل وقت الصلاة بالضبط
                            sound: null, // سيستخدم صوت التنبيه الافتراضي للنظام
                            smallIcon: "ic_stat_icon", // الأيقونة الشفافة للإشعارات
                            actionTypeId: "",
                            extra: null
                        }
                    ]
                });
                console.log(`تمت جدولة إشعار أصلي: ${title} ليوم ${dateObject}`);
            } catch (e) {
                console.error("خطأ في جدولة الإشعار الأصلي:", e);
            }
        }
    };

    // إطلاق طلب الصلاحيات بعد تحميل التطبيق بثوانٍ لضمان عدم إزعاج المستخدم فور الدخول
    window.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => {
            window.NativeCore.requestPermissions();
        }, 3000);
    });

})();
