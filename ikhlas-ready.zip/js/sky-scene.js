/* مشهد السماء الحي: خلفية كاملة تتبع مواقيت الصلاة والطقس.
   - ألوان السماء تتدرج بين الفجر والشروق والظهر والعصر والمغرب والعشاء
   - شمس زجاجية تقطع قوسها من الشروق إلى الغروب، وقمر بطوره الحقيقي ليلاً، ونجوم ليلاً
   - سحب ومطر وضباب وثلج وبرق حسب الطقس (Open-Meteo، بلا مفتاح، مع تخزين محلي ويعمل دون إنترنت)
   اختبار يدوي من الكونسول:  SkyScene.preview({time:'18:40', weather:'rain'})  ثم  SkyScene.preview() للعودة */
(function(){
'use strict';
var FLIP=true; /* الشروق يميناً والغروب يساراً ليوافق اتجاه الواجهة العربية؛ اجعلها false لعكسه */
var clamp=function(x,a,b){return Math.min(b,Math.max(a,x));};
var mix=function(a,b,t){return a.map(function(v,i){return v+(b[i]-v)*t;});};
var rgb=function(c){return Math.round(c[0])+','+Math.round(c[1])+','+Math.round(c[2]);};
var css=function(c){return 'rgb('+rgb(c)+')';};
var mins=function(s){var p=String(s).split(':');return (+p[0])*60+(+p[1]);};

/* مسار السحابة (صندوق 260×100) */
var CLOUD='M30 92C8 92 4 62 26 56C24 36 52 28 66 42C74 14 118 6 138 30C156 18 196 22 200 50C232 46 252 70 232 86C228 91 222 92 214 92Z';

/* مفاتيح الألوان: [إزاحة، قمة، وسط، أفق، إضاءة lt، دفء wm] — الإزاحة بالدقائق من وقت الصلاة */
function keys(T){
  var K=[
   [T.Fajr-35,  [6,10,28],[12,20,52],[22,34,78],        0,  0],
   [T.Fajr,     [20,30,78],[60,70,130],[120,110,160],   .14,.2],
   [T.Sunrise-10,[52,92,170],[170,130,170],[255,150,100],.5, .9],
   [T.Sunrise+25,[60,140,220],[140,195,240],[255,200,140],.9,.3],
   [T.Dhuhr,    [24,118,230],[80,170,245],[170,215,250], 1,  0],
   [T.Asr,      [40,125,215],[120,180,235],[230,215,185],.95,.1],
   [T.Maghrib-35,[70,110,185],[220,170,140],[255,185,100],.8,.5],
   [T.Maghrib,  [60,70,150],[200,100,130],[255,120,70],  .45,1],
   [T.Isha,     [24,28,78],[60,50,110],[120,70,110],     .15,.3],
   [T.Isha+70,  [6,10,28],[12,20,52],[22,34,78],         0,  0]
  ];
  for(var i=1;i<K.length;i++)while(K[i][0]<=K[i-1][0])K[i][0]+=1440;
  var f=K[0].slice();f[0]=K[0][0]+1440;K.push(f);
  return K;
}
function sample(K,now){
  var n=now;while(n<K[0][0])n+=1440;while(n>=K[K.length-1][0])n-=1440;
  if(n<K[0][0])n+=1440;
  for(var i=0;i<K.length-1;i++){
    if(n>=K[i][0]&&n<K[i+1][0]){
      var t=(n-K[i][0])/(K[i+1][0]-K[i][0]);t=t*t*(3-2*t);
      return{top:mix(K[i][1],K[i+1][1],t),mid:mix(K[i][2],K[i+1][2],t),hor:mix(K[i][3],K[i+1][3],t),lt:K[i][4]+(K[i+1][4]-K[i][4])*t,wm:K[i][5]+(K[i+1][5]-K[i][5])*t};
    }
  }
  return{top:K[0][1],mid:K[0][2],hor:K[0][3],lt:0,wm:0};
}

/* أوقات الصلاة: من التطبيق، وإلا قيم افتراضية */
function prayerMins(){
  var T=null;try{T=(typeof AppState!=='undefined'&&AppState.prayerTimes)||null;}catch(e){}
  var d={Fajr:'05:00',Sunrise:'06:15',Dhuhr:'12:15',Asr:'15:30',Maghrib:'18:20',Isha:'19:40'},o={};
  Object.keys(d).forEach(function(k){var m=T&&T[k]?mins(T[k]):NaN;o[k]=isFinite(m)?m:mins(d[k]);});
  return o;
}

/* طور القمر */
function moonPhase(d){
  var jd=d.getTime()/86400000+2440587.5,age=(((jd-2451550.1)%29.530588)+29.530588)%29.530588;
  return age/29.530588; /* 0 هلال جديد، .5 بدر */
}
function moonSVG(p){
  var r=40,k=Math.cos(2*Math.PI*p),rx=Math.abs(k)*r,waxing=p<.5;
  var lit='M0 '+(-r)+'A'+r+' '+r+' 0 0 1 0 '+r+'A'+rx.toFixed(2)+' '+r+' 0 0 '+(k>0?0:1)+' 0 '+(-r)+'Z';
  var g=waxing?'':' transform="scale(-1,1)"';
  return '<svg viewBox="-50 -50 100 100"><defs><radialGradient id="skMoonG" cx=".35" cy=".3" r=".9"><stop offset="0" stop-color="#fff"/><stop offset=".6" stop-color="#e3ebff"/><stop offset="1" stop-color="#b9c8ee"/></radialGradient><clipPath id="skMoonC"><path d="'+lit+'"'+g+'/></clipPath></defs>'+
   '<circle r="'+r+'" fill="rgba(200,215,255,.1)" stroke="rgba(255,255,255,.28)" stroke-width="1"/>'+
   '<g'+g+'><path d="'+lit+'" fill="url(#skMoonG)"/></g>'+
   '<g clip-path="url(#skMoonC)"'+g+' opacity=".16"><circle cx="-12" cy="-10" r="9" fill="#7d8db8"/><circle cx="14" cy="8" r="12" fill="#7d8db8"/><circle cx="-6" cy="22" r="6" fill="#7d8db8"/></g></svg>';
}

/* الطقس */
var DEFAULT_WX={code:1,cloud:15,precip:0,wind:8},wx=DEFAULT_WX,previewWX=null,previewTime=null;
var WKEY='ikhlas-sky-weather';
function loc(){try{if(typeof AppState!=='undefined'&&AppState.userLocation)return AppState.userLocation;}catch(e){}return{lat:15.5007,lng:32.5599};}
function readCache(){try{return JSON.parse(localStorage.getItem(WKEY));}catch(e){return null;}}
function fetchWeather(){
  var L=loc(),c=readCache(),near=c&&Math.abs(c.lat-L.lat)<.25&&Math.abs(c.lng-L.lng)<.25;
  if(near){wx=c.w;if(Date.now()-c.t<30*60000)return;}
  if(navigator.onLine===false||typeof fetch!=='function')return;
  var ctl=typeof AbortController!=='undefined'?new AbortController():null,tm=setTimeout(function(){if(ctl)ctl.abort();},8000);
  var u='https://api.open-meteo.com/v1/forecast?latitude='+L.lat.toFixed(3)+'&longitude='+L.lng.toFixed(3)+'&current=weather_code,cloud_cover,precipitation,wind_speed_10m&timezone=auto';
  fetch(u,ctl?{signal:ctl.signal}:{}).then(function(r){return r.json();}).then(function(j){
    clearTimeout(tm);var q=j&&j.current;if(!q)return;
    wx={code:q.weather_code,cloud:q.cloud_cover,precip:q.precipitation,wind:q.wind_speed_10m};
    try{localStorage.setItem(WKEY,JSON.stringify({lat:L.lat,lng:L.lng,t:Date.now(),w:wx}));}catch(e){}
    tick(true);
  }).catch(function(){clearTimeout(tm);});
}
var PRESETS={clear:{code:0,cloud:0,wind:6},partly:{code:2,cloud:50,wind:10},overcast:{code:3,cloud:100,wind:12},
  rain:{code:63,cloud:95,precip:3,wind:18},storm:{code:95,cloud:100,precip:8,wind:30},fog:{code:45,cloud:70,wind:2},snow:{code:73,cloud:95,wind:8}};
function interpret(w){
  var c=w.code,cover=w.cloud==null?20:w.cloud,rain=0,snow=0,fog=0,thunder=false;
  if(c===0)cover=Math.min(cover,12);
  else if(c===1)cover=Math.min(cover,35);
  else if(c===2)cover=clamp(cover,35,65);
  else if(c===3)cover=Math.max(cover,85);
  if(c===45||c===48){fog=1;cover=Math.max(cover,60);}
  if(c>=51&&c<=57){rain=.35;cover=Math.max(cover,80);}
  if(c>=61&&c<=67){rain=c>=65?1:.65;cover=Math.max(cover,90);}
  if((c>=71&&c<=77)||c===85||c===86){snow=.75;cover=Math.max(cover,90);}
  if(c>=80&&c<=82){rain=c===82?1:.7;cover=Math.max(cover,85);}
  if(c>=95){rain=1;thunder=true;cover=100;}
  return{cover:clamp(cover,0,100),rain:rain,snow:snow,fog:fog,thunder:thunder,wind:w.wind==null?8:w.wind};
}

/* بناء المشهد */
var root,E={},stars=[],cloudSig='',flashT=0,reduce=false;
function rnd(seed){var s=seed>>>0||1;return function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
function build(){
  if(root||!document.body)return;
  reduce=!!(window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches);
  root=document.createElement('div');root.id='sky-scene';root.setAttribute('aria-hidden','true');
  root.innerHTML=
   '<svg width="0" height="0" style="position:absolute"><defs><clipPath id="skCloudClip" clipPathUnits="objectBoundingBox"><path transform="scale(0.0038462,0.01)" d="'+CLOUD+'"/></clipPath>'+
   '<linearGradient id="skCloudSheen" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:#fff;stop-opacity:.7"/><stop offset=".55" style="stop-color:#fff;stop-opacity:.06"/><stop offset="1" style="stop-color:rgb(var(--cl-shade));stop-opacity:.3"/></linearGradient></defs></svg>'+
   '<div class="sk-horizon"></div><div class="sk-stars"></div>'+
   '<div class="sk-sun"><i class="rays"></i><i class="glow"></i><i class="disc"></i></div>'+
   '<div class="sk-moon"><i class="halo"></i><i class="pane"></i><div class="mv"></div></div>'+
   '<div class="sk-clouds"></div><div class="sk-fog"></div><div class="sk-rain"></div><div class="sk-snow"></div><div class="sk-flash"></div><div class="sk-scrim"></div>';
  document.body.prepend(root);
  ['horizon','stars','sun','moon','clouds','fog','rain','snow','flash'].forEach(function(n){E[n]=root.querySelector('.sk-'+n);});
  E.mv=root.querySelector('.mv');E.mv.style.cssText='position:absolute;inset:0';
  var R=rnd(7),h='';
  for(var i=0;i<72;i++){var big=i%9===0,z=big?4+R()*2:1.3+R()*1.7;
    h+='<i class="sk-star'+(big?' big':'')+'" style="left:'+(R()*100).toFixed(1)+'%;top:'+(R()*100).toFixed(1)+'%;--z:'+z.toFixed(1)+'px;--d:'+(2+R()*4).toFixed(1)+'s;--dl:-'+(R()*6).toFixed(1)+'s"></i>';}
  E.stars.innerHTML=h;
  document.body.classList.add('sky-on');
}

function cloudsFor(S,sample,now){
  var n=S.cover<8?0:Math.round(S.cover/12.5),sig=n+'|'+(S.cover>=85?1:0)+'|'+Math.round(clamp(S.wind,0,40)/10)+'|'+(FLIP?1:0);
  if(sig===cloudSig)return;cloudSig=sig;
  var R=rnd(n*131+17),wind=clamp(1.7-S.wind/28,.55,1.7),h='';
  for(var i=0;i<n;i++){
    var d=R(),big=S.cover>=85?1.35:1,w=(110+d*170)*big,top=3+(((i*5)%n+R()*.8)/n)*(S.cover>=85?44:38);
    var dur=(300-d*170)*wind,dl=-((i+.15+R()*.7)/n)*dur,o=(.5+d*.4)*(S.cover>=85?1:.92),bl=(3+d*4).toFixed(1);
    h+='<div class="sk-cloud" style="--w:'+w.toFixed(0)+'px;--top:'+top.toFixed(1)+'%;--dur:'+dur.toFixed(0)+'s;--dl:'+dl.toFixed(0)+'s;--o:'+o.toFixed(2)+';--bl:'+bl+'px">'+
       '<div class="cl'+(R()<.5?' m':'')+'"><svg viewBox="0 0 260 100" preserveAspectRatio="none"><path d="'+CLOUD+'" fill="url(#skCloudSheen)"/><path class="rim" d="'+CLOUD+'"/></svg></div></div>';
  }
  E.clouds.innerHTML=h;E.clouds.classList.toggle('rtl',FLIP);
}

function scheduleFlash(on){
  clearTimeout(flashT);if(!on||reduce)return;
  (function loop(){flashT=setTimeout(function(){E.flash.classList.remove('on');void E.flash.offsetWidth;E.flash.classList.add('on');loop();},6000+Math.random()*9000);})();
}
var lastThunder=false;


/* ليلاً يتحول التطبيق للوضع الداكن تلقائياً (بلوحاته الجاهزة)، ويعود نهاراً — إلا إن اختار المستخدم «فاتح» أو «داكن» صراحة */
var autoOn=false;
function userTheme(){try{return (JSON.parse(localStorage.getItem('ikhlas_settings_v1'))||{}).theme||'auto';}catch(e){return 'auto';}}
function autoDark(night){
  var b=document.body,th=userTheme();
  if(night&&th==='auto'&&!b.classList.contains('dark-mode')){b.classList.add('dark-mode');autoOn=true;}
  else if(autoOn&&(!night||th!=='auto')){
    var userDark=false;try{userDark=!!AppState.isDarkMode;}catch(e){}
    if(!userDark)b.classList.remove('dark-mode');autoOn=false;
  }
}

/* الدورة الرئيسية */
function tick(){
  build();if(!root)return;
  var d=new Date(),now=previewTime!=null?previewTime:d.getHours()*60+d.getMinutes()+d.getSeconds()/60;
  var T=prayerMins(),K=keys(T),s=sample(K,now),S=interpret(previewWX||wx),dim=S.cover/100;
  var W=window.innerWidth||390,H=window.innerHeight||800;

  /* ألوان السماء: تخفت وتتلبد مع الغيوم */
  var gray=function(c,k){var g=(c[0]+c[1]+c[2])/3*.92+8;return mix(c,[g,g,g*1.03],k);};
  var kk=.62*Math.pow(dim,.8),dark=1-.22*dim*(S.rain?1.2:.6);
  var top=gray(s.top,kk).map(function(v){return v*dark;}),mid=gray(s.mid,kk).map(function(v){return v*dark;}),hor=gray(s.hor,kk*.9).map(function(v){return v*dark;});
  root.style.setProperty('--s1',css(top));root.style.setProperty('--s2',css(mid));root.style.setProperty('--s3',css(hor));

  /* لون السحاب: أبيض نهاراً، أزرق ليلاً، دافئ عند الشروق والغروب، رمادي عند التلبد */
  var base=mix([105,122,175],[255,255,255],clamp(s.lt*1.1,0,1));
  base=mix(base,[255,175,125],s.wm*.55*Math.max(.35,s.lt));
  var g2=95+s.lt*105;base=mix(base,[g2,g2,g2*1.04],.62*Math.pow(dim,.9)*(S.rain?1.1:1));
  root.style.setProperty('--cl',rgb(base));root.style.setProperty('--cl-shade',rgb(mix(top,[40,50,80],.5)));

  /* الشمس والقمر على قوس */
  var sr=T.Sunrise,ss=T.Maghrib,n=now;
  var day=n>=sr&&n<=ss,hy=H*.56,py=H*.13,x0=W*.12,x1=W*.88;
  var dimBody=clamp(1-.9*Math.pow(dim,2.2),.12,1);
  function pos(t){var a=Math.sin(Math.PI*clamp(t,0,1));var px=FLIP?x1-(x1-x0)*t:x0+(x1-x0)*t;return[px,hy-a*(hy-py),a];}
  var sz=clamp(W*.21,76,124);
  E.sun.style.setProperty('--sz',sz+'px');
  var pr=pos((n-sr)/(ss-sr)),warm=1-clamp(pr[2]/.38,0,1);
  E.sun.style.setProperty('--sun',rgb(mix([255,246,214],[255,176,96],warm)));
  E.sun.style.setProperty('--sun-d',rgb(mix([255,196,92],[255,104,40],warm)));
  E.sun.style.transform='translate3d('+pr[0].toFixed(1)+'px,'+pr[1].toFixed(1)+'px,0)';
  E.sun.style.opacity=day?dimBody:0;
  /* القمر */
  var nn=n>=ss?n:n+1440,len=(sr+1440)-ss,mt=(nn-ss)/len,mp=pos(mt);
  var msz=clamp(W*.17,62,92);E.moon.style.setProperty('--sz',msz+'px');
  E.moon.style.transform='translate3d('+mp[0].toFixed(1)+'px,'+mp[1].toFixed(1)+'px,0)';
  E.moon.style.opacity=day?0:dimBody;
  var ph=Math.round(moonPhase(d)*100);if(E.mv.dataset.p!==String(ph)){E.mv.dataset.p=ph;E.mv.innerHTML=moonSVG(ph/100);}

  /* النجوم والأفق */
  var st=clamp((.45-s.lt)/.45,0,1)*(1-.9*dim);
  E.stars.style.setProperty('--stars',st.toFixed(2));
  root.style.setProperty('--hz',(clamp(.25+s.wm*.7,0,1)*(1-.5*dim)).toFixed(2));
  root.style.setProperty('--hx',(pr[0]/W*100).toFixed(0)+'%');
  root.style.setProperty('--sun-d',rgb(mix([255,196,92],[255,104,40],warm)));

  /* الطقس */
  cloudsFor(S,s,now);
  E.rain.style.opacity=S.rain?clamp(.35+S.rain*.5,0,.85):0;
  E.snow.style.opacity=S.snow?.8:0;
  E.fog.style.opacity=S.fog?.85:0;
  if(S.thunder!==lastThunder){lastThunder=S.thunder;scheduleFlash(S.thunder);}

  var night=s.lt<.3;
  document.body.classList.toggle('sky-night',night);
  autoDark(night);
  root.classList.add('ready');
}

function preview(o){
  if(!o){previewWX=null;previewTime=null;cloudSig='';tick();return;}
  if(o.time!=null)previewTime=typeof o.time==='number'?o.time:mins(o.time);
  if(o.weather)previewWX=PRESETS[o.weather]||null;
  cloudSig='';tick();
}

function start(){
  build();tick();fetchWeather();
  setInterval(function(){if(!document.hidden)tick();},20000);
  setInterval(function(){if(!document.hidden)fetchWeather();},10*60000);
  document.addEventListener('visibilitychange',function(){if(!document.hidden){tick();fetchWeather();}});
  var rt;window.addEventListener('resize',function(){clearTimeout(rt);rt=setTimeout(tick,200);});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
/* عند إعادة حساب المواقيت (أو تغيّر الموقع) نحدّث المشهد والطقس أيضاً */
if(window.DynamicSky&&DynamicSky.refresh){var _r=DynamicSky.refresh;DynamicSky.refresh=function(){try{_r();}catch(e){}tick();fetchWeather();};}
window.SkyScene={refresh:function(){tick();fetchWeather();},preview:preview};
})();
