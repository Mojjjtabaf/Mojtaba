/* واجهة ديناميكية: ألوان تنتقل تدريجياً بحسب موقع الشمس، وقوس شمس/قمر فوق بطاقة المواقيت */
(function(){
const K=[ // مفاتيح الألوان عند كل وقت: [top, bottom]
 ['Fajr',[[15,23,60],[74,85,140]]],['Sunrise',[[251,146,60],[254,215,170]]],['Dhuhr',[[14,165,233],[186,230,253]]],
 ['Asr',[[217,119,6],[253,224,71]]],['Maghrib',[[190,24,93],[251,146,60]]],['Isha',[[15,23,42],[30,27,75]]]];
const mix=(a,b,t)=>a.map((v,i)=>Math.round(v+(b[i]-v)*t));
const rgb=c=>`rgb(${c[0]},${c[1]},${c[2]})`;
const mins=s=>{const p=String(s).split(':');return +p[0]*60+ +p[1];};
const NS='http://www.w3.org/2000/svg';
let arc,sun,moon,note;
function P(){return window.AppState&&AppState.prayerTimes&&AppState.prayerTimes.Fajr?AppState.prayerTimes:null;}
function colors(now,T){
  const pts=K.map(k=>[mins(T[k[0]]),k[1]]);pts.push([pts[0][0]+1440,pts[0][1]]);
  let n=now;if(n<pts[0][0])n+=1440;
  for(let i=0;i<pts.length-1;i++)if(n>=pts[i][0]&&n<pts[i+1][0]){
    const t=(n-pts[i][0])/(pts[i+1][0]-pts[i][0]);
    return[mix(pts[i][1][0],pts[i+1][1][0],t),mix(pts[i][1][1],pts[i+1][1][1],t)];}
  return K[5][1];
}
function build(){
  const card=document.querySelector('.prayer-dashboard');if(!card||arc)return;
  const bg=document.createElement('div');bg.id='sky-bg';document.body.prepend(bg);
  arc=document.createElement('div');arc.className='sky-arc';
  let st='';for(let i=0;i<22;i++)st+=`<circle class="sky-star" cx="${(i*47)%300}" cy="${(i*29)%50+4}" r="${i%3?0.9:1.4}" fill="#fff" style="animation-delay:${(i%7)*.4}s"/>`;
  arc.innerHTML=`<svg viewBox="0 0 300 96" preserveAspectRatio="xMidYMid slice"><g class="stars">${st}</g>
  <ellipse class="glow" cx="150" cy="96" rx="170" ry="46" fill="rgba(251,113,133,.55)"/><rect class="fog" width="300" height="96" fill="rgba(226,232,240,.5)"/>
  <path d="M20 88Q150 -30 280 88" fill="none" stroke="rgba(255,255,255,.35)" stroke-dasharray="3 5"/>
  <line x1="0" y1="88" x2="300" y2="88" stroke="rgba(255,255,255,.45)"/>
  <circle id="sky-sun" r="9" fill="#fde047" stroke="#f59e0b" stroke-width="2"/>
  <path id="sky-moon" d="M-6-8a9 9 0 1 0 11 12A7 7 0 0 1-6-8Z" fill="#e2e8f0" style="display:none"/></svg><div class="sky-note"></div>`;
  card.parentNode.insertBefore(arc,card);
  sun=arc.querySelector('#sky-sun');moon=arc.querySelector('#sky-moon');note=arc.querySelector('.sky-note');
}
function place(el,t){ // t من 0 إلى 1 على القوس (منحنى تربيعي)
  const x=20+260*t,y=(1-t)*(1-t)*88+2*t*(1-t)*(-30)+t*t*88;
  el.setAttribute('transform',`translate(${x.toFixed(1)},${y.toFixed(1)})`);
}
function tick(){
  const T=P();if(!T)return;build();if(!arc)return;
  const d=new Date(),now=d.getHours()*60+d.getMinutes()+d.getSeconds()/60;
  const c=colors(now,T),root=document.documentElement;
  root.style.setProperty('--sky-a',rgb(c[0]));root.style.setProperty('--sky-b',rgb(c[1]));
  const sr=mins(T.Sunrise),ss=mins(T.Maghrib),fj=mins(T.Fajr),is=mins(T.Isha);
  const day=now>=sr&&now<=ss;
  sun.style.display=day?'':'none';moon.style.display=day?'none':'';
  if(day)place(sun,(now-sr)/(ss-sr));
  else{const start=ss,len=(sr+1440)-ss,n=now<sr?now+1440:now;place(moon,Math.min(1,Math.max(0,(n-start)/len)));}
  arc.classList.toggle('night',!day&&(now>=is||now<fj-20));
  arc.classList.toggle('dawn',now>=fj-20&&now<sr+10);
  arc.classList.toggle('dusk',now>=ss-15&&now<=ss+30);
  // هدوء قبل الأذان بعشر دقائق
  const times=['Fajr','Dhuhr','Asr','Maghrib','Isha'].map(k=>mins(T[k]));
  document.body.classList.toggle('pre-adhan',times.some(t=>now>=t-10&&now<t));
  document.body.classList.toggle('friday',d.getDay()===5);
  // ملاحظة: أوقات النهي، الجمعة، إفطار رمضان
  let msg='';
  if(now>=sr&&now<sr+15)msg='وقت نهي عن الصلاة (بعد الشروق)';
  else if(now>=mins(T.Dhuhr)-10&&now<mins(T.Dhuhr))msg='وقت نهي عن الصلاة (قبيل الزوال)';
  else if(now>=ss-15&&now<ss)msg='وقت نهي عن الصلاة (قبيل الغروب)';
  else if(d.getDay()===5&&day)msg='يوم الجمعة: الكهف والصلاة على النبي ﷺ';
  try{const hm=new Intl.DateTimeFormat('en-u-ca-islamic-umalqura',{month:'numeric'}).format(d);
    if(hm==='9'&&day){const r=Math.max(0,Math.round(ss-now));msg='متبقٍّ على الإفطار '+Math.floor(r/60)+' س '+(r%60)+' د';}}catch(e){}
  note.textContent=msg;
}
function powerCheck(){
  /* الوضع الطبيعي افتراضياً: لا يُخفَّف المظهر إلا عند بطارية منخفضة جداً وغير موصولة بالشاحن */
  if(navigator.getBattery)navigator.getBattery().then(b=>{
    const f=()=>document.body.classList.toggle('low-power',b.level<=.15&&!b.charging);
    f();b.addEventListener('levelchange',f);b.addEventListener('chargingchange',f);}).catch(()=>{});
}
function start(){powerCheck();tick();setInterval(tick,20000);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
window.DynamicSky={refresh:tick};
})();
