/**
 * 🌌 محرك الهالة المحيطية والتكيف الزمني (Dynamic Ambient Aura & Chrono-Theming)
 * الإصدار: 2026 | مخصص لتطبيق "إخلاص"
 * الوظيفة: حقن بقع زجاجية متحركة، وتغيير الألوان السيادية للتطبيق بأكمله بناءً على الوقت الفلكي.
 */
(function initAmbientAuraEngine() {
    'use strict';

    // 1. حقن الأنماط والمتغيرات الديناميكية (CSS Injection)
    function injectAuraCSS() {
        if (document.getElementById('ambient-aura-css')) return;
        
        const style = document.createElement('style');
        style.id = 'ambient-aura-css';
        style.innerHTML = `
            /* المتغيرات الأساسية للبقع الضوئية */
            :root {
                --blob-color-1: rgba(13, 148, 136, 0.4);
                --blob-color-2: rgba(45, 212, 191, 0.3);
                --aura-transition: background 3s ease-in-out, opacity 3s ease-in-out;
            }

            /* تصميم البقع الهلامية الزجاجية (Glass Blobs) */
            .ambient-glass-blob {
                position: fixed;
                border-radius: 50%;
                filter: blur(100px); /* غبش عميق جداً لدمج الألوان */
                z-index: -2; /* خلف كل المكونات */
                pointer-events: none; /* لمنع إعاقة اللمس */
                transition: var(--aura-transition);
                will-change: transform;
            }

            .blob-primary {
                width: 55vw; height: 55vw; 
                top: -15%; left: -15%;
                background: var(--blob-color-1);
                animation: floatAura1 25s infinite alternate cubic-bezier(0.45, 0.05, 0.55, 0.95);
            }

            .blob-secondary {
                width: 65vw; height: 65vw; 
                bottom: -15%; right: -15%;
                background: var(--blob-color-2);
                animation: floatAura2 30s infinite alternate cubic-bezier(0.45, 0.05, 0.55, 0.95);
            }

            /* حركة طفو هيدروليكية ناعمة جداً باستخدام الحث العتادي */
            @keyframes floatAura1 {
                0% { transform: translate3d(0, 0, 0) scale(1) rotate(0deg); }
                100% { transform: translate3d(20vw, 15vh, 0) scale(1.2) rotate(45deg); }
            }
            @keyframes floatAura2 {
                0% { transform: translate3d(0, 0, 0) scale(1) rotate(0deg); }
                100% { transform: translate3d(-15vw, -15vh, 0) scale(1.15) rotate(-45deg); }
            }

            /* =======================================================
               2. الألوان السيادية للتطبيق حسب الأوقات الفلكية
               هذه الكلاسات ستغير لون الأزرار، التموجات، الخطوط والبقع معاً
               ======================================================= */
            
            /* وقت الفجر: أزرق سماوي وأزرق داكن (برودة ونقاء الصباح) */
            body.aura-fajr {
                --primary: #0284c7; --primary-dark: #0369a1; --theme-glow: rgba(2, 132, 199, 0.35);
                --blob-color-1: rgba(2, 132, 199, 0.4); --blob-color-2: rgba(30, 58, 138, 0.3);
            }
            /* وقت الشروق: برتقالي وذهبي (دفء انبعاث النور) */
            body.aura-sunrise {
                --primary: #ea580c; --primary-dark: #c2410c; --theme-glow: rgba(234, 88, 12, 0.35);
                --blob-color-1: rgba(234, 88, 12, 0.4); --blob-color-2: rgba(250, 204, 21, 0.3);
            }
            /* وقت الظهر: فيروزي مشرق (كبد السماء والوضوح) */
            body.aura-dhuhr {
                --primary: #0d9488; --primary-dark: #0f766e; --theme-glow: rgba(13, 148, 136, 0.35);
                --blob-color-1: rgba(13, 148, 136, 0.4); --blob-color-2: rgba(45, 212, 191, 0.3);
            }
            /* وقت العصر: عنبري دافئ (ميل الشمس للغروب) */
            body.aura-asr {
                --primary: #d97706; --primary-dark: #b45309; --theme-glow: rgba(217, 119, 6, 0.35);
                --blob-color-1: rgba(217, 119, 6, 0.4); --blob-color-2: rgba(234, 88, 12, 0.3);
            }
            /* وقت المغرب: قرمزي وبنفسجي (ألوان الشفق المتداخلة) */
            body.aura-maghrib {
                --primary: #e11d48; --primary-dark: #be123c; --theme-glow: rgba(225, 29, 72, 0.35);
                --blob-color-1: rgba(225, 29, 72, 0.4); --blob-color-2: rgba(147, 51, 234, 0.3);
            }
            /* وقت العشاء وثلث الليل: نيلي، كحلي عميق، ولمسات ذهبية كالنجوم */
            body.aura-isha {
                --primary: #4f46e5; --primary-dark: #3730a3; --theme-glow: rgba(79, 70, 229, 0.35);
                --blob-color-1: rgba(79, 70, 229, 0.4); --blob-color-2: rgba(30, 41, 59, 0.7);
            }
        `;
        document.head.appendChild(style);
    }

    // 2. بناء وحقن البقع الهلامية في الـ DOM
    function injectBlobs() {
        return; /* v22: استُبدلت بطبقة .home-live الأخف؛ كانت تُضيف تمويه 100px متحركاً */
        if(document.querySelector('.blob-primary')) return;
        
        const blob1 = document.createElement('div');
        blob1.className = 'ambient-glass-blob blob-primary';
        
        const blob2 = document.createElement('div');
        blob2.className = 'ambient-glass-blob blob-secondary';

        // وضعها كأول عنصر في الـ body لتكون في أقصى الخلفية
        document.body.prepend(blob2);
        document.body.prepend(blob1);
    }

    // 3. المحرك الذكي لمزامنة الألوان مع وقت الصلاة / الوقت الفلكي
    function syncAuraWithTime() {
        // نعتمد على ساعة النظام (ويمكن ربطها مستقبلاً بكائن AppState.prayerTimes بدقة أعلى)
        const hour = new Date().getHours();
        let activeTheme = 'aura-dhuhr'; // الافتراضي
        
        // التقسيم الفلكي للأوقات
        if (hour >= 4 && hour < 6) {
            activeTheme = 'aura-fajr';
        } else if (hour >= 6 && hour < 11) {
            activeTheme = 'aura-sunrise';
        } else if (hour >= 11 && hour < 15) {
            activeTheme = 'aura-dhuhr';
        } else if (hour >= 15 && hour < 18) {
            activeTheme = 'aura-asr';
        } else if (hour >= 18 && hour < 19) {
            activeTheme = 'aura-maghrib';
        } else {
            // من 7 مساءً حتى 4 فجراً
            activeTheme = 'aura-isha';
        }

        if (window.Personal) activeTheme = 'aura-' + Personal.period(); // مزامنة مع أوقات الصلاة الفعلية

        // إزالة أي ثيم سابق وحقن الثيم الجديد بنعومة
        document.body.classList.remove(
            'aura-fajr', 'aura-sunrise', 'aura-dhuhr', 
            'aura-asr', 'aura-maghrib', 'aura-isha'
        );
        document.body.classList.add(activeTheme);
    }

    // تشغيل المحرك
    window.addEventListener('DOMContentLoaded', () => {
        try {
            injectAuraCSS();
            injectBlobs();
            syncAuraWithTime();
            
            // فحص وتحديث الألوان كل دقيقة (60000ms) للتأكد من الانتقال الناعم عند تغير الوقت
            setInterval(syncAuraWithTime, 60000);
            
            console.log("🌌 تم تشغيل محرك الهالة المحيطية (Ambient Aura Engine) بنجاح.");
        } catch (e) {
            console.error("خطأ في محرك الألوان المحيطية: ", e);
        }
    });

})();
