/**
 * 💎 محرك الهوية الزجاجية والانتقالات السينمائية (يدعم الوضع الداكن بامتياز)
 * الإصدار: 2026 | مخصص لتطبيق "إخلاص"
 */
(function initGlassmorphismEngine() {
    'use strict';

    // =========================================================================
    // 1. حقن الأنماط الزجاجية العميقة المتكيفة مع الوضعين (المضيء والداكن)
    // =========================================================================
    function injectAdvancedGlassCSS() {
        if (document.getElementById('advanced-glass-css')) return;
        
        const style = document.createElement('style');
        style.id = 'advanced-glass-css';
        style.innerHTML = `
            /* v22: الزجاج والبطاقات في css/smooth.css. هنا فقط دخول الشاشة بانزلاق خفيف دون opacity ودون will-change
               (opacity/will-change على الحاوية تجعل التمويه الخلفي للبطاقات يرى خلفية فارغة فيبدو الزجاج مسطّحاً ثم يقفز عند انتهاء الحركة) */
            .view-section { display: none; }
            .view-section.active { display: block; animation: vs-in .26s cubic-bezier(.2,.8,.2,1) both; }
            @keyframes vs-in { from { transform: translate3d(0, 10px, 0); } to { transform: none; } }
        `;
        document.head.appendChild(style);
    }

    // =========================================================================
    // 2. ترقية دالة الانتقال بين الصفحات (Cinematic SwitchView Override)
    // =========================================================================
    function upgradePageTransitions() {
        if (typeof window.switchView === 'function' && !window.isSwitchViewUpgraded) {
            const originalSwitchView = window.switchView;
            
            window.switchView = function(viewId) {
                const cur = document.querySelector('.view-section.active');
                if (cur && cur.id === `view-${viewId}`) return;
                originalSwitchView(viewId);
            };
            
            window.isSwitchViewUpgraded = true; 
        }
    }

    // =========================================================================
    // التشغيل التلقائي
    // =========================================================================
    window.addEventListener('DOMContentLoaded', () => {
        try {
            injectAdvancedGlassCSS();
            setTimeout(upgradePageTransitions, 100); 
            console.log("💎 تم تشغيل محرك الزجاج (متوافق مع الوضع الداكن) والانتقالات بنجاح.");
        } catch (err) {
            console.error("خطأ في تشغيل محرك الزجاج: ", err);
        }
    });

})();
