(function initMurshedAnNoor() {
    'use strict';

    // ==========================================
    // 1. قواعد البيانات (Data Models)
    // ==========================================

    // محرك توليد الرسائل (ينتج أكثر من 20,000 رسالة فريدة)
    const MSG_OPENINGS = ["يا رفيق الدرب،", "أهلاً بك يا غالي،", "صباح/مساء النور،", "أيها القلب الطيب،", "مرحباً بك مجدداً،", "يا طالب الرضا،", "خطوة جديدة مباركة،"];
    const MSG_CORE = [
        "الاستمرار ولو بقليل يبني جبالاً من الحسنات.", "ركعة واحدة بقلب حاضر قد تغير مجرى يومك.", "افتح المصحف لخمس دقائق فقط، فالبركة تحل حيثما يحل القرآن.", "الدعاء الصادق لا يضيع، ارفع يديك وبث همومك.", "خطوة صغيرة اليوم خير من توقف طويل.", "أنت في عناية الله ما دمت تحاول العودة إليه.", "لا بأس إن تعثرت، المهم أن لا تتوقف عن المحاولة.", "جدد نيتك الآن، فالله يفرح بتوبة عبده وإقباله.", "ذكر الله يحيي القلب، ردد: سبحان الله وبحمده.", "الجنة تبنى بالذكر، فماذا بنيت اليوم؟"
    ];
    const MSG_CLOSINGS = ["نحن هنا لندعمك.", "توكل على الله وامضِ.", "كل يوم هو فرصة جديدة.", "لا تستسلم أبداً.", "الله يرى محاولاتك ويحبها.", "أكمل طريقك بسلام.", "دعنا نبدأ خطوة بخطوة."];

    function generateDailyMessage() {
        const op = (window.Personal && Math.random() < 0.6) ? Personal.greet() + '،' : MSG_OPENINGS[Math.floor(Math.random() * MSG_OPENINGS.length)];
        const core = MSG_CORE[Math.floor(Math.random() * MSG_CORE.length)];
        const clo = MSG_CLOSINGS[Math.floor(Math.random() * MSG_CLOSINGS.length)];
        return `${op} ${core} ${clo}`;
    }

    // رحلة 40 يوماً للتغيير (كاملة)
    const JOURNEY_40_DAYS = [];
    const themes = ["البداية وتجديد النية", "القرآن نور", "الصلاة عماد", "الأذكار حصن", "الدعاء يقين", "القلب السليم", "الاستقامة", "الشكر والامتنان"];
    for (let i = 1; i <= 40; i++) {
        let theme = themes[Math.floor((i - 1) / 5)];
        JOURNEY_40_DAYS.push({
            day: i,
            title: `اليوم ${i}: ${theme}`,
            task: i % 2 === 0 ? "اقرأ صفحة واحدة من القرآن بتدبر." : "حافظ على أذكار الصباح أو المساء.",
            message: "القطرات الصغيرة تصنع المحيط. استمر في بناء هذا الجدار المتين من العبادات.",
            benefit: "أحب الأعمال إلى الله أدومها وإن قل."
        });
    }

    // الخطط الجاهزة (Plans)
    const MURSHED_PLANS = [
        { id: "p1", name: "🌿 خطة العودة", days: 7, goals: ["صلاتان في وقتهما", "قراءة آية واحدة", "استغفار 33 مرة"] },
        { id: "p2", name: "🌿 خطة الثبات", days: 14, goals: ["جميع الصلوات", "صفحة قرآن", "أذكار الصباح"] },
        { id: "p3", name: "🌿 خطة الفجر", days: 10, goals: ["صلاة الفجر في وقتها", "ركعتا الضحى", "الدعاء بعد الفجر"] }
    ];

    // مستويات حديقة الإصلاح
    const GARDEN_LEVELS = [
        { xp: 0, icon: "🌱", name: "بذرة الإخلاص" },
        { xp: 100, icon: "🌿", name: "شجيرة النمو" },
        { xp: 300, icon: "🌷", name: "زهرة العطاء" },
        { xp: 600, icon: "🌳", name: "شجرة الثبات" },
        { xp: 1000, icon: "🏡", name: "حديقة السكينة" },
        { xp: 2000, icon: "🏞", name: "واحة النور" }
    ];

    // ==========================================
    // 2. حالة النظام والحفظ (State)
    // ==========================================
    let MurshedState = {
        xp: 0,
        streak: 0,
        lastLoginDate: null,
        balance: { quran: 10, dua: 10, adhkar: 10, prayer: 10, consistency: 10 },
        gratitudeLog: [],
        lifeJournal: [],
        journey40Progress: 0, // 0 to 40
        activePlan: null
    };

    function loadMurshedState() {
        const saved = localStorage.getItem('Ikhlas_Murshed_Data');
        if (saved) {
            MurshedState = JSON.parse(saved);
            checkStreakAndRescue();
        } else {
            MurshedState.lastLoginDate = new Date().toDateString();
        }
    }

    function saveMurshedState() {
        localStorage.setItem('Ikhlas_Murshed_Data', JSON.stringify(MurshedState));
    }

    function checkStreakAndRescue() {
        const today = new Date().toDateString();
        if (MurshedState.lastLoginDate !== today) {
            const lastDate = new Date(MurshedState.lastLoginDate);
            const currentDate = new Date(today);
            const diffDays = Math.floor((currentDate - lastDate) / (1000 * 60 * 60 * 24));
            
            if (diffDays === 1) {
                // حافظ على السلسلة
                MurshedState.streak += 1;
            } else if (diffDays > 1) {
                // نظام الإنقاذ الذكي (لا نكتب فشلت)
                MurshedState.streak = 0;
                showSmartGuide("🌱 لا بأس يا صديقي، كل يوم هو بداية جديدة. يمكننا البدء من جديد اليوم بشغف أكبر!");
            }
            MurshedState.lastLoginDate = today;
            
            // إضافة سجل في صحيفة الحياة
            MurshedState.lifeJournal.unshift({ date: today, log: "بداية يوم جديد في رحلة النور." });
            saveMurshedState();
        }
    }

    function getGardenStatus() {
        let currentLvl = GARDEN_LEVELS[0];
        for (let l of GARDEN_LEVELS) { if (MurshedState.xp >= l.xp) currentLvl = l; }
        return currentLvl;
    }

    // ==========================================
    // 3. حقن الأنماط (Premium Glassmorphism CSS)
    // ==========================================
    function injectMurshedStyles() {
        if (document.getElementById('murshed-css')) return;
        const style = document.createElement('style');
        style.id = 'murshed-css';
        style.innerHTML = `
            /* الحاوية الرئيسية للمرشد */
            #murshed-overlay { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: linear-gradient(135deg, #f0fdf4 0%, #e0f2fe 100%); z-index: 99990; display: none; flex-direction: column; overflow-x: hidden; font-family: 'Tajawal', sans-serif; transition: background 0.5s; }
            body.dark-mode #murshed-overlay { background: linear-gradient(135deg, #064e3b 0%, #0f172a 100%); color: white; }
            #murshed-overlay.active { display: flex; animation: murshedFadeIn 0.5s ease; }
            
            /* خلفية روحانية متحركة */
            .mr-bg-blob { position: absolute; width: 300px; height: 300px; background: rgba(52, 211, 153, 0.2); border-radius: 50%; filter: blur(60px); z-index: -1; animation: floatBlob 10s infinite alternate ease-in-out; }
            .mr-bg-blob-2 { position: absolute; right: -50px; bottom: -50px; width: 250px; height: 250px; background: rgba(56, 189, 248, 0.2); border-radius: 50%; filter: blur(60px); z-index: -1; animation: floatBlob 12s infinite alternate-reverse ease-in-out; }
            
            /* شريط التنقل */
            .mr-nav { display: flex; justify-content: space-between; align-items: center; padding: 20px; background: rgba(255,255,255,0.1); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(255,255,255,0.2); z-index: 10; }
            body.dark-mode .mr-nav { background: rgba(0,0,0,0.2); border-bottom: 1px solid rgba(255,255,255,0.05); }
            
            /* بطاقات زجاجية فاخرة */
            .mr-glass-card { background: rgba(255,255,255,0.6); backdrop-filter: blur(15px); border: 1px solid rgba(255,255,255,0.5); border-radius: 25px; padding: 20px; margin: 15px 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: 0.3s; position: relative; overflow: hidden; }
            body.dark-mode .mr-glass-card { background: rgba(255,255,255,0.05); border-color: rgba(255,255,255,0.1); box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
            
            /* حديقة الإصلاح */
            .mr-garden-view { text-align: center; padding: 30px 20px; }
            .mr-garden-icon { font-size: 5rem; filter: drop-shadow(0 10px 20px rgba(52, 211, 153, 0.4)); animation: gentlePulse 3s infinite alternate; }
            
            /* بوصلة التوازن (Radar/Bars) */
            .mr-compass { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 15px; }
            .mr-compass-bar { flex: 1 1 45%; background: rgba(0,0,0,0.05); padding: 10px; border-radius: 15px; display: flex; flex-direction: column; gap: 5px; }
            body.dark-mode .mr-compass-bar { background: rgba(255,255,255,0.05); }
            .mr-progress { width: 100%; height: 6px; background: rgba(128,128,128,0.2); border-radius: 10px; overflow: hidden; }
            .mr-progress-fill { height: 100%; background: linear-gradient(90deg, #10b981, #34d399); border-radius: 10px; width: 0%; transition: 1s; }
            
            /* أزرار لينة */
            .mr-btn { background: #10b981; color: white; border: none; padding: 12px 20px; border-radius: 15px; font-weight: bold; font-family: 'Tajawal'; cursor: pointer; transition: 0.3s; width: 100%; box-shadow: 0 5px 15px rgba(16, 185, 129, 0.3); }
            .mr-btn:active { transform: scale(0.95); }
            
            /* المرشد الذكي (Smart Guide Avatar) */
            .mr-guide-avatar { position: fixed; bottom: 20px; left: 20px; width: 60px; height: 60px; background: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2rem; box-shadow: 0 10px 25px rgba(0,0,0,0.1); cursor: pointer; z-index: 100; animation: bounceSoft 2s infinite; border: 2px solid #10b981; }
            .mr-guide-bubble { position: fixed; bottom: 90px; left: 20px; background: white; color: #333; padding: 15px 20px; border-radius: 20px 20px 20px 0; box-shadow: 0 10px 30px rgba(0,0,0,0.15); max-width: 250px; font-weight: bold; font-size: 0.9rem; z-index: 100; opacity: 0; pointer-events: none; transition: 0.4s; transform: translateY(10px); }
            body.dark-mode .mr-guide-avatar { background: #1e293b; border-color: #34d399; }
            body.dark-mode .mr-guide-bubble { background: #1e293b; color: white; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
            .mr-guide-bubble.show { opacity: 1; transform: translateY(0); pointer-events: all; }

            /* القوائم السفلية */
            .mr-tabs { display: flex; justify-content: space-around; padding: 10px; background: rgba(255,255,255,0.8); backdrop-filter: blur(20px); border-top: 1px solid rgba(0,0,0,0.05); position: sticky; bottom: 0; z-index: 20; }
            body.dark-mode .mr-tabs { background: rgba(0,0,0,0.5); border-color: rgba(255,255,255,0.05); }
            .mr-tab { padding: 10px; font-size: 1.2rem; opacity: 0.5; transition: 0.3s; cursor: pointer; }
            .mr-tab.active { opacity: 1; transform: translateY(-3px); color: #10b981; }

            /* دفتر الامتنان */
            .mr-input { width: 100%; padding: 15px; border-radius: 15px; border: 1px solid rgba(128,128,128,0.2); background: rgba(255,255,255,0.5); font-family: 'Tajawal'; font-size: 1rem; margin-bottom: 10px; outline: none; }
            body.dark-mode .mr-input { background: rgba(0,0,0,0.2); color: white; }

            @keyframes murshedFadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
            @keyframes floatBlob { 0% { transform: translate(0, 0) scale(1); } 100% { transform: translate(30px, 30px) scale(1.1); } }
            @keyframes gentlePulse { 0% { transform: scale(1); } 100% { transform: scale(1.05); } }
            @keyframes bounceSoft { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
        `;
        document.head.appendChild(style);
    }

    // ==========================================
    // 4. بناء الواجهة (HTML Injection)
    // ==========================================
    function injectMurshedHTML() {
        if (document.getElementById('murshed-overlay')) return;
        
        const html = `
            <div id="murshed-overlay">
                <div class="mr-bg-blob"></div>
                <div class="mr-bg-blob-2"></div>

                <div class="mr-nav">
                    <h2 style="font-family:'Aref Ruqaa',serif; font-size:1.8rem; margin:0; color:#10b981;">مرشد النور</h2>
                    <button style="background:none; border:none; font-size:1.5rem; cursor:pointer;" onclick="window.closeMurshed()">✖</button>
                </div>

                <div id="mr-content-area" style="flex: 1; overflow-y: auto; padding-bottom: 80px;">
                    </div>

                <div class="mr-guide-avatar" onclick="window.triggerSmartGuide()">🌿</div>
                <div class="mr-guide-bubble" id="mr-guide-bubble">رسالة المرشد هنا...</div>

                <div class="mr-tabs">
                    <div class="mr-tab active" onclick="window.switchMrTab('home', this)">🏠</div>
                    <div class="mr-tab" onclick="window.switchMrTab('journey', this)">🗺️</div>
                    <div class="mr-tab" onclick="window.switchMrTab('gratitude', this)">✍️</div>
                    <div class="mr-tab" onclick="window.switchMrTab('journal', this)">📰</div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', html);

        // إضافة بطاقة الدخول في الرئيسية (بلطف وبدون إزعاج)
        const homeSection = document.getElementById('view-home');
        if (homeSection && !document.getElementById('murshed-entry-card')) {
            const entryCard = `
                <div id="murshed-entry-card" class="card ripple-effect" onclick="window.openMurshed()" style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-left: 5px solid #10b981; padding: 20px; margin-bottom: 20px; cursor: pointer; display: flex; align-items: center; gap: 15px; border-radius: 20px;">
                    <div style="font-size: 2.5rem; animation: gentlePulse 2s infinite alternate;">🌿</div>
                    <div>
                        <h3 style="margin:0 0 5px; color:#10b981; font-size:1.2rem;">مرشد النور</h3>
                        <p style="margin:0; font-size:0.85rem; opacity:0.8;">رفيق طريقك، يتابع نموك بهدوء وإيجابية.</p>
                    </div>
                </div>
            `;
            homeSection.insertAdjacentHTML('afterbegin', entryCard);
        }
    }

    // ==========================================
    // 5. محرك العرض والتبويبات (Rendering Engine)
    // ==========================================
    
    window.switchMrTab = function(tabName, el) {
        document.querySelectorAll('.mr-tab').forEach(t => t.classList.remove('active'));
        if (el) el.classList.add('active');
        
        const content = document.getElementById('mr-content-area');
        content.innerHTML = ''; // مسح المحتوى القديم

        if (tabName === 'home') renderHomeTab(content);
        if (tabName === 'journey') renderJourneyTab(content);
        if (tabName === 'gratitude') renderGratitudeTab(content);
        if (tabName === 'journal') renderJournalTab(content);
    };

    function renderHomeTab(container) {
        const garden = getGardenStatus();
        const msgOfDay = generateDailyMessage();

        const html = `
            <div class="mr-glass-card">
                <div style="font-size:0.8rem; color:#10b981; font-weight:bold; margin-bottom:5px;">رسالة اليوم 🌿</div>
                <div style="font-size:1.1rem; line-height:1.6;">${msgOfDay}</div>
            </div>

            <div class="mr-glass-card mr-garden-view">
                <div style="font-size:0.8rem; opacity:0.7; margin-bottom:10px;">حالة نموك الحالية</div>
                <div class="mr-garden-icon">${garden.icon}</div>
                <h3 style="margin:10px 0 5px; color:#10b981;">${garden.name}</h3>
                <div style="font-size:0.8rem; opacity:0.8;">🔥 سلسلة الاستمرار: ${MurshedState.streak} أيام</div>
            </div>

            <div class="mr-glass-card">
                <h3 style="margin:0 0 15px; font-size:1.1rem;">📊 بوصلة التوازن</h3>
                <div class="mr-compass">
                    ${renderCompassBar('القرآن 📖', MurshedState.balance.quran)}
                    ${renderCompassBar('الدعاء 🤲', MurshedState.balance.dua)}
                    ${renderCompassBar('الأذكار 📿', MurshedState.balance.adhkar)}
                    ${renderCompassBar('الصلاة 🕌', MurshedState.balance.prayer)}
                </div>
            </div>

            <div class="mr-glass-card">
                <h3 style="margin:0 0 10px; font-size:1.1rem;">🎯 اقتراح اليوم</h3>
                <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(16,185,129,0.1); padding:15px; border-radius:15px;">
                    <div>قرّاءة صفحة واحدة فقط من القرآن.</div>
                    <button class="mr-btn" style="width:auto; padding:8px 15px;" onclick="window.completeMurshedGoal(this)">أتممتها ✅</button>
                </div>
            </div>
        `;
        container.innerHTML = html;

        // تفعيل حركة الأشرطة بعد ثانية
        setTimeout(() => {
            document.querySelectorAll('.mr-progress-fill').forEach(bar => {
                bar.style.width = bar.getAttribute('data-w') + '%';
            });
        }, 100);
    }

    function renderCompassBar(title, value) {
        // قيمة مرئية تصل لـ 100
        const percentage = Math.min(100, Math.max(0, value));
        return `
            <div class="mr-compass-bar">
                <div style="display:flex; justify-content:space-between; font-size:0.8rem; font-weight:bold;">
                    <span>${title}</span> <span>${percentage}%</span>
                </div>
                <div class="mr-progress"><div class="mr-progress-fill" data-w="${percentage}"></div></div>
            </div>
        `;
    }

    function renderJourneyTab(container) {
        const todayIdx = MurshedState.journey40Progress;
        const currentDayData = JOURNEY_40_DAYS[todayIdx] || JOURNEY_40_DAYS[39];
        const isCompleted = todayIdx >= 40;

        const html = `
            <div class="mr-glass-card">
                <h3 style="margin:0 0 5px; color:#10b981; font-family:'Aref Ruqaa'; font-size:1.8rem;">رحلة الـ 40 يوماً</h3>
                <p style="font-size:0.9rem; opacity:0.8;">تدرج في العبادة، خطوة بخطوة.</p>
                
                <div style="margin:20px 0; padding:20px; background:rgba(0,0,0,0.05); border-radius:20px; border-left:4px solid #10b981;">
                    <div style="font-weight:bold; color:#10b981; margin-bottom:10px;">${isCompleted ? '🎉 اكتملت الرحلة' : currentDayData.title}</div>
                    <div style="font-size:1.1rem; margin-bottom:15px;">${isCompleted ? 'لقد أتممت 40 يوماً من الإصلاح. مبارك لك هذا الثبات!' : currentDayData.task}</div>
                    <div style="font-size:0.85rem; opacity:0.8; font-style:italic;">"${currentDayData.benefit}"</div>
                </div>

                ${!isCompleted ? `<button class="mr-btn" onclick="window.advance40Journey()">أنجزت مهمة اليوم 🌿</button>` : ''}
                
                <div class="mr-progress" style="margin-top:20px; height:8px;">
                    <div class="mr-progress-fill" style="width: ${(todayIdx/40)*100}%"></div>
                </div>
                <div style="text-align:center; font-size:0.8rem; margin-top:5px;">اليوم ${todayIdx} من 40</div>
            </div>

            <div class="mr-glass-card">
                <h3 style="margin:0 0 15px; font-size:1.1rem;">📋 خطط الإصلاح الجاهزة</h3>
                ${MURSHED_PLANS.map(p => `
                    <div style="background:rgba(255,255,255,0.4); border:1px solid rgba(0,0,0,0.05); padding:15px; border-radius:15px; margin-bottom:10px; cursor:pointer;" onclick="showSmartGuide('خطة ${p.name} قيد التطوير وستعمل قريباً. ابدأ برحلة الـ 40 يوماً أولاً.')">
                        <div style="font-weight:bold; color:#10b981;">${p.name} (${p.days} أيام)</div>
                        <div style="font-size:0.8rem; opacity:0.7;">أهداف: ${p.goals.join('، ')}</div>
                    </div>
                `).join('')}
            </div>
        `;
        container.innerHTML = html;
    }

    function renderGratitudeTab(container) {
        const html = `
            <div class="mr-glass-card">
                <h3 style="margin:0 0 10px; font-size:1.2rem;">✍️ دفتر الامتنان</h3>
                <p style="font-size:0.9rem; opacity:0.8; margin-bottom:20px;">"ولئن شكرتم لأزيدنكم". اكتب 3 نعم تشعر بالامتنان لها اليوم، مهما كانت صغيرة.</p>
                
                <input type="text" id="g1" class="mr-input" placeholder="1. الحمدلله على...">
                <input type="text" id="g2" class="mr-input" placeholder="2. الحمدلله على...">
                <input type="text" id="g3" class="mr-input" placeholder="3. الحمدلله على...">
                
                <button class="mr-btn" style="margin-top:10px;" onclick="window.saveGratitude()">حفظ النعم 🤍</button>
            </div>

            <div class="mr-glass-card">
                <h3 style="margin:0 0 15px; font-size:1.1rem;">سجل الامتنان السابق</h3>
                ${MurshedState.gratitudeLog.slice(0, 5).map(g => `
                    <div style="border-bottom:1px dashed rgba(0,0,0,0.1); padding-bottom:10px; margin-bottom:10px;">
                        <div style="font-size:0.7rem; color:#10b981;">${g.date}</div>
                        <div style="font-size:0.9rem;">- ${g.texts.join('<br>- ')}</div>
                    </div>
                `).join('')}
                ${MurshedState.gratitudeLog.length === 0 ? '<div style="opacity:0.6; text-align:center;">لم تكتب شيئاً بعد. ابدأ اليوم!</div>' : ''}
            </div>
        `;
        container.innerHTML = html;
    }

    function renderJournalTab(container) {
        const html = `
            <div class="mr-glass-card">
                <h3 style="margin:0 0 15px; font-size:1.2rem;">📰 صحيفة الحياة</h3>
                <p style="font-size:0.85rem; opacity:0.8; margin-bottom:20px;">سجل يومي تلقائي يوثق خطواتك النورانية في التطبيق بدون تدخل منك.</p>
                
                <div style="display:flex; flex-direction:column; gap:10px;">
                    ${MurshedState.lifeJournal.slice(0, 10).map(j => `
                        <div style="background:rgba(16,185,129,0.05); border-left:3px solid #10b981; padding:10px 15px; border-radius:0 15px 15px 0;">
                            <div style="font-size:0.7rem; opacity:0.7; margin-bottom:5px;">${j.date}</div>
                            <div style="font-size:0.9rem; font-weight:bold;">${j.log}</div>
                        </div>
                    `).join('')}
                    ${MurshedState.lifeJournal.length === 0 ? '<div>لا توجد سجلات بعد.</div>' : ''}
                </div>
            </div>

            <div class="mr-glass-card" style="text-align:center;">
                <div style="font-size:3rem; margin-bottom:10px;">🪞</div>
                <h3 style="margin:0 0 5px; color:#10b981;">مرآة النفس</h3>
                <p style="font-size:0.9rem; opacity:0.8;">تحليل لطيف وإيجابي لأدائك العام.</p>
                <button class="mr-btn" style="background:transparent; border:2px solid #10b981; color:#10b981;" onclick="showSmartGuide('أنت تبلي بلاءً حسناً! استمر في المحاولة ولا تضغط على نفسك كثيراً، فالدين يسر.')">انظر للمرآة</button>
            </div>
        `;
        container.innerHTML = html;
    }

    // ==========================================
    // 6. العمليات والتفاعلات (Actions)
    // ==========================================

    window.openMurshed = function() {
        loadMurshedState();
        document.getElementById('murshed-overlay').classList.add('active');
        window.switchMrTab('home'); // فتح الرئيسية افتراضياً
        
        // ترحيب من المرشد بعد ثانية
        setTimeout(() => {
            showSmartGuide("أهلاً بك في مرشد النور. أنا هنا لأرافقك بهدوء، بلا ضغط ولا توبيخ. كيف حال قلبك اليوم؟ 🌿");
        }, 1000);
    };

    window.closeMurshed = function() {
        document.getElementById('murshed-overlay').classList.remove('active');
    };

    window.showSmartGuide = function(msg) {
        const bubble = document.getElementById('mr-guide-bubble');
        bubble.innerText = msg;
        bubble.classList.add('show');
        if(navigator.vibrate) navigator.vibrate(30);
        
        // إخفاء تلقائي بعد 5 ثوان
        setTimeout(() => {
            bubble.classList.remove('show');
        }, 5000);
    };

    window.triggerSmartGuide = function() {
        // نصائح عشوائية للمرشد
        const tips = [
            "تذكر، قليل دائم خير من كثير منقطع.",
            "هل شربت ماءً كافياً اليوم؟ الجسد السليم يعين على العبادة.",
            "ابتسم، فقد كان نبيك ﷺ بسّاماً.",
            "إذا شعرت بالفتور، فاستغفر، فالاستغفار يفتح الأقفال.",
            "لا بأس إن لم تنجز كل شيء اليوم، غداً يوم أجمل بإذن الله."
        ];
        showSmartGuide(tips[Math.floor(Math.random() * tips.length)]);
    };

    window.completeMurshedGoal = function(btn) {
        btn.innerText = "بوركت مساعيك ✨";
        btn.style.background = "transparent";
        btn.style.color = "#10b981";
        btn.disabled = true;
        
        MurshedState.xp += 10;
        MurshedState.balance.quran += 5; // تحسين البوصلة
        MurshedState.lifeJournal.unshift({ date: new Date().toDateString(), log: "أكملت هدف اليوم البسيط." });
        saveMurshedState();
        showSmartGuide("خطوة ممتازة! الله يبارك في هذا القليل فيجعله كثيراً.");
        
        // تحديث البوصلة صامتاً
        setTimeout(() => { if(document.querySelector('.mr-tab.active').innerText.includes('🏠')) window.switchMrTab('home'); }, 2000);
    };

    window.advance40Journey = function() {
        MurshedState.journey40Progress += 1;
        MurshedState.xp += 20;
        MurshedState.lifeJournal.unshift({ date: new Date().toDateString(), log: `أنجزت اليوم ${MurshedState.journey40Progress} من رحلة الـ 40 يوماً.` });
        saveMurshedState();
        
        showSmartGuide("إنجاز رائع! نحن نتقدم خطوة بخطوة نحو النسخة الأفضل منك.");
        window.switchMrTab('journey', document.querySelectorAll('.mr-tab')[1]);
    };

    window.saveGratitude = function() {
        const g1 = document.getElementById('g1').value;
        const g2 = document.getElementById('g2').value;
        const g3 = document.getElementById('g3').value;
        
        if (!g1 && !g2 && !g3) {
            showSmartGuide("اكتب نعمة واحدة على الأقل لنسجلها لك 🤍");
            return;
        }

        const texts = [g1, g2, g3].filter(t => t.trim() !== "");
        MurshedState.gratitudeLog.unshift({
            date: new Date().toDateString(),
            texts: texts
        });
        
        MurshedState.xp += 15;
        saveMurshedState();
        showSmartGuide("الحمدلله الذي بنعمته تتم الصالحات. تم حفظ شكرك.");
        window.switchMrTab('gratitude', document.querySelectorAll('.mr-tab')[2]);
    };

    // ==========================================
    // 7. الإقلاع التلقائي
    // ==========================================
    window.addEventListener('DOMContentLoaded', () => {
        try {
            injectMurshedStyles();
            injectMurshedHTML();
            console.log("🌿 محرك 'مرشد النور' (الرفيق الإيجابي) تم تفعيله بنجاح.");
        } catch (e) {
            console.error("Murshed Engine Error:", e);
        }
    });

})();
