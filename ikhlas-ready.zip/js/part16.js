/**
 * 🎵 محرك أصوات الأذان المتعددة (Multi-Adhan Sound Engine)
 * الإصدار 6.0.0.1 | كتابة وبرمجة: مجتبى صديق
 * يضيف قائمة لتخصيص أصوات الأذان ويربطها بمحرك الإشعارات
 */
(function initAdhanSounds() {
    'use strict';

    // 1. القائمة الموثوقة لأصوات الأذان (روابط MP3 مباشرة)
    const ADHAN_SOUNDS = AdhanRegistry.list;

    // 2. حقن واجهة الاختيار في قسم الإعدادات
    function injectAdhanSettingsUI() {
        const settingsView = document.getElementById('view-settings');
        // التأكد من أن البطاقة لم تضف مسبقاً
        if (settingsView && !document.getElementById('adhan-sound-settings-card')) {
            
            let optionsHTML = ADHAN_SOUNDS.map(s => `<option value="${s.id}">${s.name}</option>`).join('');

            const soundCardHTML = `
                <div class="card" id="adhan-sound-settings-card" style="border-right: 4px solid var(--accent);">
                    <h3 style="margin-bottom: 15px; font-size: 1.1rem; color: var(--primary);">🎵 تخصيص صوت المؤذن</h3>
                    <p style="font-size:0.85rem; color:var(--text-muted); margin-bottom:12px;">اختر الصوت الذي يصدح به هاتفك وقت دخول الصلاة:</p>
                    <label style="display: flex; flex-direction: column; gap: 8px;">
                        <select id="setting-adhan-sound" style="padding: 12px; border-radius: 12px; border: 1px solid var(--glass-border); background: var(--glass-bg-solid); color: var(--text-main); font-family: inherit; outline: none; font-weight: bold;">
                            ${optionsHTML}
                        </select>
                    </label>
                    <button class="btn-secondary ripple-effect" id="test-adhan-btn" style="margin-top: 15px; width: 100%; border-color: var(--accent); color: var(--accent);">🔊 استماع تجريبي للصوت</button>
                </div>
            `;
            
            // إدراج البطاقة بعد البطاقة الأولى في قسم الإعدادات
            const firstSettingsCard = settingsView.querySelector('.card');
            if (firstSettingsCard) {
                firstSettingsCard.insertAdjacentHTML('afterend', soundCardHTML);
            } else {
                settingsView.insertAdjacentHTML('beforeend', soundCardHTML);
            }
        }
    }

    // 3. ربط المنطق البرمجي، الحفظ في الذاكرة، واختبار الصوت
    function bindAdhanLogic() {
        const soundSelect = document.getElementById('setting-adhan-sound');
        const testBtn = document.getElementById('test-adhan-btn');
        
        if (!soundSelect || !testBtn) return;

        // استرجاع الصوت المحفوظ أو تعيين الافتراضي (مكة المكرمة)
        const savedId = AdhanRegistry.get(localStorage.getItem('IkhlasAdhanId')).id;
        const savedSound = AdhanRegistry.urlFor(savedId);
        soundSelect.value = savedId;
        
        // تحديث كائن الصوت الافتراضي في التطبيق
        if (window.muezzinAudio) {
            window.muezzinAudio.src = savedSound;
        } else {
            window.muezzinAudio = new Audio(savedSound);
        }

        // تحديث دالة تشغيل الأذان المتقدمة (Native) لتستخدم الصوت الجديد دائماً
        window.playFullAdhanNative = function() {
            if (window.cordova && window.cordova.plugins && window.cordova.plugins.backgroundMode) {
                cordova.plugins.backgroundMode.wakeUp();
                cordova.plugins.backgroundMode.unlock();
            }
            // سحب الصوت الفعلي المحفوظ في لحظة التشغيل
            const currentSoundUrl = AdhanRegistry.urlFor(localStorage.getItem('IkhlasAdhanId'));
            const dynamicAudio = new Audio(currentSoundUrl);
            dynamicAudio.play().catch(e => console.error("تعذر تشغيل الصوت:", e));
            
            if (navigator.vibrate) navigator.vibrate([1000, 500, 1000, 500, 2000]);
        };

        // عند تغيير المستخدم للصوت من القائمة المنسدلة
        soundSelect.addEventListener('change', function() {
            const newUrl = AdhanRegistry.urlFor(this.value);
            localStorage.setItem('IkhlasAdhanId', this.value);
            if (window.NativeAdhan) NativeAdhan.setSound(AdhanRegistry.fileFor(this.value));
            window.muezzinAudio.src = newUrl; // تحديث المصدر فوراً
            
            if (window.triggerHapticPro) window.triggerHapticPro(30);
            
            // إيقاف الاستماع التجريبي إذا كان يعمل وتغيّر الصوت
            if (isTesting) {
                window.muezzinAudio.pause();
                window.muezzinAudio.currentTime = 0;
                testBtn.innerHTML = "🔊 استماع تجريبي للصوت";
                isTesting = false;
            }
        });

        // زر الاختبار التجريبي للصوت
        let isTesting = false;
        testBtn.addEventListener('click', function() {
            if (isTesting) {
                window.muezzinAudio.pause();
                window.muezzinAudio.currentTime = 0;
                this.innerHTML = "🔊 استماع تجريبي للصوت";
                isTesting = false;
            } else {
                window.muezzinAudio.play().catch(e => alert("تعذر تشغيل الصوت، تأكد من اتصالك بالإنترنت."));
                this.innerHTML = "⏹ إيقاف الاستماع";
                isTesting = true;
                if (window.triggerHapticPro) window.triggerHapticPro(50);
            }
        });

        // إعادة ضبط الزر عند انتهاء المقطع الصوتي
        window.muezzinAudio.addEventListener('ended', () => {
            testBtn.innerHTML = "🔊 استماع تجريبي للصوت";
            isTesting = false;
        });
    }

    // إقلاع المحرك بشكل آمن بعد تحميل الصفحة
    window.addEventListener('DOMContentLoaded', () => {
        // تأخير زمني 800 ملي ثانية لضمان اكتمال بناء واجهة الإعدادات الأصلية
        setTimeout(() => {
            injectAdhanSettingsUI();
            bindAdhanLogic();
            console.log("🎵 تم تفعيل محرك أصوات الأذان المتعددة بنجاح.");
        }, 800); 
    });

})();
