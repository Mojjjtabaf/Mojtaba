window.SPIRITUAL_THEMES = {

    // 🌙 التهجد
    tahajjud_light:{
        primary:"#B8860B",
        glow:"rgba(184,134,11,.25)",
        bg:"linear-gradient(135deg,#F8F4E8,#EDE7D5,#D6CBB4)"
    },

    tahajjud_dark:{
        primary:"#D4AF37",
        glow:"rgba(212,175,55,.35)",
        bg:"linear-gradient(135deg,#020617,#0F172A,#111827)"
    },

    // 🌅 الفجر
    fajr_light:{
        primary:"#E879F9",
        glow:"rgba(232,121,249,.25)",
        bg:"linear-gradient(135deg,#FFF7ED,#FCE7F3,#DBEAFE)"
    },

    fajr_dark:{
        primary:"#FDBA74",
        glow:"rgba(253,186,116,.35)",
        bg:"linear-gradient(135deg,#172554,#4338CA,#F9A8D4)"
    },

    // 🌄 الشروق
    shurooq_light:{
        primary:"#EA580C",
        glow:"rgba(234,88,12,.25)",
        bg:"linear-gradient(135deg,#FFF7ED,#FED7AA,#FEF3C7)"
    },

    shurooq_dark:{
        primary:"#FB923C",
        glow:"rgba(251,146,60,.35)",
        bg:"linear-gradient(135deg,#7C2D12,#EA580C,#FDBA74)"
    },

    // ☀️ الضحى
    duha_light:{
        primary:"#0284C7",
        glow:"rgba(2,132,199,.25)",
        bg:"linear-gradient(135deg,#F0F9FF,#E0F2FE,#BAE6FD)"
    },

    duha_dark:{
        primary:"#38BDF8",
        glow:"rgba(56,189,248,.30)",
        bg:"linear-gradient(135deg,#0C4A6E,#0369A1,#38BDF8)"
    },

    // 🌞 الظهر
    dhuhr_light:{
        primary:"#2563EB",
        glow:"rgba(37,99,235,.25)",
        bg:"linear-gradient(135deg,#FFFFFF,#DBEAFE,#BFDBFE)"
    },

    dhuhr_dark:{
        primary:"#60A5FA",
        glow:"rgba(96,165,250,.30)",
        bg:"linear-gradient(135deg,#1E3A8A,#2563EB,#60A5FA)"
    },

    // 🌇 العصر
    asr_light:{
        primary:"#D97706",
        glow:"rgba(217,119,6,.25)",
        bg:"linear-gradient(135deg,#FFF7ED,#FDE68A,#FEF3C7)"
    },

    asr_dark:{
        primary:"#F59E0B",
        glow:"rgba(245,158,11,.35)",
        bg:"linear-gradient(135deg,#78350F,#B45309,#F59E0B)"
    },

    // 🌆 المغرب
    maghrib_light:{
        primary:"#DC2626",
        glow:"rgba(220,38,38,.25)",
        bg:"linear-gradient(135deg,#FFF1F2,#FED7AA,#FBCFE8)"
    },

    maghrib_dark:{
        primary:"#FB7185",
        glow:"rgba(251,113,133,.35)",
        bg:"linear-gradient(135deg,#7F1D1D,#DC2626,#7C3AED)"
    },

    // 🌌 العشاء
    isha_light:{
        primary:"#6366F1",
        glow:"rgba(99,102,241,.25)",
        bg:"linear-gradient(135deg,#EEF2FF,#E0E7FF,#DBEAFE)"
    },

    isha_dark:{
        primary:"#818CF8",
        glow:"rgba(129,140,248,.35)",
        bg:"linear-gradient(135deg,#020617,#0F172A,#312E81)"
    }
};

function applyAdvancedSpiritualTheme(timeTheme){
    /* أُوقف: كان يفرض تدرّج خلفية ولون primary حسب الساعة فيتعارض مع ثيم الصلاة الفعلي.
       الألوان الآن مصدرها الوحيد css/harmony.css عبر الكلاس aura-* حسب أوقات الأذان. */
    document.body.style.background = "";
    document.documentElement.style.removeProperty("--primary");
    document.documentElement.style.removeProperty("--theme-glow");
}

function autoDetectAdvancedTheme(){

    const h = new Date().getHours();

    let current="dhuhr";

    if(h>=2 && h<4)
        current="tahajjud";

    else if(h>=4 && h<6)
        current="fajr";

    else if(h>=6 && h<8)
        current="shurooq";

    else if(h>=8 && h<12)
        current="duha";

    else if(h>=12 && h<15)
        current="dhuhr";

    else if(h>=15 && h<18)
        current="asr";

    else if(h>=18 && h<20)
        current="maghrib";

    else
        current="isha";

    applyAdvancedSpiritualTheme(current);
}

document.addEventListener(
"DOMContentLoaded",
autoDetectAdvancedTheme
);

setInterval(
autoDetectAdvancedTheme,
60000
);
