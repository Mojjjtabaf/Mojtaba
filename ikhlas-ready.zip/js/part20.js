// تهيئة المصفوفات لتكون جاهزة لاستقبال البيانات
    window.DATA_HADITH = [];
    window.DATA_SUNNAH = []; 
    window.DATA_STORIES = []; 

    // 1. الدالة السحابية (المعالجة والمحصنة ضد الانهيار)
    

    // 2. دالة العرض الرئيسية التي تحول البيانات إلى بطاقات زجاجية
    window.renderKnowledge = function(category) {
        const box = document.getElementById('knowledge-content');
        if (!box) return;
        
        let dataToRender = [];
        if (category === 'hadith') dataToRender = window.DATA_HADITH;
        else if (category === 'sunnah') dataToRender = window.DATA_SUNNAH;
        else if (category === 'stories') dataToRender = window.DATA_STORIES;
        
        // إذا كانت المصفوفة فارغة، استدعِ دالة التحميل
        if (dataToRender.length === 0 && category === 'hadith') {
            loadCompleteHadithLibrary();
            return;
        }

        box.innerHTML = dataToRender.map(item => `
            <div class="card premium-ripple-target" style="border-right: 4px solid var(--primary); text-align:right; margin-bottom:15px; padding:15px; background:var(--glass-bg); border-radius:15px;">
                <h3 style="color:var(--primary); margin-bottom:8px; font-size:1.1rem;">${item.title || item.topic}</h3>
                <p style="text-align:justify; line-height:1.7; font-size:1.1rem;">${item.text || item.desc}</p>
                <div style="margin-top:10px; border-top:1px dashed rgba(128,128,128,0.2); padding-top:8px;">
                    <small style="color:var(--text-muted); font-weight:bold;">المصدر: ${item.source}</small>
                </div>
            </div>
        `).join('');
    };

    // 3. ربط أزرار التنقل (الأحاديث، السنن، القصص)
    document.addEventListener('DOMContentLoaded', () => {
        const knowledgeTabs = document.querySelectorAll('#knowledge-tabs-nav .tab-btn');
        if (knowledgeTabs.length > 0) {
            knowledgeTabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    // تفعيل الزر المضغوط
                    knowledgeTabs.forEach(t => t.classList.remove('active'));
                    this.classList.add('active');
                    
                    // استدعاء البيانات بناءً على القسم
                    window.renderKnowledge(this.getAttribute('data-source'));
                });
            });
            // البدء بعرض قسم الأحاديث كقسم افتراضي
            window.renderKnowledge('hadith');
        }
    });
