/* يعترض طلبات api.alquran.cloud ويجيبها من data/quran.json وdata/muyassar.json عند وجودهما، وإلا يمرّرها للشبكة */
(function(){
const orig=window.fetch.bind(window);let Q=null,T=null,loading=null;
const norm=s=>String(s||'').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[إأآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه');
async function load(){
  if(loading)return loading;
  loading=(async()=>{
    try{const r=await orig('data/quran.json');if(r.ok)Q=await r.json();}catch(e){}
    try{const r=await orig('data/muyassar.json');if(r.ok)T=await r.json();}catch(e){}
  })();return loading;
}
const res=(d)=>new Response(JSON.stringify({code:200,status:'OK',data:d}),{headers:{'Content-Type':'application/json'}});
const head=s=>({number:s.number,name:s.name,englishName:s.englishName,englishNameTranslation:s.englishNameTranslation,numberOfAyahs:s.ayahs.length,revelationType:s.revelationType});
window.fetch=async function(input,init){
  const url=typeof input==='string'?input:(input&&input.url)||'';
  const m=url.match(/^https:\/\/api\.alquran\.cloud\/v1\/(.*)$/);
  if(!m)return orig(input,init);
  await load();
  if(!Q||!Q.length)return orig(input,init);
  const p=decodeURIComponent(m[1]).split('/');
  try{
    if(p[0]==='surah'&&p.length===1)return res(Q.map(head));
    if(p[0]==='surah'&&p.length===2&&/^\d+$/.test(p[1])){const s=Q[+p[1]-1];return res({...head(s),ayahs:s.ayahs});}
    if(p[0]==='ayah'&&p[2]==='ar.muyassar'&&T){const [s,a]=p[1].split(':').map(Number);const t=T[s-1]&&T[s-1].ayahs[a-1];if(t)return res({text:t.text,numberInSurah:a,surah:head(Q[s-1])});}
    if(p[0]==='search'){
      const q=norm(p[1]);const matches=[];
      Q.forEach(s=>s.ayahs.forEach(a=>{if(norm(a.text).includes(q))matches.push({number:a.number,text:a.text,numberInSurah:a.numberInSurah,surah:head(s)});}));
      return res({count:matches.length,matches:matches.slice(0,60)});
    }
  }catch(e){}
  return orig(input,init);
};
})();
