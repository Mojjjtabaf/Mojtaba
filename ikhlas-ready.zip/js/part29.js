(function initSmartAdhkarSystem() {
    'use strict';

    // ==========================================
    // 1. إدارة الحالة والإحصائيات (State Management)
    // ==========================================
    let AdhkarState = {
        streak: 0,
        totalCompleted: 0,
        lastActiveDate: null,
        favorites: [], // مصفوفة بأسماء الأذكار المفضلة
        progress: {}, // سجل تقدم كل قسم { "الصباح": { count: 5, lastDate: "..." } }
        weeklyActivity: [0,0,0,0,0,0,0] // نشاط الأسبوع
    };

    function loadAdhkarState() {
        const saved = localStorage.getItem('Ikhlas_SmartAdhkar_Data');
        if (saved) AdhkarState = JSON.parse(saved);
        updateDailyStreak();
    }

    function saveAdhkarState() {
        localStorage.setItem('Ikhlas_SmartAdhkar_Data', JSON.stringify(AdhkarState));
    }

    function updateDailyStreak() {
        const today = new Date().toLocaleDateString('en-CA');
        if (AdhkarState.lastActiveDate !== today) {
            if (AdhkarState.lastActiveDate) {
                const diffDays = Math.floor((new Date(today) - new Date(AdhkarState.lastActiveDate)) / (1000 * 60 * 60 * 24));
                if (diffDays === 1) AdhkarState.streak++;
                else if (diffDays > 1) AdhkarState.streak = 1; // إعادة السلسلة بلطف
            } else {
                AdhkarState.streak = 1;
            }
            AdhkarState.lastActiveDate = today;
            // تحديث نشاط الأسبوع
            const dayIdx = new Date().getDay();
            AdhkarState.weeklyActivity[dayIdx] = 0; // تصفير اليوم الجديد
            saveAdhkarState();
        }
    }

    // ==========================================
    // 2. التصنيفات الذكية والخلفيات الديناميكية
    // ==========================================
    const MAIN_CATEGORIES = {
        daily: ["الصباح", "النهار", "المساء", "الليل", "النوم", "الاستيقاظ"],
        life: ["المنزل", "الخروج", "الدخول", "السفر", "الطعام", "اللباس", "المطر", "السوق"],
        worship: ["الصلاة", "الوضوء", "القرآن", "التسبيح", "الدعاء", "المسجد", "الآذان"],
        heart: ["السكينة", "الاستغفار", "الشكر", "التحصين", "الطمأنينة", "إزالة القلق", "الهم", "الإيمان", "الكرب"]
    };

    function getDynamicTheme() {
        const hour = new Date().getHours();
        if (hour >= 4 && hour < 7) return { name: "فجر", class: "theme-dawn", rec: "أذكار الصباح" };
        if (hour >= 7 && hour < 16) return { name: "نهار", class: "theme-day", rec: "أذكار النهار" };
        if (hour >= 16 && hour < 19) return { name: "مغرب", class: "theme-dusk", rec: "أذكار المساء" };
        return { name: "ليل", class: "theme-night", rec: "أذكار النوم" };
    }

    // ==========================================
    // 3. حقن الأنماط (Premium Glassmorphism CSS)
    // ==========================================
    function injectAdhkarStyles() {
        if(document.getElementById('smart-adhkar-css')) return;
        const style = document.createElement('style');
        style.id = 'smart-adhkar-css';
        style.innerHTML = `
            /* الخلفيات الديناميكية */
            .theme-dawn { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
            .theme-day { background: linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%); }
            .theme-dusk { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); }
            .theme-night { background: linear-gradient(135deg, #141e30 0%, #243b55 100%); color: white !important; }
            
            /* الواجهة الرئيسية */
            .sa-container { display: flex; flex-direction: column; gap: 20px; padding: 20px; padding-bottom: 90px; min-height: 100vh; transition: background 1s ease; }
            
            /* شريط النشاط */
            .sa-activity-bar { display: flex; justify-content: space-between; background: rgba(255,255,255,0.25); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.3); border-radius: 20px; padding: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
            .theme-night .sa-activity-bar { background: rgba(0,0,0,0.3); border-color: rgba(255,255,255,0.1); }
            .sa-stat { text-align: center; }
            .sa-stat-val { font-size: 1.5rem; font-weight: 900; }
            .sa-stat-lbl { font-size: 0.75rem; opacity: 0.8; font-weight: bold; }

            /* البطاقة الذكية */
            .sa-smart-card { background: rgba(255,255,255,0.3); backdrop-filter: blur(25px); border: 1px solid rgba(255,255,255,0.5); border-radius: 25px; padding: 25px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 15px 35px rgba(0,0,0,0.1); position: relative; overflow: hidden; }
            .theme-night .sa-smart-card { background: rgba(255,255,255,0.1); border-color: rgba(255,255,255,0.15); }
            .sa-smart-card::before { content: '✨'; position: absolute; top: -10px; right: -10px; font-size: 5rem; opacity: 0.2; transform: rotate(-15deg); }
            
            /* شريط البحث */
            .sa-search-box { position: relative; width: 100%; }
            .sa-search-input { width: 100%; background: rgba(255,255,255,0.4); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.5); border-radius: 15px; padding: 15px 45px 15px 15px; font-family: 'Tajawal', sans-serif; font-size: 1rem; color: inherit; outline: none; transition: 0.3s; }
            .theme-night .sa-search-input { background: rgba(0,0,0,0.3); border-color: rgba(255,255,255,0.2); color: white; }
            .sa-search-input:focus { border-color: #0d9488; background: rgba(255,255,255,0.6); }
            .sa-search-icon { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); opacity: 0.6; }

            /* التبويبات (Tabs) */
            .sa-tabs { display: flex; gap: 10px; overflow-x: auto; scrollbar-width: none; padding-bottom: 5px; }
            .sa-tabs::-webkit-scrollbar { display: none; }
            .sa-tab { white-space: nowrap; padding: 10px 20px; background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); border-radius: 20px; font-weight: bold; cursor: pointer; transition: 0.3s; }
            .theme-night .sa-tab { background: rgba(0,0,0,0.3); border-color: rgba(255,255,255,0.1); }
            .sa-tab.active { background: #0d9488; color: white; border-color: #0d9488; box-shadow: 0 5px 15px rgba(13, 148, 136, 0.4); }

            /* شبكة البطاقات الحديثة */
            .sa-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; }
            .sa-card { background: rgba(255,255,255,0.3); backdrop-filter: blur(15px); border: 1px solid rgba(255,255,255,0.4); border-radius: 20px; padding: 20px; text-align: center; cursor: pointer; transition: 0.3s; position: relative; }
            .theme-night .sa-card { background: rgba(30,41,59,0.5); border-color: rgba(255,255,255,0.1); }
            .sa-card:hover { transform: translateY(-5px); background: rgba(255,255,255,0.5); }
            .sa-card-icon { font-size: 2.5rem; margin-bottom: 10px; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.1)); }
            .sa-card-title { font-family: 'Aref Ruqaa', serif; font-size: 1.2rem; font-weight: bold; margin-bottom: 5px; }
            .sa-card-meta { font-size: 0.75rem; opacity: 0.8; display: flex; justify-content: space-between; align-items: center; }
            
            /* شريط الإنجاز الصغير */
            .sa-card-progress { width: 100%; height: 4px; background: rgba(0,0,0,0.1); border-radius: 2px; margin-top: 10px; overflow: hidden; }
            .sa-card-progress-fill { height: 100%; background: #10b981; transition: width 0.5s; }

            /* زر المفضلة */
            .sa-fav-btn { position: absolute; top: 10px; left: 10px; background: none; border: none; font-size: 1.2rem; opacity: 0.3; cursor: pointer; transition: 0.3s; }
            .sa-fav-btn.active { opacity: 1; color: #fbbf24; text-shadow: 0 0 10px rgba(251, 191, 36, 0.5); }

            /* شاشة الاحتفال عند الإكمال */
            .sa-success-overlay { position: fixed; top:0; left:0; width:100vw; height:100vh; background: rgba(16,185,129,0.9); backdrop-filter: blur(15px); z-index: 100000; display: flex; flex-direction: column; align-items: center; justify-content: center; color: white; opacity: 0; pointer-events: none; transition: 0.5s; }
            .sa-success-overlay.show { opacity: 1; pointer-events: all; }
        `;
        document.head.appendChild(style);
    }

    // ==========================================
    // 4. بناء وتصنيف البيانات (بدون حذف القديم)
    // ==========================================
    function getCategorizedAdhkar() {
        // قراءة البيانات من التطبيق القديم (إذا كانت موجودة في ADHKAR_DATA)
        // أو قراءتها من عناصر الـ DOM الموجودة في قسم الأذكار القديم.
        let allCategories = [];
        
        // محاولة جلبها من المصفوفة العامة إن وجدت
        if (typeof window.ADHKAR_DATA !== 'undefined') {
            allCategories = Object.keys(window.ADHKAR_DATA);
        } else {
            // بديل: استخراجها من أزرار التطبيق القديم لضمان عدم فقدان أي قسم
            document.querySelectorAll('#view-adhkar .card h3, #view-adhkar button').forEach(el => {
                let name = el.innerText.trim();
                if(name && !allCategories.includes(name)) allCategories.push(name);
            });
        }

        // إذا كانت فارغة تماماً (حالة تهيئة أولية)، نضع مصفوفة طوارئ
        if(allCategories.length === 0) {
            allCategories = ["الصباح", "المساء", "النوم", "الصلاة", "الاستغفار", "المنزل"];
        }

        let sorted = { daily: [], life: [], worship: [], heart: [], all: allCategories };

        allCategories.forEach(cat => {
            let added = false;
            if(MAIN_CATEGORIES.daily.some(k => cat.includes(k))) { sorted.daily.push(cat); added = true; }
            else if(MAIN_CATEGORIES.life.some(k => cat.includes(k))) { sorted.life.push(cat); added = true; }
            else if(MAIN_CATEGORIES.worship.some(k => cat.includes(k))) { sorted.worship.push(cat); added = true; }
            else if(MAIN_CATEGORIES.heart.some(k => cat.includes(k))) { sorted.heart.push(cat); added = true; }
            
            // أي قسم غير معروف نضعه في "حياتي" كاحتياط لعدم ضياع أي داتا
            if(!added) sorted.life.push(cat); 
        });

        return sorted;
    }

    function getIconForCategory(name) {
        if(name.includes("صباح") || name.includes("نهار")) return "🌅";
        if(name.includes("مساء") || name.includes("غروب")) return "🌇";
        if(name.includes("نوم") || name.includes("ليل")) return "🌙";
        if(name.includes("صلاة") || name.includes("مسجد") || name.includes("وضوء")) return "🕌";
        if(name.includes("قرآن") || name.includes("تلاوة")) return "📖";
        if(name.includes("طعام") || name.includes("شرب")) return "🍽";
        if(name.includes("سفر") || name.includes("ركوب")) return "🚗";
        if(name.includes("منزل") || name.includes("دخول") || name.includes("خروج")) return "🚪";
        if(name.includes("قلق") || name.includes("هم") || name.includes("طمأنينة") || name.includes("سكينة")) return "💖";
        if(name.includes("تحصين") || name.includes("حفظ")) return "🛡";
        return "📿"; // افتراضي
    }

    // ==========================================
    // 5. حقن الواجهة الجديدة (UI Injector)
    // ==========================================
    function injectSmartUI() {
        const oldView = document.getElementById('view-adhkar');
        if (!oldView) return; // ننتظر حتى يوجد القسم

        // إخفاء المحتوى القديم (وليس حذفه)
        Array.from(oldView.children).forEach(child => child.style.display = 'none');

        const theme = getDynamicTheme();
        const data = getCategorizedAdhkar();

        const uiHTML = `
            <div class="sa-container ${theme.class}" id="sa-main-container">
                
                <div class="sa-activity-bar">
                    <div class="sa-stat">
                        <div class="sa-stat-val">🔥 <span id="sa-val-streak">${AdhkarState.streak}</span></div>
                        <div class="sa-stat-lbl">سلسلة الأيام</div>
                    </div>
                    <div class="sa-stat">
                        <div class="sa-stat-val">⭐ <span id="sa-val-total">${AdhkarState.totalCompleted}</span></div>
                        <div class="sa-stat-lbl">إجمالي الإكمال</div>
                    </div>
                    <div class="sa-stat">
                        <div class="sa-stat-val">📅 <span id="sa-val-today">✓</span></div>
                        <div class="sa-stat-lbl">نشاط اليوم</div>
                    </div>
                </div>

                <div class="sa-smart-card" onclick="window.openSmartCategory('${theme.rec}')">
                    <div>
                        <div style="font-size:0.85rem; font-weight:bold; opacity:0.8; margin-bottom:5px;">${theme.icon || '✨'} مناسب لك الآن</div>
                        <h2 style="font-family:'Aref Ruqaa'; font-size:2rem; margin:0;">${theme.rec}</h2>
                    </div>
                    <button style="background:var(--primary); color:white; border:none; padding:10px 20px; border-radius:15px; font-weight:bold; cursor:pointer;">ابدأ الآن ◀</button>
                </div>

                <div class="sa-search-box">
                    <span class="sa-search-icon">🔍</span>
                    <input type="text" class="sa-search-input" id="sa-search" placeholder="ابحث في جميع الأذكار..." onkeyup="window.filterSmartAdhkar()">
                </div>

                <div class="sa-tabs">
                    <div class="sa-tab active" onclick="window.switchSaTab('all', this)">الكل</div>
                    <div class="sa-tab" onclick="window.switchSaTab('fav', this)">⭐ المفضلة</div>
                    <div class="sa-tab" onclick="window.switchSaTab('daily', this)">☀️ يومي</div>
                    <div class="sa-tab" onclick="window.switchSaTab('life', this)">🏠 حياتي</div>
                    <div class="sa-tab" onclick="window.switchSaTab('worship', this)">🕌 عبادتي</div>
                    <div class="sa-tab" onclick="window.switchSaTab('heart', this)">💖 قلبي</div>
                </div>

                <div class="sa-grid" id="sa-cards-grid"></div>

            </div>

            <div class="sa-success-overlay" id="sa-success-screen">
                <div style="font-size:5rem; margin-bottom:10px;">🌿</div>
                <h1 style="font-family:'Aref Ruqaa'; font-size:3rem; margin:0;">أحسنت!</h1>
                <p style="font-size:1.2rem; margin-top:10px;" id="sa-success-msg">تم إكمال الأذكار بنجاح.</p>
                <button style="margin-top:30px; background:white; color:#10b981; border:none; padding:12px 30px; border-radius:20px; font-weight:bold; font-size:1.1rem; cursor:pointer;" onclick="document.getElementById('sa-success-screen').classList.remove('show')">متابعة</button>
            </div>
        `;

        // إضافة الواجهة الجديدة فوق القديمة
        oldView.insertAdjacentHTML('beforeend', uiHTML);
        
        // رسم البطاقات
        window.SA_CURRENT_DATA = data;
        renderSmartCards('all');
    }

    // ==========================================
    // 6. دوال التشغيل والتفاعل (Logic)
    // ==========================================
    window.renderSmartCards = function(tabFilter) {
        const grid = document.getElementById('sa-cards-grid');
        if(!grid) return;
        
        let targetArray = [];
        if(tabFilter === 'all') targetArray = window.SA_CURRENT_DATA.all;
        else if(tabFilter === 'fav') targetArray = AdhkarState.favorites;
        else targetArray = window.SA_CURRENT_DATA[tabFilter] || [];

        if(targetArray.length === 0) {
            grid.innerHTML = `<div style="grid-column: 1/-1; text-align:center; padding:30px; opacity:0.6;">لا توجد أذكار في هذا القسم حالياً.</div>`;
            return;
        }

        grid.innerHTML = targetArray.map(catName => {
            const isFav = AdhkarState.favorites.includes(catName);
            const prog = AdhkarState.progress[catName] || { count: 0, lastDate: 'لم تقرأ بعد' };
            const icon = getIconForCategory(catName);
            
            // حساب نسبة تقدم وهمية للجمال البصري (إذا كانت مقروءة اليوم نضع 100%)
            const isToday = prog.lastDate === new Date().toLocaleDateString('ar-EG');
            const percent = isToday ? 100 : 0;

            return `
                <div class="sa-card" data-title="${catName}">
                    <button class="sa-fav-btn ${isFav ? 'active' : ''}" onclick="window.toggleSaFav('${catName}', event)">★</button>
                    <div onclick="window.openSmartCategory('${catName}')">
                        <div class="sa-card-icon">${icon}</div>
                        <div class="sa-card-title">${catName}</div>
                        <div class="sa-card-meta">
                            <span>مرات: ${prog.count}</span>
                            <span style="font-size:0.65rem;">${isToday ? '✓ اليوم' : prog.lastDate}</span>
                        </div>
                        <div class="sa-card-progress"><div class="sa-card-progress-fill" style="width:${percent}%"></div></div>
                    </div>
                </div>
            `;
        }).join('');
    };

    window.switchSaTab = function(tabName, element) {
        document.querySelectorAll('.sa-tab').forEach(t => t.classList.remove('active'));
        element.classList.add('active');
        renderSmartCards(tabName);
    };

    window.filterSmartAdhkar = function() {
        const query = document.getElementById('sa-search').value.trim();
        const cards = document.querySelectorAll('.sa-card');
        
        // إذا كان فارغاً، نظهر الجميع حسب التبويب النشط
        if(query === "") {
            cards.forEach(c => c.style.display = 'block');
            return;
        }

        // بحث مرن (Fuzzy Search)
        cards.forEach(card => {
            const title = card.getAttribute('data-title');
            if(title.includes(query)) card.style.display = 'block';
            else card.style.display = 'none';
        });
    };

    window.toggleSaFav = function(catName, event) {
        event.stopPropagation(); // منع فتح القسم
        const btn = event.target;
        if(AdhkarState.favorites.includes(catName)) {
            AdhkarState.favorites = AdhkarState.favorites.filter(c => c !== catName);
            btn.classList.remove('active');
        } else {
            AdhkarState.favorites.push(catName);
            btn.classList.add('active');
        }
        saveAdhkarState();
    };

    // ربط هذا المحرك بالدالة القديمة لفتح الأذكار
    window.openSmartCategory = function(catName) {
        // التحقق مما إذا كانت الدالة القديمة موجودة
        if (typeof window.openAdhkarCategory === 'function') {
            window.openAdhkarCategory(catName); // فتح الدالة القديمة لعدم كسر النظام
        } else {
            console.log("فتح القسم:", catName); // احتياطي
        }

        // دمج نظام "فضل الذكر" والاحتفال
        injectVirtueAndCompletion(catName);
    };

    function injectVirtueAndCompletion(catName) {
        // ننتظر حتى يتم بناء واجهة القراءة القديمة (DOM)
        setTimeout(() => {
            const readerHeader = document.querySelector('.reader-header');
            if(readerHeader && !document.getElementById('sa-virtue-box')) {
                // إضافة فضل الذكر
                const virtueHTML = `<div id="sa-virtue-box" style="background:rgba(13,148,136,0.1); border:1px dashed #0d9488; padding:10px; margin:10px 20px; border-radius:10px; text-align:center; font-size:0.85rem; color:#0d9488; font-weight:bold;">📖 فضل هذا الذكر: طمأنينة للقلب وحفظ من كل سوء.</div>`;
                readerHeader.insertAdjacentHTML('afterend', virtueHTML);
            }

            // تتبع إنهاء الأذكار (ربط زر الانتهاء القديم إن وجد، أو مراقبة العداد)
            // سنضيف دالة إكمال يدوية لمراقبة الإنجاز
            const originalBackBtn = document.querySelector('.reader-header .btn-icon');
            if(originalBackBtn) {
                originalBackBtn.addEventListener('click', () => {
                    markCategoryCompleted(catName);
                });
            }
        }, 500);
    }

    function markCategoryCompleted(catName) {
        // تحديث الإحصائيات
        AdhkarState.totalCompleted++;
        if(!AdhkarState.progress[catName]) AdhkarState.progress[catName] = { count: 0 };
        AdhkarState.progress[catName].count++;
        AdhkarState.progress[catName].lastDate = new Date().toLocaleDateString('ar-EG');
        
        const dayIdx = new Date().getDay();
        AdhkarState.weeklyActivity[dayIdx]++;
        
        saveAdhkarState();

        // تحديث الواجهة الرئيسية برمجياً
        document.getElementById('sa-val-total').innerText = AdhkarState.totalCompleted;
        renderSmartCards(document.querySelector('.sa-tab.active').innerText.includes('الكل') ? 'all' : 'fav');

        // إظهار شاشة الاحتفال
        const successScreen = document.getElementById('sa-success-screen');
        if(successScreen) {
            document.getElementById('sa-success-msg').innerText = `تم إكمال ${catName} بنجاح.`;
            successScreen.classList.add('show');
            if(navigator.vibrate) navigator.vibrate([50, 100, 50]);
        }
    }

    // ==========================================
    // 7. الإقلاع (Boot)
    // ==========================================
    window.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => {
            try {
                loadAdhkarState();
                injectAdhkarStyles();
                injectSmartUI();
                console.log("📿 تم تشغيل محرك الأذكار الذكي بنجاح مع الحفاظ على البيانات القديمة.");
            } catch(e) { console.error("Smart Adhkar Engine Error:", e); }
        }, 2000); // تأخير بسيط لضمان اكتمال تحميل التطبيق الأصلي أولاً
    });

})();
