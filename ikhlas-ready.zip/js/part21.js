// =========================================================================
    // 🚀 المحرك السحابي المطور للموسوعة (خفيف جداً ومحصن ضد الانهيار)
    // =========================================================================
    
    window.DATA_HADITH = [];
    window.DATA_SUNNAH = []; 
    window.DATA_STORIES = []; 

    // 1. دالة جلب البيانات من المكتبة الجديدة والمستقرة
    async function loadCompleteHadithLibrary() {
        const box = document.getElementById('knowledge-content');
        if (!box) return;

        // واجهة تحميل زجاجية أنيقة
        box.innerHTML = `
            <div style="text-align:center; padding:40px; color:var(--primary);">
                <div class="micro-breathe" style="font-size:2.5rem; margin-bottom:15px;">📡</div>
                <h3 style="margin-bottom:10px;">جاري الاتصال بالمكتبة...</h3>
                <p style="opacity:0.8;">نعتمد تقنية الجلب السريع لضمان سرعة التطبيق</p>
            </div>
        `;

        try {
            // استخدام مكتبة جديدة تدعم تحديد العدد (نجلب من الحديث 1 إلى 300 فقط لمنع الانهيار)
            const response = await fetch('https://api.hadith.gading.dev/books/bukhari?range=1-300');
            
            if (!response.ok) throw new Error("فشل الاتصال بالخادم السحابي");
            
            const rawData = await response.json();
            
            if (!rawData || !rawData.data || !rawData.data.hadiths) {
                throw new Error("بنية بيانات غير صالحة");
            }

            // معالجة البيانات وتجهيزها للعرض
            window.DATA_HADITH = rawData.data.hadiths.map(item => {
                return {
                    topic: `صحيح البخاري - رقم (${item.number})`,
                    text: item.arab, // النص العربي الصافي للحديث
                    source: "صحيح البخاري"
                };
            });

            // عرض البيانات بعد نجاح التحميل
            window.renderKnowledge('hadith');

        } catch (error) {
            console.error("خطأ في جلب المكتبة المحدثة:", error);
            
            // 🛡️ نظام الطوارئ (Fallback) لمنع الشاشة البيضاء تماماً
            window.DATA_HADITH = [
                { topic: "صحيح البخاري - حديث (1)", text: "عَنْ عُمَرَ بْنِ الْخَطَّابِ، قَالَ: سَمِعْتُ رَسُولَ اللَّهِ ﷺ يَقُولُ: «إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى...»", source: "صحيح البخاري" },
                { topic: "صحيح البخاري - حديث (10)", text: "عَنْ أَبِي هُرَيْرَةَ، عَنِ النَّبِيِّ ﷺ قَالَ: «الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ».", source: "صحيح البخاري" },
                { topic: "تنبيه النظام", text: "تعذر الاتصال بالمكتبة السحابية حالياً بسبب ضعف الشبكة. يرجى سحب الشاشة للأسفل لتحديث البيانات.", source: "نظام إخلاص" }
            ];
            
            box.innerHTML = `
                <div class="card" style="text-align:center; color:#e11d48; padding:20px; border:1px solid rgba(225,29,72,0.3);">
                    <h3 style="margin-bottom:10px;">⚠️ فشل الاتصال بالإنترنت</h3>
                    <p>تعذر جلب المكتبة. سيتم عرض الأحاديث المحفوظة محلياً.</p>
                </div>
            `;
            
            setTimeout(() => window.renderKnowledge('hadith'), 2000);
        }
    }

    // 2. دالة العرض الزجاجية الفاخرة
    window.renderKnowledge = function(category) {
        const box = document.getElementById('knowledge-content');
        if (!box) return;
        
        let dataToRender = [];
        if (category === 'hadith') dataToRender = window.DATA_HADITH;
        else if (category === 'sunnah') dataToRender = window.DATA_SUNNAH;
        else if (category === 'stories') dataToRender = window.DATA_STORIES;
        
        // جلب الأحاديث إذا لم تكن محملة
        if (dataToRender.length === 0 && category === 'hadith') {
            loadCompleteHadithLibrary();
            return;
        }

        if (dataToRender.length === 0) {
            box.innerHTML = `<div style="text-align:center; padding:20px;">البيانات قيد التحديث...</div>`;
            return;
        }

        box.innerHTML = dataToRender.map(item => `
            <div class="card premium-ripple-target" style="border-right: 4px solid var(--primary); text-align:right; margin-bottom:15px; padding:15px; background:var(--glass-bg); border-radius:15px; animation: cinematic-enter 0.4s ease forwards;">
                <h3 style="color:var(--primary); margin-bottom:12px; font-size:1.1rem; border-bottom:1px solid rgba(128,128,128,0.1); padding-bottom:8px;">
                    ${item.title || item.topic}
                </h3>
                <p style="text-align:justify; line-height:1.8; font-size:1.15rem; font-weight: 500;">
                    ${item.text || item.desc}
                </p>
                <div style="margin-top:12px; border-top:1px dashed rgba(128,128,128,0.2); padding-top:8px;">
                    <small style="color:var(--text-muted); font-weight:bold; background: rgba(128,128,128,0.1); padding: 4px 8px; border-radius: 6px;">
                        المصدر: ${item.source}
                    </small>
                </div>
            </div>
        `).join('');
    };

    // 3. ربط أزرار التبويبات (أحاديث، سنن، قصص)
    document.addEventListener('DOMContentLoaded', () => {
        const knowledgeTabs = document.querySelectorAll('#knowledge-tabs-nav .tab-btn');
        if (knowledgeTabs.length > 0) {
            knowledgeTabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    knowledgeTabs.forEach(t => t.classList.remove('active'));
                    this.classList.add('active');
                    window.renderKnowledge(this.getAttribute('data-source'));
                });
            });
            // استدعاء الأحاديث كافتراضي
            window.renderKnowledge('hadith');
        }
    });
