/* أدوات: حاسبة الزكاة + أقرب مسجد (تفتح تطبيق الخرائط). تُحقن في الصفحة الرئيسية */
(function(){
const $=id=>document.getElementById(id);
const n=id=>{const v=parseFloat(($(id)||{}).value);return isFinite(v)&&v>0?v:0;};
function zakat(){
  const ov=document.createElement('div');ov.className='ob-overlay';
  ov.innerHTML='<div class="ob-card zk"><h2>🧮 حاسبة الزكاة</h2>'+
  [['zk-gp','سعر غرام الذهب عيار 24 (بعملتك)'],['zk-g','ذهب تملكه (غرام، محوَّل إلى عيار 24)'],['zk-c','نقد وأرصدة'],['zk-t','عروض تجارة'],['zk-d','ديون حالّة عليك']]
   .map(function(r){return '<label>'+r[1]+'<input id="'+r[0]+'" type="number" inputmode="decimal" min="0"></label>';}).join('')+
  '<div id="zk-out" class="zk-out"></div><button class="ob-main" id="zk-go">احسب</button><button class="ob-skip" id="zk-x">إغلاق</button></div>';
  document.body.appendChild(ov);
  $('zk-x').onclick=()=>ov.remove();
  $('zk-go').onclick=function(){
    const gp=n('zk-gp'),nis=85*gp,wealth=n('zk-g')*gp+n('zk-c')+n('zk-t')-n('zk-d');
    const o=$('zk-out');
    if(!gp){o.textContent='أدخل سعر غرام الذهب أولاً.';return;}
    o.innerHTML=wealth>=nis?'النصاب ('+'85 غرام ذهب): '+nis.toFixed(2)+'<br>صافي مالك: '+wealth.toFixed(2)+'<br><b>الزكاة الواجبة (2.5%): '+(wealth*0.025).toFixed(2)+'</b><br><small>بشرط مرور الحول القمري.</small>'
     :'صافي مالك ('+wealth.toFixed(2)+') أقل من النصاب ('+nis.toFixed(2)+')، فلا زكاة عليك الآن.<br><small>للحالات الخاصة راجع أهل العلم.</small>';};
}
function mosque(){
  const L=AppState.userLocation,u='https://www.google.com/maps/search/mosque/@'+L.lat+','+L.lng+',15z';
  window.open(u,'_blank');
}
function inject(){
  const h=$('view-home');if(!h||$('tools-card'))return;
  const c=document.createElement('div');c.id='tools-card';c.className='card tools-card';
  c.innerHTML='<button id="t-zk">🧮 حاسبة الزكاة</button><button id="t-ms">🕌 أقرب مسجد</button>';
  h.appendChild(c);$('t-zk').onclick=zakat;$('t-ms').onclick=mosque;
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',inject);else inject();
})();
