/* شاشة الأذان: تشغيل الأذان كاملاً + شاشة زجاجية بلون الصلاة. تعمل عند دخول الوقت، وعند فتح إشعار الأذان، وعند العودة للتطبيق */
(function(){'use strict';
const NAMES={Fajr:'الفجر',Sunrise:'الشروق',Dhuhr:'الظهر',Asr:'العصر',Maghrib:'المغرب',Isha:'العشاء'};
const ICON={Fajr:'stars',Sunrise:'sunrise',Dhuhr:'sun',Asr:'cloudsun',Maghrib:'sunset',Isha:'moon'};
const EMO={Fajr:'✨',Sunrise:'🌅',Dhuhr:'☀️',Asr:'🌤️',Maghrib:'🌇',Isha:'🌙'};
const SEQ=['Fajr','Dhuhr','Asr','Maghrib','Isha'];
const SK='ikhlas_adhan_shown',WINDOW=2; /* دقائق يُسمح فيها بالتعويض إن فات الوقت والتطبيق بالخلفية */
const $=s=>document.querySelector(s);
const AS=()=>typeof AppState!=='undefined'?AppState:null;
const get=k=>{try{return localStorage.getItem(k)}catch(e){return null}};
const put=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const mins=s=>{const p=String(s).split(':');return +p[0]*60+ +p[1]};
const fmt=s=>{const p=String(s).split(':'),h=+p[0],m=p[1];return ((h%12)||12)+':'+m+' '+(h<12?'ص':'م')};
const dayKey=d=>d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();
let audio=null,ov=null,wake=null,curKey=null,nat=false; /* nat: الأذان يُشغَّل من خدمة أندرويد الأصلية */
const AN=()=>window.NativeAdhan&&NativeAdhan.plugin?NativeAdhan.plugin():null;
const nstop=()=>{try{const a=AN();a&&a.stop()}catch(e){}};

function url(){const id=get('IkhlasAdhanId');return window.AdhanRegistry?AdhanRegistry.urlFor(id):'https://download.quranicaudio.com/adhan/makkah.mp3'}
function soundName(){return window.AdhanRegistry?AdhanRegistry.get(get('IkhlasAdhanId')).name:''}
function nextOf(k){const a=AS(),T=a&&a.prayerTimes;if(!T)return '';const i=SEQ.indexOf(k);
  const n=k==='Sunrise'?'Dhuhr':SEQ[(i+1)%5];return T[n]?'الصلاة التالية: '+NAMES[n]+' · '+fmt(T[n]):''}
function icon(k){try{return window.Icons?Icons.html(ICON[k]):EMO[k]}catch(e){return EMO[k]}}

function stopAudio(){if(audio){try{audio.pause();audio.currentTime=0}catch(e){}}}
async function lock(){try{if(navigator.wakeLock)wake=await navigator.wakeLock.request('screen')}catch(e){}}
function unlock(){try{wake&&wake.release()}catch(e){}wake=null}
function media(k){try{if('mediaSession'in navigator){navigator.mediaSession.metadata=new MediaMetadata({title:'أذان '+NAMES[k],artist:soundName(),album:'إخلاص'});
  navigator.mediaSession.setActionHandler('pause',()=>toggle());navigator.mediaSession.setActionHandler('play',()=>toggle());navigator.mediaSession.setActionHandler('stop',()=>close())}}catch(e){}}

function setPlaying(on){if(!ov)return;ov.classList.toggle('playing',on);const b=ov.querySelector('[data-a=t]');if(b)b.textContent=on?(nat?'⏹ إيقاف الأذان':'⏸ إيقاف مؤقت'):'▶ تشغيل الأذان'}
function play(){try{if(window.muezzinAudio)window.muezzinAudio.pause()}catch(e){}
  if(!audio){audio=new Audio();audio.preload='auto';
    audio.addEventListener('timeupdate',()=>{const p=ov&&ov.querySelector('.p');if(p&&audio.duration)p.style.strokeDashoffset=326.7*(1-audio.currentTime/audio.duration)});
    audio.addEventListener('error',()=>{const u=audio.getAttribute('data-u'),r=window.AdhanRegistry&&AdhanRegistry.get(get('IkhlasAdhanId')).remote;if(r&&u!==r){audio.src=r;audio.setAttribute('data-u',r);audio.play().catch(()=>setPlaying(false))}else setPlaying(false)});
    audio.addEventListener('play',()=>setPlaying(true));audio.addEventListener('pause',()=>setPlaying(false));
    audio.addEventListener('ended',()=>{setPlaying(false);const p=ov&&ov.querySelector('.p');if(p)p.style.strokeDashoffset=0})}
  const u=url();if(audio.getAttribute('data-u')!==u){audio.src=u;audio.setAttribute('data-u',u)}
  const r=audio.play();if(r&&r.catch)r.catch(()=>setPlaying(false))}
function toggle(){if(nat){nstop();nat=false;setPlaying(false);return}if(!audio||audio.paused)play();else audio.pause()}
function close(){if(nat){nstop();nat=false}stopAudio();unlock();const o=ov;ov=null;curKey=null;
  if(o){o.classList.remove('on');setTimeout(()=>o.remove(),500)}}

function show(k,opt){opt=opt||{};if(!NAMES[k])return;
  if(ov){if(ov.dataset.k===k)return;close()}
  const T=(AS()&&AS().prayerTimes)||{},tm=T[k]||'';
  ov=document.createElement('div');ov.id='adhan-screen';ov.dataset.p=k.toLowerCase();ov.dataset.k=k;
  ov.setAttribute('role','alertdialog');ov.setAttribute('aria-label','أذان '+NAMES[k]);
  const line=k==='Fajr'?'الصلاة خير من النوم':k==='Sunrise'?'طلعت الشمس، فاذكر الله':'حيّ على الصلاة · حيّ على الفلاح';
  ov.innerHTML='<i class="as-blob as-b1"></i><i class="as-blob as-b2"></i><div class="as-card">'+
   '<div class="as-ring"><svg viewBox="0 0 120 120"><circle class="t" cx="60" cy="60" r="52"/><circle class="p" cx="60" cy="60" r="52"/></svg><div class="as-ic">'+icon(k)+'</div></div>'+
   '<div class="as-kicker">حان الآن موعد أذان</div><div class="as-name">'+NAMES[k]+'</div>'+(tm?'<div class="as-time">'+fmt(tm)+'</div>':'')+
   '<div class="as-who">'+soundName()+'</div><div class="as-wave">'+Array.from({length:21},(_,i)=>'<i style="animation-delay:'+(-(i*.09)).toFixed(2)+'s"></i>').join('')+'</div>'+
   '<div class="as-line">'+line+'</div><div class="as-next">'+nextOf(k)+'</div>'+
   '<div class="as-row"><button class="main" data-a="t">▶ تشغيل الأذان</button><button data-a="c">إغلاق</button></div></div>';
  ov.addEventListener('click',e=>{const a=e.target.closest('[data-a]');if(!a)return;a.dataset.a==='t'?toggle():close()});
  document.body.appendChild(ov);requestAnimationFrame(()=>requestAnimationFrame(()=>ov&&ov.classList.add('on')));
  curKey=k;lock();media(k);
  if(window.triggerHapticPro)try{triggerHapticPro([300,150,300])}catch(e){}else if(navigator.vibrate)navigator.vibrate([300,150,300]);
  nat=!!opt.native;
  if(nat){stopAudio();setPlaying(true)}
  else{if(opt.play!==false&&k!=='Sunrise')play();
  if(k==='Sunrise'||opt.play===false)setPlaying(false)}}

/* مراقب الوقت: يعمل كل ثانيتين، ويعوّض ≤2 دقيقة إن كانت الشاشة مطفأة/التطبيق بالخلفية */
function check(){const a=AS(),T=a&&a.prayerTimes;if(!T||!T.Fajr)return;
  const on=$('#setting-adhan-enabled');if(on&&!on.checked)return;
  const now=new Date(),n=now.getHours()*60+now.getMinutes(),cfg=a.prayerConfig||{};
  for(const k of SEQ){if(!T[k]||cfg[k]===false||cfg[k]===0)continue;
    const el=n-mins(T[k]);if(el<0||el>WINDOW)continue;
    const key=dayKey(now)+'-'+k;if(get(SK)===key)continue;put(SK,key);
    const an=AN();if(!an){show(k);return}
    setTimeout(async()=>{let p=false;try{p=(await an.status()).playing}catch(e){}show(k,{native:p})},2500);return}}
function fromNotif(n){const k=n&&n.extra&&n.extra.prayer;if(!k||!NAMES[k])return;
  const key=dayKey(new Date())+'-'+k;put(SK,key);show(k)}

function nativeAdhanHooks(){const an=AN();if(!an)return;
  const launch=e=>{const k=e&&e.prayer;if(!k||!NAMES[k])return;put(SK,dayKey(new Date())+'-'+k);show(k,e.playing?{native:true}:{play:false})};
  try{an.getLaunch().then(launch).catch(()=>{})}catch(e){}
  try{an.addListener('adhanLaunch',launch)}catch(e){}
  /* الخدمة بدأت/انتهت: نوقف صوت الويب لتفادي التكرار ونعكس الحالة على الشاشة */
  try{an.addListener('adhanState',e=>{
    if(e.playing){stopAudio();nat=true;if(ov)setPlaying(true);else if(NAMES[e.prayer]){put(SK,dayKey(new Date())+'-'+e.prayer);show(e.prayer,{native:true})}}
    else if(nat){nat=false;setPlaying(false)}})}catch(e){}}
function nativeHooks(){nativeAdhanHooks();const C=window.Capacitor,ln=C&&C.Plugins&&C.Plugins.LocalNotifications;if(!ln)return;
  try{ln.addListener('localNotificationActionPerformed',e=>fromNotif(e.notification))}catch(e){}
  try{ln.addListener('localNotificationReceived',n=>fromNotif(n))}catch(e){}
  try{const ap=C.Plugins.App;ap&&ap.addListener('appStateChange',s=>{if(s.isActive)check()})}catch(e){}}

/* زر معاينة في الإعدادات */
function addPreview(){const t=$('#test-adhan-btn');if(!t||$('#as-prev'))return;
  const b=document.createElement('button');b.id='as-prev';b.className='btn-secondary as-prev-btn';b.textContent='🖼 معاينة شاشة الأذان';
  b.style.cssText='border-color:var(--accent);color:var(--accent)';
  b.onclick=()=>{const p=window.Personal?Personal.period():'dhuhr';const k=p.charAt(0).toUpperCase()+p.slice(1);show(NAMES[k]?k:'Dhuhr',{play:false})};
  t.insertAdjacentElement('afterend',b)}

window.AdhanScreen={show:show,close:close,toggle:toggle,preview:k=>show(k||'Maghrib',{play:false}),check:check};
document.addEventListener('visibilitychange',()=>{if(!document.hidden)check()});
document.addEventListener('DOMContentLoaded',()=>{nativeHooks();setInterval(check,2000);let n=0;const t=setInterval(()=>{addPreview();if($('#as-prev')||n++>20)clearInterval(t)},700)});
})();
