/* مكتبة القصص والسنن: تصنيفات + بحث + مفضلة + نسخ. تُحمَّل بعد plus.js */
(function(){'use strict';
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const plain=s=>String(s).replace(/[\u064B-\u0652\u0670\u0640]/g,'').replace(/[إأآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه');
const LS=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}};
const SV=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const FAV=LS('ikhlas_lib2_fav',[]);
const st={stories:{q:'',c:'all'},sunnah:{q:'',c:'all'}};
function items(src){
  let a=[];
  try{a=src==='stories'?STORIES_DATA.slice():SUNNAH_DATA.slice();}catch(e){}
  if(src==='stories'){
    const seen=new Set(a.map(i=>plain(i.title).replace(/\s/g,'')));
    (window.STORIES_EXTRA||[]).forEach(i=>{const k=plain(i.title).replace(/\s/g,'');if(!seen.has(k)){seen.add(k);a.push(i);}});
    a.forEach(i=>{if(!i.c)i.c='قصص وعبر عامة';});
  }else a.forEach(i=>{if(!i.c)i.c='سنن مهجورة';});
  return a;
}
const key=i=>plain(i.title).replace(/\s/g,'').slice(0,40);
function draw(src,box){
  const all=items(src),S=st[src],q=plain(S.q).trim();
  const cats=[...new Set(all.map(i=>i.c))];
  const list=all.filter(i=>(S.c==='all'||(S.c==='fav'?FAV.includes(key(i)):i.c===S.c))&&(!q||plain(i.title+' '+i.desc+' '+(i.source||'')).includes(q)));
  box.innerHTML=`<input class="xp-search" id="l2-q" placeholder="🔍 ابحث في ${src==='stories'?'القصص':'السنن'}..." value="${esc(S.q)}">
  <div class="xp-chips" id="l2-cats"><button class="xp-chip ${S.c==='all'?'on':''}" data-cat="all">الكل (${all.length})</button><button class="xp-chip ${S.c==='fav'?'on':''}" data-cat="fav">⭐ المفضلة</button>${cats.map(c=>`<button class="xp-chip ${S.c===c?'on':''}" data-cat="${esc(c)}">${esc(c)}</button>`).join('')}</div>
  <div id="l2-list">${list.map(i=>`<div class="card xp-card"><h3>${esc(i.title)}</h3><p>${esc(i.desc)}</p><small>${esc(i.source||'')}</small><div class="xp-row"><button class="xp-btn xp-fav ${FAV.includes(key(i))?'on':''}" data-fav="${esc(key(i))}">★ مفضلة</button><button class="xp-btn" data-cp="${esc(key(i))}">📋 نسخ</button></div></div>`).join('')||'<div class="xp-info">لا نتائج</div>'}</div>`;
  const inp=$('#l2-q');
  inp.oninput=e=>{S.q=e.target.value;const pos=e.target.selectionStart;draw(src,box);const n=$('#l2-q');n.focus();n.setSelectionRange(pos,pos);};
  box.onclick=e=>{const b=e.target.closest('button');if(!b)return;
    if(b.dataset.cat){S.c=b.dataset.cat;draw(src,box);}
    else if(b.dataset.fav){const j=FAV.indexOf(b.dataset.fav);j<0?FAV.push(b.dataset.fav):FAV.splice(j,1);SV('ikhlas_lib2_fav',FAV);b.classList.toggle('on',j<0);if(S.c==='fav')draw(src,box);}
    else if(b.dataset.cp){const i=all.find(x=>key(x)===b.dataset.cp);if(i){const t=i.title+'\n'+i.desc+'\n— '+(i.source||'');(navigator.share?navigator.share({text:t}):navigator.clipboard.writeText(t)).catch(()=>{});b.textContent='✓ تم';setTimeout(()=>b.textContent='📋 نسخ',1200);}}
  };
}
const orig=window.renderKnowledge;
window.renderKnowledge=function(src){
  const box=$('#knowledge-content');
  if(box&&(src==='stories'||src==='sunnah')){draw(src,box);return;}
  return orig&&orig.apply(this,arguments);
};
/* واجهة برمجية صغيرة يستعملها المساعد */
window.IkhlasLib={openKnowledge(tab,query){
  try{switchView('knowledge');}catch(e){}
  const b=document.querySelector(`#knowledge-tabs-nav .tab-btn[data-source="${tab}"]`);if(b)b.click();
  if(query)setTimeout(()=>{const i=$('#xh-q')||$('#l2-q');if(i){i.value=query;i.dispatchEvent(new Event('input'));}},150);
},openAdhkar(cat){
  try{switchView('adhkar');}catch(e){}
  setTimeout(()=>{const b=document.querySelector(`#al-cats [data-c="${cat}"]`);if(b)b.click();},250);
}};
})();
