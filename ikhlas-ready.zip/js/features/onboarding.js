/* شاشات الترحيب: الموقع ← طريقة الحساب ← الإشعارات. تظهر مرة واحدة فقط */
(function(){
const KEY='IkhlasOnboarded';
try{if(localStorage.getItem(KEY))return;}catch(e){}
const S=[
 {i:'📍',t:'موقعك',d:'نحسب مواقيت الصلاة والقبلة على جهازك مباشرة، دون إرسال موقعك لأي جهة.',b:'السماح بالموقع',a:function(){return new Promise(function(ok){
   if(!navigator.geolocation)return ok();
   navigator.geolocation.getCurrentPosition(function(p){AppState.userLocation.lat=p.coords.latitude;AppState.userLocation.lng=p.coords.longitude;try{calculatePrayerTimes();}catch(e){}ok();},ok,{timeout:12000});});}},
 {i:'🧮',t:'طريقة الحساب',d:'اختر ما تعتمده دار الإفتاء في بلدك.',sel:true,b:'التالي',a:function(o){var s=document.getElementById('setting-calc-method');if(s&&o){s.value=o;s.dispatchEvent(new Event('change'));try{calculatePrayerTimes();}catch(e){}}}},
 {i:'🔔',t:'الإشعارات',d:'ليصلك الأذان في وقته حتى والتطبيق مغلق.',b:'تفعيل الأذان',a:function(){if(window.NativeAdhan)return NativeAdhan.reschedule();if(window.Notification&&Notification.permission==='default')return Notification.requestPermission();}}];
let n=0;
function done(){try{localStorage.setItem(KEY,'1');}catch(e){}ov.remove();}
const ov=document.createElement('div');ov.className='ob-overlay';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');
function render(){
  const s=S[n];let sel='';
  if(s.sel){const m=document.getElementById('setting-calc-method');sel='<select id="ob-method">'+(m?[].map.call(m.options,function(o){return '<option value="'+o.value+'"'+(o.selected?' selected':'')+'>'+o.text+'</option>';}).join(''):'')+'</select>';}
  ov.innerHTML='<div class="ob-card"><div class="ob-ico">'+s.i+'</div><h2>'+s.t+'</h2><p>'+s.d+'</p>'+sel+
   '<button class="ob-main">'+s.b+'</button><button class="ob-skip">'+(n<S.length-1?'تخطَّ':'لاحقاً')+'</button>'+
   '<div class="ob-dots">'+S.map(function(_,i){return '<i'+(i===n?' class="on"':'')+'></i>';}).join('')+'</div></div>';
  ov.querySelector('.ob-main').onclick=async function(){var m=ov.querySelector('#ob-method');try{await s.a(m&&m.value);}catch(e){}next();};
  ov.querySelector('.ob-skip').onclick=next;
}
function next(){n++;if(n>=S.length)done();else render();}
function start(){document.body.appendChild(ov);render();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
