/* الطابع الشخصي: اسم المستخدم ← تحية بحسب وقت الصلاة (وألوانها) في الواجهة والإشعارات، ودعاء الوالدين عند الخروج */
(function(){'use strict';
const NK='ikhlas_username',AK='ikhlas_name_asked',MK='ikhlas_exit_dua_mode',LK='ikhlas_exit_dua_last';
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const get=(k,d)=>{try{return localStorage.getItem(k)||d}catch(e){return d}};
const put=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};

/* الفترات تتبع أوقات الصلاة الفعلية: كل فترة تبدأ بأذانها. g=صيغ التحية، c=لونا الفترة، i=اسم الأيقونة */
const PER={
 fajr:{g:['بارك الله في فجرك','فجرٌ مبارك','نوّر الله فجرك'],c:['#0284c7','#1e3a8a'],i:'stars'},
 sunrise:{g:['صباح الخير','صباح النور','صباحك بركة'],c:['#ea580c','#facc15'],i:'sunrise'},
 dhuhr:{g:['طاب يومك','نهارك مبارك','ظهرٌ مبارك'],c:['#0d9488','#2dd4bf'],i:'sun'},
 asr:{g:['عصر مبارك','عصرك طيّب','عصرٌ بذكر الله'],c:['#d97706','#fbbf24'],i:'cloudsun'},
 maghrib:{g:['مساء الخير','مساء النور','مغرب مبارك'],c:['#be185d','#fb923c'],i:'sunset'},
 isha:{g:['طابت ليلتك','ليلة هانئة','ليلك سكينة'],c:['#4338ca','#1e1b4b'],i:'moon'}};
const ORDER=['Fajr','Sunrise','Dhuhr','Asr','Maghrib','Isha'];
const ico=n=>window.Icons?Icons.html(n):'';
const AS=()=>typeof AppState!=='undefined'?AppState:null; /* AppState معرّف بـ const فلا يظهر على window */
const mins=s=>{const p=String(s).split(':');return +p[0]*60+ +p[1]};

function name(){return get(NK,'')}
function setName(v){v=String(v||'').replace(/\s+/g,' ').trim().slice(0,24);if(v)put(NK,v);else try{localStorage.removeItem(NK)}catch(e){}
 paint();try{window.NativeAdhan&&NativeAdhan.reschedule()}catch(e){}}

function period(d){
 d=d||new Date();const a=AS(),T=a&&a.prayerTimes&&a.prayerTimes.Fajr?a.prayerTimes:null;
 const n=d.getHours()*60+d.getMinutes();
 if(T){let cur='isha';ORDER.forEach(k=>{if(T[k]&&n>=mins(T[k]))cur=k.toLowerCase()});return cur}
 const h=d.getHours();return h>=4&&h<6?'fajr':h>=6&&h<11?'sunrise':h>=11&&h<15?'dhuhr':h>=15&&h<18?'asr':h>=18&&h<19?'maghrib':'isha'}
const dayNo=d=>Math.floor((d-new Date(d.getFullYear(),0,0))/864e5);
/* تحية الفترة p (اختياري) مع الاسم؛ تتنوّع الصيغة بحسب اليوم */
function greet(p,d){d=d||new Date();p=p||period(d);const P=PER[p]||PER.dhuhr,g=P.g[[0,0,1,2][dayNo(d)%4]%P.g.length],n=name();return n?g+' يا '+n:g}
const key2p=k=>String(k).toLowerCase();
/* نص الإشعار لصلاة k (Fajr...) في يوم d */
function line(k,d){return greet(key2p(k),d)+'، '+(k==='Sunrise'?'طلعت الشمس':'حيّ على الصلاة')}
function color(k){return (PER[key2p(k)]||PER.dhuhr).c[0]}

/* ألوان الفترة تُنشر كمتغيّرات CSS وتنتقل بنعومة */
function paint(){
 const p=period(),P=PER[p],r=document.documentElement;
 r.style.setProperty('--pz-a',P.c[0]);r.style.setProperty('--pz-b',P.c[1]);
 if(document.body){document.body.dataset.period=p;
  ['fajr','sunrise','dhuhr','asr','maghrib','isha'].forEach(x=>document.body.classList.toggle('aura-'+x,x===p))}
 const el=$('#pz-greet');if(el&&!el.classList.contains('nz')){const e=el.querySelector('.pz-e');if(e.dataset.i!==P.i){e.dataset.i=P.i;e.innerHTML=ico(P.i)}el.querySelector('.pz-t').textContent=greet(p)+(name()?'':' · أضف اسمك')}
 const pv=$('#pz-preview');if(pv)pv.innerHTML=ico(P.i)+' '+esc(greet(p))}

function note(msg){let t=$('#pz-toast');if(!t){t=document.createElement('div');t.id='pz-toast';document.body.appendChild(t)}
 t.textContent=msg;t.classList.add('on');clearTimeout(note.h);note.h=setTimeout(()=>t.classList.remove('on'),2800)}

/* ===== نافذة الاسم ===== */
function askName(){
 if($('#pz-name-ov'))return;
 const ov=document.createElement('div');ov.className='pz-ov';ov.id='pz-name-ov';
 ov.innerHTML='<div class="pz-card"><div class="pz-ic">'+ico(PER[period()].i)+'</div><h3>ما اسمك؟</h3><p>سنناديك به في التحية والإشعارات، مثل: «'+esc(greet(period()).replace(/ يا .*$/,''))+' يا ...»</p>'+
  '<input class="pz-in" id="pz-name-in" maxlength="24" placeholder="اكتب اسمك" autocomplete="given-name" value="'+esc(name())+'"><button class="btn-primary pz-full" data-pz="ok">حفظ</button><button class="pz-skip" data-pz="later">لاحقاً</button></div>';
 ov.addEventListener('click',e=>{const a=e.target.dataset.pz;if(!a)return;put(AK,'1');
  if(a==='ok'){const v=$('#pz-name-in').value.trim();if(!v){$('#pz-name-in').focus();return}setName(v);note('أهلاً بك يا '+name())}
  ov.remove()});
 document.body.appendChild(ov);setTimeout(()=>{const i=$('#pz-name-in');i&&i.focus()},250)}

/* ===== بطاقة الإعدادات ===== */
function settingsCard(){
 const v=$('#view-settings');if(!v||$('#pz-settings'))return;
 const c=document.createElement('div');c.className='card pz-set';c.id='pz-settings';
 const m=get(MK,'all');
 c.innerHTML='<h3>'+ico('user')+' اسمك والتحية</h3><div class="pz-pv" id="pz-preview"></div>'+
  '<input class="pz-in pz-inl" id="pz-set-name" maxlength="24" placeholder="اسمك" value="'+esc(name())+'"><button class="btn-secondary pz-full" data-pz="save">حفظ الاسم</button>'+
  '<small>يظهر في التحية أعلى الشاشة وفي إشعارات الأذان، وتتغير التحية وألوانها مع كل وقت صلاة.</small>'+
  '<div class="pz-lbl">'+ico('hands')+' دعاء الوالدين عند الخروج</div><select class="pz-in pz-inl" id="pz-mode"><option value="all">للجميع (أحياء وأموات)</option><option value="living">للوالدين الأحياء</option><option value="deceased">للوالدين المتوفَّين</option></select>';
 const h=v.querySelector('.section-header');if(h)h.after(c);else v.prepend(c);
 $('#pz-mode').value=m;
 c.addEventListener('click',e=>{if(e.target.dataset.pz!=='save')return;const b=e.target;setName($('#pz-set-name').value);put(AK,'1');b.innerHTML=ico('check')+' تم الحفظ';setTimeout(()=>{b.textContent='حفظ الاسم'},1500)});
 c.addEventListener('change',e=>{if(e.target.id==='pz-mode')put(MK,e.target.value)});
 paint()}

/* ===== دعاء الخروج ===== */
let open=false;
function pool(){const m=get(MK,'all'),L=window.PARENT_DUAS_V2||[];return L.map((d,i)=>({d:d,i:i})).filter(o=>o.d.t==='q'||o.d.t==='g'||m==='all'||o.d.t===(m==='living'?'l':'d'))}
function pick(){const p=pool();if(!p.length)return{x:'رب اغفر لي ولوالدي وارحمهما كما ربياني صغيراً.',s:''};
 const last=+get(LK,-1);let o;for(let n=0;n<6;n++){o=p[Math.floor(Math.random()*p.length)];if(o.i!==last||p.length<2)break}
 put(LK,o.i);return o.d}
function showDua(){const d=pick(),t=$('#exit-random-dua-text'),s=$('#exit-dua-src');if(t)t.textContent=d.t==='q'?'﴿ '+d.x+' ﴾':d.x;if(s)s.textContent=d.s?'— '+d.s:''}
function render(){
 const m=$('#custom-exit-modal'),card=m&&m.querySelector('.exit-card');if(!card)return;
 const p=period(),n=name();
 card.innerHTML='<div class="pz-xtop"><span>'+ico(PER[p].i)+'</span><h3>'+(n?'في أمان الله يا '+esc(n):'في أمان الله')+'</h3><p>هل تودّ مغادرة التطبيق؟</p></div>'+
  '<div class="exit-dua-box"><h4>'+ico('hands')+' دعاء لوالديّ قبل أن تمضي</h4><p id="exit-random-dua-text" class="pz-dua"></p><small id="exit-dua-src" class="pz-src"></small><button class="pz-more" data-pz="more">'+ico('refresh')+' دعاء آخر</button></div>'+
  '<div class="pz-xbtns"><button class="btn-secondary pz-out" data-pz="out">نعم، خروج</button><button class="btn-primary" data-pz="stay">البقاء '+ico('hands')+'</button></div>';
 showDua()}
function show(){const m=$('#custom-exit-modal');if(!m||open)return;open=true;render();m.style.display='flex';requestAnimationFrame(()=>m.classList.add('show'));try{navigator.vibrate&&navigator.vibrate([30,50,30])}catch(e){}}
function hide(){const m=$('#custom-exit-modal');if(!m)return;open=false;m.classList.remove('show');setTimeout(()=>{if(!open)m.style.display='none'},300)}
const capApp=()=>{const C=window.Capacitor;if(!C||!(C.isNativePlatform&&C.isNativePlatform()))return null;
 try{return (C.Plugins&&C.Plugins.App)||(C.registerPlugin&&C.registerPlugin('App'))||null}catch(e){return null}};
function exit(){const A=capApp();hide();
 if(A&&A.exitApp){A.exitApp();return}
 try{window.close()}catch(e){}
 setTimeout(()=>note('جزاك الله خيراً، يمكنك إغلاق التطبيق الآن'),350)}

/* زر الرجوع: النوافذ المفتوحة ← الصفحة السابقة ← دعاء الخروج (المنطق في nav.js) */
function onBack(){
 if(open){hide();return}
 if(window.AppNav&&AppNav.back())return;
 show()}
function bindBack(){
 const A=capApp();
 if(A&&A.addListener){
  /* أندرويد (Capacitor): نمسك الزر بالكامل فلا يخرج التطبيق إلا من نافذة دعاء الخروج */
  try{const r=A.addListener('backButton',onBack);if(r&&r.catch)r.catch(bindWeb);return}catch(e){}
 }
 bindWeb()}
/* متصفح/PWA/WebView: أندرويد يتجاهل مداخل السجل المضافة بلا لمسة (ومنها ما يُضاف داخل popstate)،
   فيخرج التطبيق عند الرجوع الثاني. لذا نضيف حرّاساً عند لمسات المستخدم فقط ونُبقي عدة منها. */
function bindWeb(){
 if(bindWeb.done)return;bindWeb.done=true;
 const MAX=8;let g=0;
 const arm=()=>{if(g<MAX){try{history.pushState({ik:1},'');g++}catch(e){}}};
 ['pointerdown','touchstart','click','keydown'].forEach(t=>addEventListener(t,arm,{capture:true,passive:true}));
 arm();
 addEventListener('popstate',()=>{g=Math.max(0,g-1);onBack();if(g<1)arm()})}

function build(){
 const hj=$('#hijri-date-display');
 if(hj&&!$('#pz-greet')){const g=document.createElement('button');g.type='button';g.id='pz-greet';g.className='pz-greet';g.innerHTML='<span class="pz-e"></span><span class="pz-t"></span>';g.onclick=()=>{if(name()&&window.Nouri){Nouri.poke();return}askName()};hj.after(g)}
 const m=$('#custom-exit-modal');
 if(m)m.addEventListener('click',e=>{const a=e.target.dataset&&e.target.dataset.pz;
  if(a==='more'){showDua();try{navigator.vibrate&&navigator.vibrate(15)}catch(x){}}
  else if(a==='out')exit();else if(a==='stay'||e.target===m)hide()});
 const ex=$('#app-exit-trigger');if(ex){const c=ex.cloneNode(true);ex.replaceWith(c);c.addEventListener('click',e=>{e.preventDefault();show()})}
 settingsCard();paint();bindBack();
 setInterval(paint,30000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)paint()});
 /* أول مرة: اسأل عن الاسم بعد انتهاء شاشات الترحيب */
 if(!name()&&!get(AK,'')){let n=0;const w=setInterval(()=>{if(!$('.ob-overlay')||n++>90){clearInterval(w);setTimeout(()=>{if(!name())askName()},700)}},700)}}

window.Personal={name:name,setName:setName,period:period,greet:greet,line:line,color:color,ask:askName,repaint:paint};
window.PersonalExit={show:show,hide:hide,exit:exit,toggle:v=>v?show():hide()};
window.closeAppConfirm=function(x){x?exit():hide()};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',build);else build();
})();
