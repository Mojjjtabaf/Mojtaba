/* وقت التشغيل لتعديلات المطوّر: يُحمَّل قبل plus.js ليطبّق التعديلات المحفوظة (CSS/نصوص/إخفاء/محتوى/JS).
   الوضع الآمن: إذا فشل الإقلاع مرتين متتاليتين تُعطَّل التعديلات تلقائياً حتى لا يتعطّل التطبيق. */
(function(){'use strict';
const K='ikh-dev-data',B='ikh-dev-boot',OFF='ikh-dev-off';
const EMPTY=()=>({css:'',vars:{},texts:[],hides:[],hadith:[],adhkar:[],stories:[],js:[],htmls:[],attrs:[],qj:[],qt:[]});
const LS=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}};
const load=()=>Object.assign(EMPTY(),LS(K,{}));
const save=d=>{try{localStorage.setItem(K,JSON.stringify(d))}catch(e){}};
function cleanCss(c){c=String(c||'').slice(0,30000);
  if(/@import|expression\s*\(|javascript:|<\/?style|url\(\s*['"]?\s*(https?:|\/\/)/i.test(c))return null;return c;}
const okSel=s=>{try{return typeof s==='string'&&s.length<220&&document.querySelector(s)!==undefined}catch(e){return false}};
function cleanHtml(h){const t=document.createElement('template');t.innerHTML=String(h||'').slice(0,20000);
  t.content.querySelectorAll('script,iframe,object,embed,link,meta,base,form[action]').forEach(n=>n.remove());
  t.content.querySelectorAll('*').forEach(n=>[...n.attributes].forEach(a=>{const v=a.value.trim();
    if(/^on/i.test(a.name)||/^\s*(javascript|data:text\/html)/i.test(v)||(/^(src|href)$/i.test(a.name)&&/^\/\//.test(v)))n.removeAttribute(a.name);}));
  return t.innerHTML;}
const okAttr=(n,v)=>/^[a-z][\w:-]{0,30}$/i.test(n)&&!/^on/i.test(n)&&!/^\s*javascript/i.test(String(v));
const okVar=(n,v)=>/^--[\w-]{1,40}$/.test(n)&&/^[#\w\s.,%()\-+*/]{1,120}$/.test(String(v));
/* الوضع الآمن */
let n=(+localStorage.getItem(B)||0)+1;localStorage.setItem(B,n);
const safe=n>2||localStorage.getItem(OFF)==='1';
if(n>2){localStorage.setItem(OFF,'1');localStorage.setItem(B,'0');}
setTimeout(()=>localStorage.setItem(B,'0'),5000);
function css(d){
  let t='';const v=Object.keys(d.vars).filter(k=>okVar(k,d.vars[k])).map(k=>`${k}:${d.vars[k]}!important`).join(';');
  if(v)t+=`html body,html body[class]{${v}}\n`;
  if(d.hides.length)t+=d.hides.filter(okSel).map(s=>`${s}{display:none!important}`).join('\n')+'\n';
  const c=cleanCss(d.css);if(c)t+=c;return t;}
function texts(d){d.texts.forEach(r=>{try{document.querySelectorAll(r.sel).forEach(el=>{
  if(!el.children.length){if(el.textContent!==r.text)el.textContent=r.text;}
  else{const tn=[...el.childNodes].find(x=>x.nodeType===3&&x.textContent.trim());if(tn&&tn.textContent!==r.text)tn.textContent=r.text;}});}catch(e){}});}
let mo,tm;
function apply(){
  const d=load();let s=document.getElementById('dev-css');
  if(!s){s=document.createElement('style');s.id='dev-css';document.head.appendChild(s);}
  s.textContent=css(d);texts(d);extras(d);
  if(!mo&&(d.texts.length||d.htmls.length||d.attrs.length)){mo=new MutationObserver(()=>{clearTimeout(tm);tm=setTimeout(()=>{const x=load();texts(x);extras(x)},300)});mo.observe(document.body,{childList:true,subtree:true});}
}
function extras(d){
  (d.attrs||[]).forEach(r=>{try{if(!okAttr(r.name,r.value))return;document.querySelectorAll(r.sel).forEach(el=>{if(el.getAttribute(r.name)!==r.value)el.setAttribute(r.name,r.value)})}catch(e){}});
  (d.htmls||[]).forEach(r=>{try{const t=document.querySelector(r.sel);if(!t||document.querySelector('[data-dv-id="'+r.id+'"]'))return;
    const w=document.createElement('div');w.setAttribute('data-dv-id',r.id);w.style.display='contents';w.innerHTML=cleanHtml(r.html);
    if(r.pos==='replace'){t.replaceWith(w)}else if(r.pos==='afterbegin')t.prepend(w);else if(r.pos==='beforebegin')t.before(w);else if(r.pos==='afterend')t.after(w);else t.append(w);}catch(e){}});}
function merge(d){
  try{window.HADITH_LIB=(window.HADITH_LIB||[]).concat(d.hadith.map(h=>({c:h.c||'إضافات المطوّر',t:h.t,s:h.s,x:h.x})));}catch(e){}
  try{const E=window.ADHKAR_LIB_EXTRA=window.ADHKAR_LIB_EXTRA||{};d.adhkar.forEach(a=>{(E[a.cat]=E[a.cat]||[]).push({id:a.id,text:a.text,target:a.target||1,info:a.info||''})});}catch(e){}
  try{window.STORIES_EXTRA=(window.STORIES_EXTRA||[]).concat(d.stories);}catch(e){}
}
function runJs(d){d.js.filter(j=>j.on).forEach(j=>{try{new Function(j.code)();}catch(e){console.warn('dev js',j.name,e);}});}
window.DevRT={load,save,apply,cleanCss,cleanHtml,okAttr,okSel,okVar,safe,EMPTY,setOff:v=>localStorage.setItem(OFF,v?'1':'0')};
if(!safe){
  const d=load();merge(d);
  const go=()=>{apply();if(localStorage.getItem('ikh-dev-js')==='1')runJs(d);};
  document.readyState==='loading'?document.addEventListener('DOMContentLoaded',go):go();
}
})();
