/* v22: يوقف الحركات الدائمة أثناء التمرير/اللمس (تمنع إعادة حساب التمويه الخلفي كل إطار) ويعيدها بعد السكون */
(function(){'use strict';
const b=document.body;let t=0,on=false;
function set(v){if(on===v)return;on=v;b.classList.toggle('is-scrolling',v)}
function bump(){set(true);clearTimeout(t);t=setTimeout(()=>set(false),220)}
['scroll','touchmove','wheel'].forEach(e=>addEventListener(e,bump,{passive:true,capture:true}));
document.addEventListener('visibilitychange',()=>{b.classList.toggle('is-scrolling',document.hidden)});
})();
