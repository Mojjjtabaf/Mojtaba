/* v33: رسالة نوري تظهر داخل بطاقة التحية («صباحك بركة يا ...») ثم تعود إليها بانتقال ناعم، ونوري يتفاعل مع اللمس وتغيّر الصلاة. v18: شخصية «نوري». v28: اسم «إخلاص — صديق الجنة» عاد للرأس بجانب نوري، وشريط مواقيت الصلوات تحته، وإشعار نوري يطفو ثم يختفي */
(function(){'use strict';
const $=s=>document.querySelector(s);
const NAV=[['home','🏠','الرئيسية'],['quran','📖','القرآن'],['adhkar','🤲','الأذكار'],['tasbeeh','📿','السبحة'],['knowledge','📜','السنة'],['qibla','🧭','القبلة'],['khatmah','📅','الختمة']];
const TAP=['ما شاء الله عليك! 🌟','ابتسم، فالله معك 😊','ذكرٌ واحد يُنير قلبك ✨','أحبّك في الله! 💚','هل شربت ماءً اليوم؟ 💧','سبحان الله وبحمده 🌿','خطوة صغيرة كل يوم تكفي 🌱','تبسّمك في وجه أخيك صدقة 😄'];
const VIEW={quran:'نقرأ معاً بسم الله 📖',adhkar:'أذكار تُطمئن القلب 🤲',tasbeeh:'هيا نسبّح! 📿',knowledge:'علمٌ ينفع 📜',qibla:'نتجه إلى القبلة 🧭',khatmah:'نمضي في ختمتنا 📅',settings:'خصّص التطبيق كما تحب ⚙️'};
const h=new Date().getHours();
const HELLO=h<5?'قيام الليل شرف 🌙':h<12?'صباح النور والسرور ☀️':h<16?'طاب يومك ✨':h<19?'عصر مبارك 🌤️':'مساء الخير والطمأنينة 🌆';
const svg='<svg viewBox="0 0 64 64" aria-hidden="true"><defs><radialGradient id="crg" cx="35%" cy="28%" r="80%"><stop offset="0" stop-color="#fff8d6"/><stop offset=".45" stop-color="#fcd34d"/><stop offset="1" stop-color="#f59e0b"/></radialGradient></defs>'
+'<path class="cr-arm" d="M52 40c6-2 9-8 7-13" stroke="#f59e0b" stroke-width="5" stroke-linecap="round" fill="none"/>'
+'<circle cx="32" cy="36" r="24" fill="url(#crg)"/><ellipse cx="24" cy="24" rx="9" ry="5" fill="#fff" opacity=".45" transform="rotate(-25 24 24)"/>'
+'<path d="M14 18c3-8 12-12 20-9-8 0-13 5-14 12z" fill="var(--primary,#0d9488)"/><path class="cr-star" d="M47 9l1.8 4 4.2.4-3.2 2.8 1 4.2-3.8-2.3-3.8 2.3 1-4.2-3.2-2.8 4.2-.4z" fill="#fff" stroke="#f59e0b" stroke-width=".8"/>'
+'<g fill="#3b2200"><ellipse class="cr-eye" cx="24" cy="36" rx="3" ry="4"/><ellipse class="cr-eye" cx="40" cy="36" rx="3" ry="4"/></g><circle cx="25" cy="34.5" r="1.1" fill="#fff"/><circle cx="41" cy="34.5" r="1.1" fill="#fff"/>'
+'<ellipse cx="17" cy="44" rx="4.5" ry="3" fill="#fb7185" opacity=".55"/><ellipse cx="47" cy="44" rx="4.5" ry="3" fill="#fb7185" opacity=".55"/>'
+'<g class="cr-mouth"><path d="M25 45c3 5 11 5 14 0z" fill="#7c2d12"/><path d="M28 48c2 1.6 6 1.6 8 0" stroke="#fb7185" stroke-width="2" fill="none" stroke-linecap="round"/></g></svg>';
const MINI='<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="34" r="27" fill="#fbbf24"/><ellipse cx="23" cy="22" rx="9" ry="5" fill="#fff" opacity=".45" transform="rotate(-25 23 22)"/><g fill="#3b2200"><ellipse cx="23" cy="35" rx="3.2" ry="4.2"/><ellipse cx="41" cy="35" rx="3.2" ry="4.2"/></g><path d="M24 44c3 6 13 6 16 0z" fill="#7c2d12"/></svg>';
const esc=x=>String(x==null?'':x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const N=()=>{try{return window.Personal?String(Personal.name()||''):''}catch(e){return ''}};
const PCH={fajr:'أذّن الفجر، بارك الله في يومك 🌙',sunrise:'طلعت الشمس، أذكار الصباح بانتظارك ☀️',dhuhr:'حان وقت الظهر 🕌',asr:'حان وقت العصر 🕌',maghrib:'حان المغرب، وأذكار المساء بانتظارك 🌇',isha:'حان وقت العشاء 🌙'};
let bub,mas,msgT,hideT;
/* بطاقة نوري الزجاجية الذهبية بجانبه: تعرض كلمة الفترة الحالية وموعد الصلاة القادمة، وتتبدّل لحظياً برسائل نوري ثم تعود */
const AMB={fajr:'ركعتا الفجر خيرٌ من الدنيا',sunrise:'أذكار الصباح بانتظارك',dhuhr:'ظهرٌ مبارك، اذكر الله',asr:'حافظ على الصلاة الوسطى',maghrib:'حان وقت أذكار المساء',isha:'اختم يومك بوردٍ من القرآن'};
const PIC={fajr:'stars',sunrise:'sunrise',dhuhr:'sun',asr:'cloudsun',maghrib:'sunset',isha:'moon'};
function per(){try{if(window.Personal&&Personal.period)return Personal.period()}catch(e){}const h=new Date().getHours();return h>=4&&h<6?'fajr':h>=6&&h<11?'sunrise':h>=11&&h<15?'dhuhr':h>=15&&h<18?'asr':h>=18&&h<19?'maghrib':'isha'}
const PN=[['Fajr','الفجر'],['Dhuhr','الظهر'],['Asr','العصر'],['Maghrib','المغرب'],['Isha','العشاء']];
function T(){try{const A=typeof AppState!=='undefined'?AppState:null;return A&&A.prayerTimes&&A.prayerTimes.Fajr?A.prayerTimes:null}catch(e){return null}}
function nextP(){
 const t=T();if(!t)return null;const now=new Date();let best=null,min=1e12;
 PN.forEach(([k,n])=>{const x=String(t[k]||'').split(':');if(x.length<2)return;const d=new Date();d.setHours(+x[0],+x[1],0,0);let m=(d-now)/60000;if(m<0)m+=1440;if(m<min){min=m;best={k:k,name:n,time:t[k],mins:Math.round(m)}}});
 return best}
function nextLine(){
 const n=nextP();if(!n)return '';const H=Math.floor(n.mins/60),M=n.mins%60;
 return n.name+' '+n.time+' · بعد '+(H?H+' س ':'')+M+' د'}
let lastStrip='';
function strip(){
 const el=$('.cr-strip');if(!el)return;const t=T();
 if(!t){el.hidden=true;return}
 const nx=nextP(),html=PN.map(([k,n])=>'<div class="cr-pr'+(nx&&nx.k===k?' nx':'')+'"><span>'+n+'</span><b>'+t[k]+'</b></div>').join('');
 if(html!==lastStrip){el.innerHTML=html;lastStrip=html}el.hidden=false}
function paintCard(html,sub,say){
 if(!bub)return;const p=per();bub.dataset.period=p;bub.classList.toggle('say',!!say);
 const ic=bub.querySelector('.cr-ic'),t=bub.querySelector('.cr-t'),u=bub.querySelector('.cr-s');
 if(ic&&ic.dataset.i!==PIC[p]){ic.dataset.i=PIC[p];ic.innerHTML=window.Icons?Icons.html(PIC[p]):''}
 t.innerHTML=html;u.textContent=sub||'';u.hidden=!sub}
function floatFlash(html,sub,isSay){
 if(!bub)return;clearTimeout(msgT);clearTimeout(hideT);bub.classList.remove('show');
 msgT=setTimeout(()=>{paintCard(html,sub,isSay);bub.classList.add('show');hideT=setTimeout(()=>bub.classList.remove('show'),isSay?4200:5400)},140)}
/* انتقال ناعم داخل بطاقة التحية: يخفت المحتوى، يتبدّل، ثم يظهر */
let swapT;
function swap(g,fn){clearTimeout(swapT);g.classList.add('sw');swapT=setTimeout(()=>{fn();g.classList.remove('sw')},170)}
function back(){
 if(mas)mas.classList.remove('talk');
 const g=$('#pz-greet');if(!g||!g.classList.contains('nz'))return;
 swap(g,()=>{g.classList.remove('nz');try{window.Personal&&Personal.repaint()}catch(e){}})}
function flash(html,sub,isSay){
 const g=$('#pz-greet');
 if(!g)return floatFlash(html,sub,isSay);
 clearTimeout(hideT);
 const len=(String(html).replace(/<[^>]*>/g,'')+(sub||'')).length,ms=Math.min(7500,3400+len*55);
 swap(g,()=>{
  g.classList.add('nz');
  const e=g.querySelector('.pz-e'),t=g.querySelector('.pz-t');
  if(e){e.dataset.i='nz';e.innerHTML=MINI}
  if(t)t.innerHTML='<b class="nz-m">'+esc(html)+'</b>'+(sub?'<small class="nz-s">'+esc(sub)+'</small>':'');
 });
 if(mas)mas.classList.add('talk');
 hideT=setTimeout(back,ms)}
function ambient(){flash(AMB[per()],nextLine(),false)}
function say(t,sub){flash(t,sub,true)}
function hop(){if(!mas)return;mas.classList.remove('hop');void mas.offsetWidth;mas.classList.add('hop');try{navigator.vibrate&&navigator.vibrate(10)}catch(e){}}
function place(){
 const nav=$('.cr-nav'),pill=$('.cr-pill');if(!nav||!pill)return;
 const on=nav.querySelector('.cr-chip.on');
 if(!on){pill.style.opacity=0;return}
 pill.style.opacity=1;pill.style.width=on.offsetWidth+'px';pill.style.transform='translateX('+on.offsetLeft+'px)';
 const r=on.offsetLeft-(nav.clientWidth-on.offsetWidth)/2;nav.scrollTo({left:r,behavior:'smooth'})}
function mark(){
 const a=$('.view-section.active'),v=a?a.id.slice(5):'home';
 document.querySelectorAll('.cr-chip').forEach(c=>{const o=c.dataset.v===v;c.classList.toggle('on',o);c.setAttribute('aria-current',o?'page':'false')});
 place();return v}
function build(){
 const hd=$('.main-header'),t=$('.creative-brand-title');if(!hd||!t||$('.cr-who'))return;
 const brand=t.parentElement,top=brand.parentElement;
 const who=document.createElement('div');who.className='cr-who';
 who.innerHTML='<button class="cr-mascot" aria-label="نوري، صديقك المبتهج">'+svg+'</button>';
 top.insertBefore(who,brand);who.appendChild(brand);
 bub=document.createElement('div');bub.className='cr-card cr-float';bub.setAttribute('role','status');bub.setAttribute('aria-live','polite');
 bub.innerHTML='<i class="cr-ic"></i><div class="cr-tx"><b class="cr-t"></b><small class="cr-s" hidden></small></div>';
 hd.appendChild(bub);
 try{if(getComputedStyle(hd).position==='static')hd.style.position='relative'}catch(e){}
 const st=document.createElement('div');st.className='cr-strip';st.hidden=true;st.setAttribute('aria-label','مواقيت الصلاة');hd.appendChild(st);
 mas=who.firstChild;
 strip();[1500,4000,9000].forEach(ms=>setTimeout(strip,ms));setInterval(strip,20000);
 setTimeout(()=>{const n=N();say(n?'أهلاً بك يا '+n+' ✨':HELLO,'أنا نوري، رفيقك في إخلاص')},1000);
 setInterval(()=>{const a=$('.view-section.active');if(!document.hidden&&a&&a.id==='view-home')ambient()},180000);
 let taps=0;
 const poke=()=>{hop();taps++;const nl=nextLine();if(nl&&taps%3===1){say('🕌 الصلاة القادمة',nl);return}
  const n=N(),m=TAP[Math.floor(Math.random()*TAP.length)];say(n&&taps%2===0?'يا '+n+'، '+m:m)};
 mas.addEventListener('click',poke);
 window.Nouri={say:say,poke:poke,hop:hop};
 /* نوري يلاحظ دخول وقت صلاة جديد ويخبرك به */
 let lp=per();const t0=Date.now();
 setInterval(()=>{const p=per();if(p===lp)return;lp=p;if(Date.now()-t0<60000||document.hidden)return;hop();say(PCH[p]||'',nextLine())},20000);
 const sw=window.switchView;
 if(typeof sw==='function')window.switchView=function(v){const r=sw.apply(this,arguments);requestAnimationFrame(()=>{mark();if(VIEW[v]){hop();say(VIEW[v])}else if(v==='home')say(HELLO)});return r};
 mark();addEventListener('resize',place);setTimeout(place,350);if(document.fonts&&document.fonts.ready)document.fonts.ready.then(place);
 /* احتفال عند كل 33 تسبيحة */
 const c=$('#tasbeeh-main-count');
 if(c)new MutationObserver(()=>{const n=parseInt(c.textContent,10);if(n>0&&n%33===0){hop();say('ما شاء الله! '+n+' تسبيحة 🎉')}}).observe(c,{childList:true,characterData:true,subtree:true});
 /* تلميح الصلاة القادمة مع موعدها */
 const hint=()=>{const nl=nextLine(),v=$('.view-section.active');if(nl&&v&&v.id==='view-home')say('🕌 القادمة: '+nl.split(' · ')[0],nl.split(' · ')[1]||'')};
 setTimeout(hint,6500)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',build);else build();
})();
