/* إعدادات إخلاص المطوّرة: مظهر، موقع، ضبط المواقيت، عام، نسخ احتياطي. تحفظ الإعدادات التي كانت تُفقد عند إعادة التشغيل. */
(function(){'use strict';
const K='ikhlas_settings_v1',$=s=>document.querySelector(s),
esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])),
ready=f=>document.readyState==='loading'?addEventListener('DOMContentLoaded',f):f(),
isMine=k=>/^(ikhlas|smartkhatmah)/i.test(k),
S=(()=>{try{return JSON.parse(localStorage.getItem(K))||{}}catch(e){return{}}})();
S.font=S.font||100;S.haptics=S.haptics!==false;S.adj=S.adj||{};
const save=()=>{try{localStorage.setItem(K,JSON.stringify(S))}catch(e){}};
const PK=['Fajr','Sunrise','Dhuhr','Asr','Maghrib','Isha'],
PN={Fajr:'الفجر',Sunrise:'الشروق',Dhuhr:'الظهر',Asr:'العصر',Maghrib:'المغرب',Isha:'العشاء'};

/* اهتزاز عام قابل للإيقاف */
let ov=null;try{ov=navigator.vibrate&&navigator.vibrate.bind(navigator);if(ov)navigator.vibrate=p=>S.haptics?ov(p):false}catch(e){}

/* مذهب العصر + تعديل الدقائق: تغليف الحساب المحلي فيعمل مع الإشعارات أيضاً */
function addMin(t,m){if(!m||!/^\d\d:\d\d$/.test(t))return t;const p=t.split(':').map(Number),x=((p[0]*60+p[1]+m)%1440+1440)%1440;return String(x/60|0).padStart(2,'0')+':'+String(x%60).padStart(2,'0')}
if(window.PrayerCalc&&!PrayerCalc.__sp){const o=PrayerCalc.times;
 PrayerCalc.times=(d,la,ln,m,op)=>{const r=o(d,la,ln,m,Object.assign({hanafi:!!S.hanafi},op));PK.forEach(k=>{r[k]=addMin(r[k],+S.adj[k]||0)});return r};PrayerCalc.__sp=1}
const recalc=()=>{try{calculatePrayerTimes()}catch(e){}try{savePersistence()}catch(e){}};

/* المظهر والخط */
const mq=window.matchMedia?matchMedia('(prefers-color-scheme: dark)'):{matches:false};
function applyTheme(){const d=S.theme==='dark'||(S.theme==='auto'&&mq.matches);document.body.classList.toggle('dark-mode',d);try{AppState.isDarkMode=d}catch(e){}}
const applyFont=()=>{document.documentElement.style.fontSize=S.font+'%'};

/* إبقاء الشاشة مضاءة */
let wl=null;
async function wake(){try{if(S.wake&&navigator.wakeLock&&!document.hidden&&!wl){wl=await navigator.wakeLock.request('screen');wl.addEventListener('release',()=>{wl=null})}else if(!S.wake&&wl){await wl.release();wl=null}}catch(e){}}
document.addEventListener('visibilitychange',wake);

/* المواقع */
const CITIES=[['الخرطوم',15.5007,32.5599],['أم درمان',15.6445,32.4777],['بورتسودان',19.6158,37.2164],['مكة المكرمة',21.3891,39.8579],['المدينة المنورة',24.5247,39.5692],['جدة',21.4858,39.1925],['الرياض',24.7136,46.6753],['القاهرة',30.0444,31.2357],['الإسكندرية',31.2001,29.9187],['دبي',25.2048,55.2708],['الدوحة',25.2854,51.531],['الكويت',29.3759,47.9774],['عمّان',31.9454,35.9284],['القدس',31.7683,35.2137],['بغداد',33.3152,44.3661],['إسطنبول',41.0082,28.9784],['الدار البيضاء',33.5731,-7.5898],['الجزائر',36.7538,3.0588],['تونس',36.8065,10.1815],['طرابلس',32.8872,13.1913],['لندن',51.5074,-0.1278],['كوالالمبور',3.139,101.6869],['جاكرتا',-6.2088,106.8456]];
const cityOf=()=>{const L=AppState.userLocation;return CITIES.find(c=>Math.abs(c[1]-L.lat)<.06&&Math.abs(c[2]-L.lng)<.06)};

const say=(id,t)=>{const e=document.getElementById(id);if(e)e.textContent=t};
function refresh(){const v=$('#view-settings');if(!v||!v.dataset.sp)return;
 v.querySelectorAll('[data-sp=theme]').forEach(b=>b.classList.toggle('on',b.dataset.v===S.theme));
 v.querySelectorAll('[data-sp=font]').forEach(b=>b.classList.toggle('on',+b.dataset.v===S.font));
 v.querySelectorAll('[data-sp=tg]').forEach(b=>b.classList.toggle('active',!!S[b.dataset.k]));
 PK.forEach(k=>{const n=+S.adj[k]||0;say('sp-adj-'+k,(n>0?'+':'')+n)});
 const L=AppState.userLocation,c=cityOf();
 say('sp-loc-txt',(c?c[0]:'موقع مخصص')+' · '+L.lat.toFixed(3)+'، '+L.lng.toFixed(3));
 const sc=$('#sp-city');if(sc)sc.value=c?c[0]:'custom';
 const la=$('#sp-lat'),ln=$('#sp-lng');if(la&&document.activeElement!==la)la.value=L.lat.toFixed(4);if(ln&&document.activeElement!==ln)ln.value=L.lng.toFixed(4);
 const a=$('#sp-asr');if(a)a.value=S.hanafi?'1':'0'}

/* النسخ الاحتياطي */
function dump(){const o={_app:'ikhlas',_v:1,_at:new Date().toISOString(),data:{}};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(isMine(k))o.data[k]=localStorage.getItem(k)}return JSON.stringify(o)}
function importTxt(t){let o;try{o=JSON.parse(t)}catch(e){return say('sp-data-msg','⚠️ النص ليس نسخة صالحة')}
 if(!o||o._app!=='ikhlas'||!o.data||typeof o.data!=='object')return say('sp-data-msg','⚠️ هذه ليست نسخة احتياطية من إخلاص');
 if(!confirm('سيتم استبدال بياناتك الحالية بالنسخة المستوردة. متابعة؟'))return;
 Object.keys(o.data).filter(isMine).forEach(k=>{if(typeof o.data[k]==='string')try{localStorage.setItem(k,o.data[k])}catch(e){}});location.reload()}
function download(txt){const a=document.createElement('a'),u=URL.createObjectURL(new Blob([txt],{type:'application/json'}));
 a.href=u;a.download='ikhlas-backup-'+new Date().toLocaleDateString('en-CA')+'.json';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(u);a.remove()},600)}

function flash(b,t){const o=b.textContent;b.textContent=t;setTimeout(()=>{b.textContent=o},1600)}
function geo(b){if(!navigator.geolocation)return flash(b,'غير مدعوم');b.textContent='⏳ جارٍ التحديد...';
 navigator.geolocation.getCurrentPosition(p=>{AppState.userLocation.lat=p.coords.latitude;AppState.userLocation.lng=p.coords.longitude;recalc();refresh();b.textContent='📍 تحديد موقعي تلقائياً'},
 ()=>{b.textContent='📍 تحديد موقعي تلقائياً';say('sp-loc-msg','⚠️ تعذّر الوصول للموقع، تأكد من الإذن أو اختر مدينتك')},{timeout:12000})}

function build(){
 const v=$('#view-settings');if(!v||v.dataset.sp)return;v.dataset.sp=1;
 const cards=[...v.querySelectorAll(':scope>.card')],c1=cards[0]||null,dua=cards.length>1?cards[cards.length-2]:null,head=v.querySelector('.section-header');
 const mk=(id,html)=>{const d=document.createElement('div');d.className='card sp-card';d.id=id;d.innerHTML=html;return d};
 const seg=(a,items)=>'<div class="sp-seg">'+items.map(i=>`<button data-sp="${a}" data-v="${i[0]}">${i[1]}</button>`).join('')+'</div>';
 const tg=(k,l,d)=>`<div class="sp-row"><div><div>${l}</div>${d?`<small>${d}</small>`:''}</div><div class="toggle-switch" data-sp="tg" data-k="${k}"></div></div>`;
 const nav=mk('sp-nav','');nav.className='sp-nav';nav.innerHTML=[['sp-look','🎨 المظهر'],['sp-loc','📍 الموقع'],['sp-prayer','🕌 الأذان'],['sp-adj','⏱ المواقيت'],['sp-gen','⚙️ عام'],['sp-data','💾 البيانات']].map(x=>`<button class="xp-chip" data-sp="go" data-t="${x[0]}">${x[1]}</button>`).join('');
 const look=mk('sp-look',`<h3>🎨 المظهر</h3><div class="sp-lbl">السمة</div>${seg('theme',[['auto','تلقائي'],['light','فاتح'],['dark','داكن']])}<div class="sp-lbl">حجم الخط في التطبيق</div>${seg('font',[[90,'صغير'],[100,'عادي'],[112,'كبير'],[125,'كبير جداً']])}`);
 const loc=mk('sp-loc',`<h3>📍 الموقع</h3><div class="sp-cur" id="sp-loc-txt"></div><select id="sp-city" class="sp-in"><option value="custom" disabled>موقع مخصص</option>${CITIES.map(c=>`<option>${esc(c[0])}</option>`).join('')}</select><button class="btn-secondary ripple-effect sp-full" data-sp="geo">📍 تحديد موقعي تلقائياً</button><details class="sp-det"><summary>إدخال الإحداثيات يدوياً</summary><div class="sp-two"><input id="sp-lat" class="sp-in" inputmode="decimal" placeholder="خط العرض"><input id="sp-lng" class="sp-in" inputmode="decimal" placeholder="خط الطول"></div><button class="btn-secondary sp-full" data-sp="coords">تطبيق</button></details><small id="sp-loc-msg">تُحسب المواقيت بحسب ساعة جهازك، فعند اختيار مدينة في منطقة زمنية أخرى اضبط توقيت الجهاز لها.</small>`);
 const adj=mk('sp-adj',`<h3>⏱ ضبط المواقيت</h3><div class="sp-lbl">وقت صلاة العصر</div><select id="sp-asr" class="sp-in"><option value="0">الجمهور (شافعي / مالكي / حنبلي)</option><option value="1">الحنفي</option></select><div class="sp-lbl">تعديل بالدقائق (احتياطاً أو لمطابقة تقويم بلدك)</div>${PK.map(k=>`<div class="sp-row"><span>${PN[k]}</span><span class="sp-step"><button data-sp="adj" data-k="${k}" data-d="-1">−</button><b id="sp-adj-${k}">0</b><button data-sp="adj" data-k="${k}" data-d="1">+</button></span></div>`).join('')}<button class="btn-secondary sp-full" data-sp="adjreset">إعادة الضبط إلى الصفر</button>`);
 const gen=mk('sp-gen',`<h3>⚙️ عام</h3>${tg('haptics','الاهتزاز','عند التسبيح والأذكار والأزرار')}${tg('wake','إبقاء الشاشة مضاءة','أثناء استخدام التطبيق (يستهلك البطارية)')}<button class="btn-secondary sp-full" data-sp="resched">🔔 إعادة جدولة الأذان</button><small id="sp-gen-msg"></small><button class="btn-secondary sp-full" data-sp="tour">🧭 إعادة الجولة التعريفية</button>`);
 const data=mk('sp-data',`<h3>💾 النسخ الاحتياطي</h3><small>يشمل العدّادات والمفضلة والإعدادات والتقدم.</small><div class="sp-two"><button class="btn-secondary" data-sp="exp">📤 حفظ ملف</button><button class="btn-secondary" data-sp="share">📋 مشاركة / نسخ</button></div><button class="btn-secondary sp-full" data-sp="imp">📥 استيراد من ملف</button><input type="file" id="sp-file" accept=".json,application/json" hidden><details class="sp-det"><summary>أو الصق نسخة نصية</summary><textarea id="sp-paste" class="sp-in" rows="3" placeholder="الصق النسخة هنا"></textarea><button class="btn-secondary sp-full" data-sp="paste">استيراد النص</button></details><button class="btn-secondary sp-full sp-danger" data-sp="wipe">🗑 مسح كل بيانات التطبيق</button><small id="sp-data-msg"></small>`);
 if(head)head.after(nav);
 if(c1){c1.id='sp-prayer';v.insertBefore(look,c1);v.insertBefore(loc,c1);c1.after(adj)}else{v.appendChild(look);v.appendChild(loc);v.appendChild(adj)}
 v.insertBefore(gen,dua);v.insertBefore(data,dua);
 /* حفظ الإعدادات القديمة التي كانت تُنسى */
 const on=$('#setting-adhan-enabled'),me=$('#setting-calc-method');let changed=false;
 if(on&&S.adhan!==undefined)on.checked=!!S.adhan;
 if(me&&S.method&&[...me.options].some(o=>o.value===S.method)){changed=me.value!==S.method;me.value=S.method}
 if(on)on.addEventListener('change',()=>{S.adhan=on.checked;save()});
 if(me)me.addEventListener('change',()=>{S.method=me.value;save()});
 v.addEventListener('click',e=>{const b=e.target.closest('[data-sp]');if(!b)return;const a=b.dataset.sp,k=b.dataset.k;
  if(a==='go'){const t=document.getElementById(b.dataset.t);t&&t.scrollIntoView({behavior:'smooth',block:'start'});return}
  if(a==='theme'){S.theme=b.dataset.v;save();applyTheme()}
  else if(a==='font'){S.font=+b.dataset.v;save();applyFont()}
  else if(a==='tg'){S[k]=!S[k];save();if(k==='wake')wake();if(k==='haptics'&&S.haptics&&ov)try{ov(30)}catch(x){}}
  else if(a==='adj'){S.adj[k]=Math.max(-30,Math.min(30,(+S.adj[k]||0)+ +b.dataset.d));save();recalc()}
  else if(a==='adjreset'){S.adj={};save();recalc()}
  else if(a==='geo')geo(b);
  else if(a==='coords'){const la=parseFloat($('#sp-lat').value),ln=parseFloat($('#sp-lng').value);
   if(!(la>=-90&&la<=90&&ln>=-180&&ln<=180))return say('sp-loc-msg','⚠️ إحداثيات غير صحيحة');
   AppState.userLocation.lat=la;AppState.userLocation.lng=ln;recalc()}
  else if(a==='resched'){const nat=window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform();
   if(window.NativeAdhan&&nat){NativeAdhan.reschedule();say('sp-gen-msg','✓ أُعيدت جدولة أذان الأيام السبعة القادمة')}else say('sp-gen-msg','الأذان المجدول يعمل في تطبيق أندرويد فقط.')}
  else if(a==='tour'){try{localStorage.removeItem('IkhlasOnboarded')}catch(x){}location.reload()}
  else if(a==='exp')download(dump());
  else if(a==='share'){const t=dump();(async()=>{try{navigator.share?await navigator.share({title:'نسخة إخلاص',text:t}):await navigator.clipboard.writeText(t);say('sp-data-msg','✓ تمت العملية')}catch(x){say('sp-data-msg','تعذّر النسخ')}})()}
  else if(a==='imp')$('#sp-file').click();
  else if(a==='paste')importTxt($('#sp-paste').value.trim());
  else if(a==='wipe'){if(confirm('سيُحذف كل شيء: العدّادات والمفضلة والإعدادات. لا يمكن التراجع. متابعة؟')){
   Object.keys(localStorage).filter(isMine).forEach(x=>localStorage.removeItem(x));location.reload()}}
  refresh()});
 v.addEventListener('change',e=>{
  if(e.target.id==='sp-city'){const c=CITIES.find(x=>x[0]===e.target.value);if(c){AppState.userLocation.lat=c[1];AppState.userLocation.lng=c[2];recalc()}}
  else if(e.target.id==='sp-asr'){S.hanafi=e.target.value==='1';save();recalc()}
  else if(e.target.id==='sp-file'){const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>importTxt(String(r.result));r.readAsText(f);e.target.value=''}
  refresh()});
 if(changed||S.hanafi||PK.some(k=>+S.adj[k]))recalc();
 refresh()}

ready(()=>{
 if(!S.theme)S.theme=(typeof AppState!=='undefined'&&AppState.isDarkMode)?'dark':'auto';
 applyTheme();applyFont();wake();
 if(mq.addEventListener)mq.addEventListener('change',()=>{if(S.theme==='auto')applyTheme()});
 const t=$('#theme-toggle');if(t)t.addEventListener('click',()=>{S.theme=document.body.classList.contains('dark-mode')?'dark':'light';save();refresh()});
 let n=0;const tick=()=>{const v=$('#view-settings');if(v&&($('#adhan-sound-settings-card')||n>8))build();else if(n++<14)setTimeout(tick,500)};setTimeout(tick,900)});
})();
