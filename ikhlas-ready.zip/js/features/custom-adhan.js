/* أذان مخصص من ملفات الجهاز. أندرويد: نسخة داخل مخزن التطبيق تشغّلها خدمة الأذان الأصلية. المتصفح: تُحفظ في IndexedDB وتُشغَّل داخل الصفحة. */
(function(){'use strict';
const R=window.AdhanRegistry;if(!R)return;
const KEY='IkhlasCustomAdhans',MAX=20*1024*1024,DB='ikhlas-adhan',ST='sounds';
const isNative=()=>window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform();
const AN=()=>window.NativeAdhan&&NativeAdhan.plugin?NativeAdhan.plugin():null;
const clean=s=>String(s||'').replace(/\.[^.]+$/,'').replace(/[<>&"'`]/g,'').trim().slice(0,40)||'أذان مخصص';
const load=()=>{try{const a=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}};
const save=a=>{try{localStorage.setItem(KEY,JSON.stringify(a))}catch(e){}};
const urls={};let items=load();

/* IndexedDB لوضع المتصفح */
function idb(){return new Promise((ok,no)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore(ST);r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)})}
async function dbDo(mode,fn){const d=await idb();return new Promise((ok,no)=>{const t=d.transaction(ST,mode),q=fn(t.objectStore(ST));t.oncomplete=()=>ok(q&&q.result);t.onerror=()=>no(t.error)})}
const dbPut=(id,b)=>dbDo('readwrite',s=>s.put(b,id));
const dbGet=id=>dbDo('readonly',s=>s.get(id));
const dbDel=id=>dbDo('readwrite',s=>s.delete(id));

/* ربط السجلّ: urlFor للتشغيل داخل الصفحة، fileFor للخدمة الأصلية */
const baseUrl=R.urlFor.bind(R),baseFile=R.fileFor.bind(R);
function urlOf(c){
  if(c.mode==='native'){try{return Capacitor.convertFileSrc('file://'+c.path)}catch(e){return null}}
  return urls[c.id]||null}
R.urlFor=function(id){const s=R.get(id);return s&&s.custom?(urlOf(s.custom)||baseUrl('makkah')):baseUrl(id)};
R.fileFor=function(id){const s=R.get(id);return s&&s.custom?(s.custom.mode==='native'?'custom:'+s.custom.file:baseFile('makkah')):baseFile(id)};
R.isCustom=id=>{const s=R.list.find(x=>x.id===id);return !!(s&&s.custom)};

function register(c){if(R.list.some(s=>s.id===c.id))return;R.list.push({id:c.id,name:c.name,file:'adhan_makkah.mp3',remote:'',custom:c})}
items=items.filter(c=>c&&c.id&&c.name&&(c.mode==='native'?isNative():true));
items.forEach(register);
/* تجهيز روابط ملفات المتصفح ثم تحديث مصدر الصوت إن كان المختار منها */
items.filter(c=>c.mode==='web').forEach(c=>dbGet(c.id).then(b=>{if(!b)return;urls[c.id]=URL.createObjectURL(b);
  if(localStorage.getItem('IkhlasAdhanId')===c.id&&window.muezzinAudio)window.muezzinAudio.src=urls[c.id]}).catch(()=>{}));

const $=s=>document.querySelector(s);
function msg(t,bad){const m=$('#ca-msg');if(!m)return;m.textContent=t;m.style.color=bad?'var(--danger,#e11d48)':'var(--text-muted)'}
function refresh(){const s=$('#setting-adhan-sound'),d=$('#ca-del');if(d&&s)d.style.display=R.isCustom(s.value)?'':'none'}
function choose(id,name){const s=$('#setting-adhan-sound');if(!s)return;
  if(![...s.options].some(o=>o.value===id)){const o=document.createElement('option');o.value=id;o.textContent=name;s.appendChild(o)}
  s.value=id;s.dispatchEvent(new Event('change'));refresh()}

function pickWeb(){return new Promise((ok,no)=>{const i=document.createElement('input');i.type='file';i.accept='audio/*,.mp3,.ogg,.wav,.m4a,.aac';
  i.onchange=async()=>{const f=i.files&&i.files[0];if(!f)return no(new Error('cancelled'));
    if(f.size>MAX)return no(new Error('حجم الملف أكبر من 20 ميغابايت'));
    if(f.type&&f.type.indexOf('audio')!==0&&!/\.(mp3|ogg|wav|m4a|aac|opus)$/i.test(f.name))return no(new Error('اختر ملفاً صوتياً'));
    const id='c'+Date.now();try{await dbPut(id,f)}catch(e){return no(new Error('تعذّر الحفظ على هذا المتصفح'))}
    urls[id]=URL.createObjectURL(f);ok({id:id,name:clean(f.name),mode:'web'})};
  i.addEventListener('cancel',()=>no(new Error('cancelled')));i.click()})}

async function add(){
  const btn=$('#ca-add');if(btn)btn.disabled=true;
  try{
    let c,an=AN();
    if(isNative()&&an&&an.pickSound){const r=await an.pickSound();c={id:'c'+Date.now(),name:clean(r.name),mode:'native',file:r.file,path:r.path}}
    else c=await pickWeb();
    let n=prompt('اسم هذا الأذان:',c.name);if(n!==null)c.name=clean(n);
    items.push(c);save(items);register(c);choose(c.id,c.name);
    msg('تمت إضافة «'+c.name+'» واختياره أذاناً.')}
  catch(e){const m=String(e&&e.message||e);if(m.indexOf('cancel')<0)msg(m||'تعذّرت الإضافة',true)}
  finally{if(btn)btn.disabled=false}}

async function del(){
  const s=$('#setting-adhan-sound'),c=items.find(x=>s&&x.id===s.value);if(!c)return;
  if(!confirm('حذف «'+c.name+'» من جهازك؟'))return;
  try{if(c.mode==='native'){const an=AN();an&&an.deleteSound&&await an.deleteSound({file:c.file})}else{await dbDel(c.id);if(urls[c.id]){URL.revokeObjectURL(urls[c.id]);delete urls[c.id]}}}catch(e){}
  items=items.filter(x=>x.id!==c.id);save(items);
  const i=R.list.findIndex(x=>x.id===c.id);if(i>=0)R.list.splice(i,1);
  const o=[...s.options].find(o=>o.value===c.id);if(o)o.remove();
  s.value='makkah';s.dispatchEvent(new Event('change'));refresh();msg('تم حذف «'+c.name+'». عاد الأذان إلى الحرم المكي.')}

function mount(){
  const t=$('#test-adhan-btn'),s=$('#setting-adhan-sound');if(!t||!s||$('#ca-box'))return false;
  const box=document.createElement('div');box.id='ca-box';box.style.cssText='margin-top:12px';
  box.innerHTML='<div style="display:flex;gap:8px"><button type="button" class="btn-secondary ripple-effect" id="ca-add" style="flex:1;border-color:var(--accent);color:var(--accent)">+ إضافة أذان من الملفات</button>'+
    '<button type="button" class="btn-secondary ripple-effect" id="ca-del" style="display:none;border-color:var(--danger,#e11d48);color:var(--danger,#e11d48)">حذف</button></div>'+
    '<div id="ca-msg" style="font-size:.8rem;color:var(--text-muted);margin-top:8px"></div>';
  t.insertAdjacentElement('beforebegin',box);
  $('#ca-add').onclick=add;$('#ca-del').onclick=del;s.addEventListener('change',refresh);refresh();
  msg(isNative()?'يُحفظ الملف داخل التطبيق ويُشغَّل وقت الأذان حتى والتطبيق مغلق (حتى 20 ميغابايت).':'يُحفظ الملف في المتصفح (حتى 20 ميغابايت).');
  return true}
document.addEventListener('DOMContentLoaded',()=>{let n=0;const t=setInterval(()=>{if(mount()||n++>30)clearInterval(t)},600)});
})();
