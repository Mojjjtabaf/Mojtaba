/* إخلاص+ : سبحة مطوّرة + مكتبة أحاديث + مكتبة أذكار. تُحمَّل آخراً وتعتمد على بيانات التطبيق الحالية. */
(function(){'use strict';
const $=s=>document.querySelector(s),
esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])),
LS=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}},
SV=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}},
buzz=p=>{try{navigator.vibrate&&navigator.vibrate(p)}catch(e){}},
persist=()=>{try{savePersistence()}catch(e){}},
today=()=>new Date().toLocaleDateString('en-CA'),
plain=s=>String(s).replace(/[\u064B-\u0652\u0670]/g,''),
ready=f=>document.readyState==='loading'?addEventListener('DOMContentLoaded',f):f();
async function copy(t,b){try{navigator.share?await navigator.share({text:t}):await navigator.clipboard.writeText(t)}catch(e){}
 if(b){const o=b.textContent;b.textContent='✓ تم';setTimeout(()=>b.textContent=o,1200)}}

/* ───────── السبحة ───────── */
const DH=[{id:'sub',t:'سبحان الله',n:33},{id:'hamd',t:'الحمد لله',n:33},{id:'akbar',t:'الله أكبر',n:34},
{id:'tahlil',t:'لا إله إلا الله',n:100},{id:'istighfar',t:'أستغفر الله',n:100},{id:'salat',t:'اللهم صلِّ على محمد',n:100},
{id:'hawqala',t:'لا حول ولا قوة إلا بالله',n:100},{id:'subhamd',t:'سبحان الله وبحمده',n:100}],
TG=[10,33,34,99,100,500,1000];
function misbaha(){
 const btn=$('#tasbeeh-btn'),disp=$('#tasbeeh-main-count'),txt=$('#current-dhikr-text'),lbl=$('#widget-label'),wrap=btn&&btn.closest('.tasbeeh-wrapper');
 if(!btn||!disp||!txt||!wrap||btn.dataset.xp)return;btn.dataset.xp=1;
 const S=LS('ikhlas_misbaha_v1',{});S.sel=S.sel||'sub';S.c=S.c||{};S.l=S.l||{};S.tg=S.tg||{};S.tot=S.tot||0;S.vib=S.vib!==0&&S.vib!==false;
 if(S.d!==today()){S.c={};S.l={};S.d=today()}
 const cur=()=>DH.find(d=>d.id===S.sel)||DH[0],tgt=()=>S.tg[S.sel]||cur().n,
 chips=document.createElement('div'),info=document.createElement('div'),ctl=document.createElement('div');
 chips.className='xp-chips';chips.innerHTML=DH.map(d=>`<button class="xp-chip" data-id="${d.id}">${esc(d.t)}</button>`).join('');
 info.className='xp-info';ctl.className='xp-ctl';
 ctl.innerHTML='<button class="xp-btn" data-a="undo">↩︎ تراجع</button><button class="xp-btn" data-a="tg">🎯 الهدف</button><button class="xp-btn" data-a="vib"></button>';
 const old=$('#tasbeeh-mode');if(old)old.style.display='none';
 wrap.insertBefore(chips,wrap.firstChild);txt.after(info);info.after(ctl);
 const save=()=>{SV('ikhlas_misbaha_v1',S);persist()},
 draw=()=>{const c=S.c[S.sel]||0,t=tgt();disp.textContent=c;txt.textContent=cur().t;
  btn.style.setProperty('--p',Math.min(100,c/t*100));if(lbl)lbl.textContent=c>=t?'✅ اكتمل الهدف':'اضغط للتسبيح';
  info.innerHTML=`الهدف <b>${t}</b> · الدورات <b>${S.l[S.sel]||0}</b> · اليوم <b>${AppState.tasbeehCount}</b> · الإجمالي <b>${S.tot}</b>`;
  chips.querySelectorAll('.xp-chip').forEach(e=>e.classList.toggle('on',e.dataset.id===S.sel));
  ctl.querySelector('[data-a=vib]').textContent=S.vib?'📳 اهتزاز':'🔕 صامت'};
 btn.onclick=()=>{
  if(window.AssistantTasbeehTarget){S.tg[S.sel]=+window.AssistantTasbeehTarget||tgt();window.AssistantTasbeehTarget=0;S.c[S.sel]=0}
  const t=tgt();if((S.c[S.sel]||0)>=t)S.c[S.sel]=0;
  S.c[S.sel]=(S.c[S.sel]||0)+1;S.tot++;AppState.tasbeehCount++;
  if(S.c[S.sel]>=t){S.l[S.sel]=(S.l[S.sel]||0)+1;S.vib&&buzz([90,60,160])}else S.vib&&buzz(25);
  save();draw()};
 $('#tasbeeh-reset').onclick=()=>{S.c[S.sel]=0;S.l[S.sel]=0;buzz(120);save();draw()};
 chips.onclick=e=>{const id=e.target.dataset.id;if(id){S.sel=id;buzz(15);save();draw()}};
 ctl.onclick=e=>{const a=e.target.dataset.a;if(!a)return;
  if(a==='undo'){const c=S.c[S.sel]||0;if(c>0){if(c>=tgt()&&S.l[S.sel])S.l[S.sel]--;S.c[S.sel]=c-1;S.tot=Math.max(0,S.tot-1);AppState.tasbeehCount=Math.max(0,AppState.tasbeehCount-1)}}
  else if(a==='tg')S.tg[S.sel]=TG[(TG.indexOf(tgt())+1)%TG.length];
  else if(a==='vib')S.vib=!S.vib;
  save();draw()};
 draw()}

/* ───────── مكتبة الأحاديث (+ إصلاح تبويبي السنن والقصص) ───────── */
let HP,hq='',hc='all';const HF=LS('ikhlas_hfav',[]),
key=h=>plain(h.x).replace(/\s/g,'').slice(0,40),
pool=()=>{if(HP)return HP;const seen=new Set(),o=[],add=h=>{const k=key(h);if(!seen.has(k)){seen.add(k);o.push(h)}};
 try{MEGA_HADITH_DATA.forEach(ch=>ch.hadiths.forEach(h=>add({c:String(ch.chapter).replace(/^الفصل\s+[^:]+:\s*/,''),t:h.topic,x:h.text,s:h.source})))}catch(e){}
 (window.HADITH_LIB||[]).forEach(add);return HP=o};
function hList(){const l=$('#xh-list');if(!l)return;const q=plain(hq).trim(),P=pool();
 const a=P.filter(h=>(hc==='all'||(hc==='fav'?HF.includes(key(h)):h.c===hc))&&(!q||plain(h.t+' '+h.x+' '+h.c).includes(q)));
 l.innerHTML=a.length?a.map(h=>`<div class="card xp-card"><h3>${esc(h.t)}</h3><p>${esc(h.x)}</p><small>${esc(h.s||'')}${h.n?' · الأربعون النووية ('+h.n+')':''}</small><div class="xp-row"><button class="xp-btn xp-fav ${HF.includes(key(h))?'on':''}" data-i="${P.indexOf(h)}">★ مفضلة</button><button class="xp-btn" data-cp="${P.indexOf(h)}">📋 نسخ</button></div></div>`).join(''):'<div class="xp-info">لا نتائج</div>'}
window.renderKnowledge=function(src){const box=$('#knowledge-content');if(!box)return;
 if(src==='sunnah'||src==='stories'){let a=[];try{a=src==='sunnah'?SUNNAH_DATA:STORIES_DATA}catch(e){}
  box.onclick=null;box.innerHTML=a.map(i=>`<div class="card xp-card"><h3>${esc(i.title)}</h3><p>${esc(i.desc)}</p><small>${esc(i.source||'')}</small></div>`).join('');return}
 const cats=[...new Set(pool().map(h=>h.c))];
 box.innerHTML=`<input class="xp-search" id="xh-q" placeholder="🔍 ابحث في الأحاديث..." value="${esc(hq)}"><div class="xp-chips" id="xh-cats"><button class="xp-chip ${hc==='all'?'on':''}" data-cat="all">الكل (${pool().length})</button><button class="xp-chip ${hc==='fav'?'on':''}" data-cat="fav">⭐ المفضلة</button>${cats.map((c,i)=>`<button class="xp-chip ${hc===c?'on':''}" data-cat="${esc(c)}">${esc(c)}</button>`).join('')}</div><div id="xh-list"></div>`;
 $('#xh-q').oninput=e=>{hq=e.target.value;hList()};
 box.onclick=e=>{const b=e.target.closest('button');if(!b)return;
  if(b.dataset.cat){hc=b.dataset.cat;box.querySelectorAll('#xh-cats .xp-chip').forEach(x=>x.classList.toggle('on',x===b));hList()}
  else if(b.dataset.i!=null){const k=key(pool()[+b.dataset.i]),j=HF.indexOf(k);j<0?HF.push(k):HF.splice(j,1);SV('ikhlas_hfav',HF);b.classList.toggle('on',j<0);if(hc==='fav')hList()}
  else if(b.dataset.cp!=null){const h=pool()[+b.dataset.cp];copy(h.x+'\n— '+(h.s||''),b)}};
 hList()};

/* ───────── مكتبة الأذكار ───────── */
const CATS={morning:'الصباح',evening:'المساء',after_prayer:'بعد الصلاة',sleep:'النوم',protection:'التحصين',ruqyah:'الرقية الشرعية',quranic:'أذكار القرآن',prophetic:'الأذكار النبوية',wakeup:'الاستيقاظ',travel:'السفر',food:'الطعام',occasions:'المناسبات',home:'المنزل والمسجد',distress:'الهم والكرب',tasbih:'التسبيح والصلاة على النبي',istighfar:'الاستغفار والتوبة',rizq:'الرزق والحاجة',family:'الأسرة والذرية',illness:'المرض والشفاء',nature:'المطر والرياح والهلال'};
let ac='morning',aq='';const AI={};
function adata(){try{const E=window.ADHKAR_LIB_EXTRA||{};Object.keys(E).forEach(k=>{ADHKAR_DATA[k]=ADHKAR_DATA[k]||[];E[k].forEach(i=>{if(!ADHKAR_DATA[k].some(x=>x.id===i.id))ADHKAR_DATA[k].push(i)})});return ADHKAR_DATA}catch(e){return {}}}
const cardA=i=>{const n=AppState.adhkarProgress[i.id]||0,t=i.target||1;
 return `<div class="card xp-card ${n>=t?'done':''}" data-id="${esc(i.id)}"><p>${esc(i.text)}</p>${i.info?`<small>${esc(i.info)}</small>`:''}<div class="xp-row"><button class="xp-btn" data-cp="1">📋 نسخ</button><button class="xp-btn xp-cnt" data-t="${t}">${n>=t?'✓ تم':n+' / '+t}</button></div></div>`};
function sumA(){const P=AppState.adhkarProgress,a=Object.values(AI),d=a.filter(i=>(P[i.id]||0)>=(i.target||1)).length;
 $('#al-sum').textContent=aq.trim()?`${a.length} نتيجة`:`${d} / ${a.length} مكتمل`;$('#al-bar').style.width=(a.length?d/a.length*100:0)+'%'}
let ai=0,cur=[],dirA=0;
const slideA=i=>{const p=AppState.adhkarProgress[i.id]||0,t=i.target||1,d=p>=t;
 return `<div class="az-card ${d?'done':''} ${dirA>0?'az-in-next':dirA<0?'az-in-prev':''}" data-id="${esc(i.id)}"><div class="az-head"><span>${esc(i.info||CATS[ac]||'')}</span><span class="badge">المطلوب: ${t}</span></div><div class="az-text"><p class="islamic-text">${esc(i.text)}</p></div><div class="az-bar"><i style="width:${Math.min(100,p/t*100)}%"></i></div><button class="az-tap" data-t="${t}" ${d?'disabled':''}>${d?'✓ أتممتَ هذا الذكر':'التكرار: '+p+' / '+t}</button><div class="az-tools"><button class="xp-btn" data-azcp="1">📋 نسخ</button></div></div>`};
function slideDraw(){const L=$('#al-list');if(!L)return;
 if(!cur.length){L.innerHTML='<div class="xp-info">لا نتائج</div>';return}
 ai=Math.max(0,Math.min(ai,cur.length-1));
 const dots=cur.length<=12?`<div class="az-dots">${cur.map((x,k)=>`<button data-dot="${k}" aria-label="${k+1}" class="${k===ai?'on':''} ${(AppState.adhkarProgress[x.id]||0)>=(x.target||1)?'ok':''}"></button>`).join('')}</div>`:'';
 L.innerHTML=`<div class="az-deck">${slideA(cur[ai])}</div><div class="az-nav"><button class="xp-btn" data-az="prev" ${ai===0?'disabled':''}>→ السابق</button><span class="az-pos">${ai+1} / ${cur.length}</span><button class="xp-btn" data-az="next" ${ai===cur.length-1?'disabled':''}>التالي ←</button></div>${dots}`;dirA=0}
function goA(n){if(n<0||n>=cur.length||n===ai)return;dirA=n>ai?1:-1;ai=n;buzz(15);slideDraw()}
function tapA(b){const card=b.closest('.az-card');if(!card)return;const id=card.dataset.id,t=+b.dataset.t,P=AppState.adhkarProgress;if((P[id]||0)>=t)return;
 const p=P[id]=(P[id]||0)+1;buzz(p>=t?[60,40,100]:20);persist();
 card.querySelector('.az-bar i').style.width=Math.min(100,p/t*100)+'%';
 if(p>=t){card.classList.add('done');b.disabled=true;b.textContent='✓ أتممتَ هذا الذكر';sumA();
  const dt=document.querySelector('.az-dots button.on');if(dt)dt.classList.add('ok');
  if(ai<cur.length-1)setTimeout(()=>{if(cur[ai]&&cur[ai].id===id)goA(ai+1)},650)}
 else{b.textContent='التكرار: '+p+' / '+t;sumA()}}
function listA(){const D=adata(),q=plain(aq).trim();
 const items=q?Object.keys(D).flatMap(k=>D[k]).filter(i=>plain(i.text+' '+(i.info||'')).includes(q)):(D[ac]||[]);
 Object.keys(AI).forEach(k=>delete AI[k]);items.forEach(i=>AI[i.id]=i);
 if(q){$('#al-list').innerHTML=items.map(cardA).join('')||'<div class="xp-info">لا نتائج</div>'}
 else{cur=items;slideDraw()}
 sumA()}
function drawA(){const r=$('#al-root'),ks=Object.keys(adata());
 r.innerHTML=`<div class="section-header"><h2 class="section-title">🤲 مكتبة الأذكار</h2></div><input class="xp-search" id="al-q" placeholder="🔍 ابحث في كل الأذكار..." value="${esc(aq)}"><div class="xp-chips" id="al-cats">${ks.map(k=>`<button class="xp-chip ${k===ac?'on':''}" data-c="${esc(k)}">${esc(CATS[k]||k)}</button>`).join('')}</div><div class="xp-info" id="al-sum"></div><div class="xp-bar"><i id="al-bar"></i></div><div id="al-list"></div><div class="xp-row"><button class="xp-btn" data-reset="1">↺ تصفير القسم</button></div>`;
 $('#al-q').oninput=e=>{aq=e.target.value;ai=0;listA()};listA();
 const L=$('#al-list');let x0=null,y0=0;
 L.addEventListener('touchstart',e=>{x0=e.touches[0].clientX;y0=e.touches[0].clientY},{passive:true});
 L.addEventListener('touchend',e=>{if(x0==null||plain(aq).trim())return;const dx=e.changedTouches[0].clientX-x0,dy=e.changedTouches[0].clientY-y0;x0=null;
  if(Math.abs(dx)>50&&Math.abs(dx)>Math.abs(dy)*1.4)goA(ai+(dx<0?1:-1))},{passive:true})}
function aClick(e){const b=e.target.closest('button');if(!b)return;
 if(b.dataset.az){goA(b.dataset.az==='next'?ai+1:ai-1);return}
 if(b.dataset.dot!=null){goA(+b.dataset.dot);return}
 if(b.classList.contains('az-tap')){tapA(b);return}
 if(b.dataset.azcp){const c=b.closest('.az-card'),h=c.querySelector('.az-head span');copy(c.querySelector('p').textContent+(h?'\n— '+h.textContent:''),b);return}
 const card=b.closest('.xp-card');
 if(b.dataset.c){ac=b.dataset.c;aq='';ai=0;const q=$('#al-q');if(q)q.value='';$('#al-cats').querySelectorAll('.xp-chip').forEach(x=>x.classList.toggle('on',x===b));listA()}
 else if(b.dataset.reset){(adata()[ac]||[]).forEach(i=>{AppState.adhkarProgress[i.id]=0});buzz(120);persist();ai=0;listA()}
 else if(card&&b.classList.contains('xp-cnt')){const id=card.dataset.id,t=+b.dataset.t,P=AppState.adhkarProgress;if((P[id]||0)>=t)return;
  P[id]=(P[id]||0)+1;buzz(P[id]>=t?[60,40,100]:20);persist();card.outerHTML=cardA(AI[id]);sumA()}
 else if(card&&b.dataset.cp){const s=card.querySelector('small');copy(card.querySelector('p').textContent+(s?'\n— '+s.textContent:''),b)}}
function adhkar(){const v=$('#view-adhkar');if(!v)return;
 v.querySelectorAll('.sa-container,.sa-success-overlay').forEach(e=>e.remove());
 let r=$('#al-root');
 if(!r){Array.from(v.children).forEach(c=>c.style.display='none');r=document.createElement('div');r.id='al-root';r.onclick=aClick;v.appendChild(r);r.style.display='';drawA();return}
 if(r.style.display==='none'){r.style.display='';drawA()}}
/* المحرك القديم يخفي القسم بعد ثانيتين ويحقن واجهة معطوبة؛ نعيد مكتبتنا فور ذلك */
window.renderAdhkarStack=()=>{if($('#al-list'))listA()};

ready(()=>{misbaha();adhkar();window.renderKnowledge('hadith');
 const v=$('#view-adhkar');if(v)new MutationObserver(()=>{if(v.querySelector('.sa-container')||($('#al-root')&&$('#al-root').style.display==='none'))adhkar()}).observe(v,{childList:true,attributes:true,subtree:true,attributeFilter:['style']})});
})();
