/* الخرزة: تنزلق إلى التبويب النشط (نقر أو سحب) */
(function(){'use strict';
const nav=document.querySelector('.bottom-nav');if(!nav)return;
const bead=document.createElement('span');bead.className='dock-bead';bead.setAttribute('aria-hidden','true');nav.prepend(bead);
const items=()=>[].slice.call(nav.querySelectorAll('.nav-item'));
const cx=el=>el.offsetLeft+el.offsetWidth/2;
let drag=false,moved=false,swallow=false,x0=0;
function place(x,it){bead.style.transform='translate3d('+(x-bead.offsetWidth/2)+'px,0,0)';
 if(it){const c=getComputedStyle(it).getPropertyValue('--acc').trim();if(c)bead.style.setProperty('--acc',c)}}
function sync(){if(drag)return;
 const it=nav.querySelector('.nav-item.active')||nav.querySelector('.nav-item.nav-parent')||items()[0];
 if(it)place(cx(it),it)}
const near=x=>items().reduce((b,i)=>Math.abs(cx(i)-x)<Math.abs(cx(b)-x)?i:b,items()[0]);
const xin=e=>{const r=nav.getBoundingClientRect();return Math.max(0,Math.min(r.width,e.clientX-r.left))};
nav.addEventListener('pointerdown',e=>{drag=true;moved=false;x0=e.clientX});
nav.addEventListener('pointermove',e=>{if(!drag)return;if(Math.abs(e.clientX-x0)>8)moved=true;
 if(moved){bead.style.transition='none';const x=xin(e);place(x,near(x))}});
function end(e,ok){if(!drag)return;drag=false;bead.style.transition='';
 if(ok&&moved){const it=near(xin(e));swallow=true;setTimeout(()=>swallow=false,120);
  if(it&&it.dataset.id){try{navigator.vibrate&&navigator.vibrate(8)}catch(x){}window.switchView(it.dataset.id)}}
 sync()}
nav.addEventListener('pointerup',e=>end(e,true));
nav.addEventListener('pointercancel',e=>end(e,false));
nav.addEventListener('click',e=>{if(swallow){e.stopPropagation();e.preventDefault()}},true);
new MutationObserver(sync).observe(nav,{attributes:true,attributeFilter:['class'],subtree:true});
addEventListener('resize',sync);
requestAnimationFrame(sync);setTimeout(sync,300);
})();
