/* يتتبّع المساحة المرئية فعلاً (مع لوحة المفاتيح) ليبقى حقل الإدخال وزر الإرسال ظاهرَين في المساعد ووضع المطوّر */
(function(){'use strict';
const vv=window.visualViewport,root=document.documentElement.style;
function f(){
  const h=vv?vv.height:innerHeight,t=vv?vv.offsetTop:0;
  root.setProperty('--vvh',Math.round(h)+'px');root.setProperty('--vvt',Math.round(t)+'px');
  root.setProperty('--kb',Math.max(0,Math.round(innerHeight-h-t))+'px');
}
f();
if(vv){vv.addEventListener('resize',f);vv.addEventListener('scroll',f);}
addEventListener('resize',f);addEventListener('orientationchange',()=>setTimeout(f,250));
document.addEventListener('focusin',e=>{
  const t=e.target;
  if(t&&t.matches&&t.matches('input,textarea,select')&&t.closest('.as-sheet,.dv-ov'))
    setTimeout(()=>{try{t.scrollIntoView({block:'center',behavior:'smooth'})}catch(_){}},320);
});
})();
