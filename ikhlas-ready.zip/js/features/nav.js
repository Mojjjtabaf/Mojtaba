/* التنقل: سجل صفحات، رجوع ذكي، حركة باتجاه الصفحة، حفظ موضع التمرير، إغلاق النوافذ بزر الرجوع، ووصول بلوحة المفاتيح */
(function(){'use strict';
/* غلافا part04/part05 يؤخّران التبديل 250ms، فإذا نقر المستخدم تبويبين بسرعة يفوز الأول لا الأخير.
   نمنعهما ونتولى الحركة هنا بلا تأخير. (يجب أن يُنفَّذ هذا قبل DOMContentLoaded) */
window.isSwitchViewUpgraded=true;
const base=window.switchView;
if(typeof base!=='function')return;

const $=s=>document.querySelector(s),$$=s=>[].slice.call(document.querySelectorAll(s));
const TABS=['home','quran','adhkar','knowledge','qibla'];
/* الصفحات الفرعية: أي تبويب يبقى مضيئاً بشكل خافت وهي مفتوحة */
const PARENT={tasbeeh:'adhkar',khatmah:'quran',journey:'home',settings:'home'};
const TITLE={home:'الرئيسية',quran:'القرآن',adhkar:'الأذكار',knowledge:'السنة',qibla:'القبلة',tasbeeh:'التسبيح',khatmah:'الختمة',settings:'الإعدادات',journey:'رحلة النور'};
const isTab=v=>TABS.indexOf(v)>=0;
const tabOf=v=>isTab(v)?v:(PARENT[v]||'home');
const exists=v=>!!document.getElementById('view-'+v);
const current=()=>{const a=$('.view-section.active');return a?a.id.slice(5):'home'};

let stack=[],pos={};
const scroller=()=>innerWidth>1024?$('.app-container'):null;
const getY=()=>{const s=scroller();return s?s.scrollTop:(window.scrollY||0)};
const setY=y=>{const s=scroller();if(s)s.scrollTop=y;else window.scrollTo({top:y,behavior:'auto'})};

function sync(v){
 const t=tabOf(v);
 $$('.nav-item').forEach(n=>{const on=n.dataset.id===v;
  n.classList.toggle('active',on);n.classList.toggle('nav-parent',!on&&n.dataset.id===t);
  n.setAttribute('aria-current',on?'page':'false')});
 const b=$('#global-back-btn');
 if(b){b.style.display=isTab(v)?'none':'inline-flex';
  const to=stack.length?stack[stack.length-1]:'home',s=b.querySelector('span');
  if(s)s.textContent='العودة إلى '+(TITLE[to]||'الرئيسية');
  b.setAttribute('aria-label',s?s.textContent:'رجوع')}
 try{history.replaceState(history.state,'','#'+v)}catch(e){}
}

function go(v,o){
 o=o||{};
 if(!exists(v))return false;
 const from=current();
 if(from===v){ /* النقر على الصفحة الحالية: ارجع لأعلاها بسلاسة */
  const s=scroller();if(s)s.scrollTo({top:0,behavior:'smooth'});else window.scrollTo({top:0,behavior:'smooth'});
  return true}
 pos[from]=getY();
 /* اتجاه الحركة (الواجهة RTL): الأمام/التبويب الأبعد يدخل من اليسار، والرجوع من اليمين */
 let fwd=true;
 if(o.back)fwd=false;
 else if(isTab(from)&&isTab(v))fwd=TABS.indexOf(v)>TABS.indexOf(from);
 if(!o.back){if(isTab(v))stack=[];else stack.push(from)}
 $$('.view-section').forEach(e=>e.classList.remove('nav-l','nav-r'));
 base(v);
 const el=document.getElementById('view-'+v);
 el.classList.add(fwd?'nav-l':'nav-r');
 setY(o.back?(pos[v]||0):0);
 sync(v);
 return true}

/* أعلى نافذة مفتوحة تُغلق أولاً؛ كل عنصر: [هل هي مفتوحة؟، الإغلاق] */
const shown=e=>e&&getComputedStyle(e).display!=='none';
const LAYERS=[
 ['#pz-name-ov',e=>shown(e),e=>{const b=e.querySelector('[data-pz=later]');b?b.click():e.remove()}],
 ['.ob-overlay',e=>shown(e),e=>{const b=e.querySelector('.ob-skip');b?b.click():e.remove()}],
 ['.as-sheet.open',e=>true,e=>{const b=e.querySelector('.as-head button');b?b.click():e.classList.remove('open')}],
 ['#tm-overlay.active',e=>true,()=>{typeof window.closeTimeMachine==='function'&&window.closeTimeMachine()}],
 ['#murshed-overlay.active',e=>true,()=>{typeof window.closeMurshed==='function'&&window.closeMurshed()}],
 ['#smart-khatmah-overlay',e=>e.style.display==='flex',()=>{if(confirm('إنهاء جلسة الختمة الذكية؟')&&window.stopSmartKhatmah)window.stopSmartKhatmah()}],
 ['#smart-khatmah-launcher.open',e=>true,()=>{window.closeSmartKhatmahSheet&&window.closeSmartKhatmahSheet()}],
 ['#tafsir-glass-modal.show',e=>true,e=>e.classList.remove('show')],
 ['#quran-reader',e=>e.style.display==='flex',()=>{typeof window.closeQuranReader==='function'&&window.closeQuranReader()}]
];
function closeLayer(){
 for(let i=0;i<LAYERS.length;i++){const e=$(LAYERS[i][0]);if(e&&LAYERS[i][1](e)){LAYERS[i][2](e);return true}}
 return false}

/* يعيد true إذا تصرّف؛ وfalse عند الرئيسية (فيُعرض دعاء الخروج) */
function back(){
 if(closeLayer())return true;
 const v=current();
 if(!isTab(v)){go(stack.length?stack.pop():'home',{back:true});return true}
 if(v!=='home'){go('home',{back:true});return true}
 return false}

window.switchView=function(v){return go(v)};
window.AppNav={go:go,back:back,current:current,canGoBack:()=>!!$('.view-section.active:not(#view-home)')};

function enhance(){
 const nav=$('.bottom-nav');
 if(nav){nav.setAttribute('role','navigation');nav.setAttribute('aria-label','التنقل الرئيسي');
  $$('.nav-item').forEach(n=>{n.setAttribute('role','button');n.tabIndex=0;
   n.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();n.click()}})})}
 const b=$('#global-back-btn');
 if(b){b.removeAttribute('onclick');b.addEventListener('click',()=>{back()})}
 /* رابط مباشر: index.html#quran */
 const h=(location.hash||'').slice(1);
 if(h&&h!=='home'&&exists(h))setTimeout(()=>go(h),400);
 else sync(current())}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',enhance);else enhance();
})();
