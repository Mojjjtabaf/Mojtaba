/* علامات مرجعية + آخر موضع قراءة: اضغط على رقم الآية لوضع علامة. يحفظ موضعك تلقائياً */
(function(){
const BK='IkhlasBookmarks',LR='IkhlasLastRead';
const load=k=>{try{return JSON.parse(localStorage.getItem(k))||(k===BK?[]:null);}catch(e){return k===BK?[]:null;}};
const save=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}};
const $=id=>document.getElementById(id);
const sname=()=>($('reader-surah-name').innerText||'').replace(/^سورة\s*/,'');
function card(){
  const v=$('view-quran');if(!v)return;let c=$('bk-card');
  if(!c){c=document.createElement('div');c.id='bk-card';c.className='card bk-card';v.insertBefore(c,v.children[1]||null);}
  const last=load(LR),bks=load(BK);
  c.style.display=(last||bks.length)?'':'none';
  c.innerHTML=(last?'<button class="bk-resume" data-s="'+last.s+'" data-a="'+last.a+'" data-n="'+last.n+'">📖 متابعة القراءة: سورة '+last.n+' — آية '+last.a+'</button>':'')+
   (bks.length?'<div class="bk-title">🔖 العلامات المرجعية</div><div class="bk-list">'+bks.map(function(b,i){return '<span class="bk-chip" data-s="'+b.s+'" data-a="'+b.a+'" data-n="'+b.n+'">'+b.n+' : '+b.a+'<b data-del="'+i+'" aria-label="حذف">×</b></span>';}).join('')+'</div>':'');
}
function open(s,a,n){
  openSurah(+s,n);
  let tries=0;const t=setInterval(function(){
    const el=document.getElementById('ayah-wrapper-'+(a-1));
    if(el||++tries>40){clearInterval(t);if(el){el.scrollIntoView({block:'center'});el.classList.add('bk-flash');setTimeout(function(){el.classList.remove('bk-flash');},1800);}}},150);
}
document.addEventListener('click',function(e){
  const d=e.target.closest('[data-del]');
  if(d){const b=load(BK);b.splice(+d.dataset.del,1);save(BK,b);card();e.stopPropagation();return;}
  const r=e.target.closest('.bk-resume,.bk-chip');
  if(r){open(r.dataset.s,+r.dataset.a,r.dataset.n);return;}
  const c=e.target.closest('.ayah-circle-num');
  if(c&&$('quran-reader').contains(c)){
    e.stopPropagation();const s=AppState.currentSurah,a=+c.textContent,b=load(BK),i=b.findIndex(x=>x.s==s&&x.a==a);
    if(i>=0){b.splice(i,1);c.classList.remove('bk-on');}else{b.push({s:s,a:a,n:sname()});c.classList.add('bk-on');}
    save(BK,b);card();if(navigator.vibrate)navigator.vibrate(20);}
},true);
function mark(){const b=load(BK);document.querySelectorAll('#reader-verses .ayah-circle-num').forEach(function(c){if(b.some(x=>x.s==AppState.currentSurah&&x.a==+c.textContent))c.classList.add('bk-on');});}
let tm;
function watch(){
  const rv=$('reader-verses');if(!rv)return;
  new MutationObserver(function(){clearTimeout(tm);tm=setTimeout(mark,120);}).observe(rv,{childList:true});
  rv.addEventListener('scroll',function(){clearTimeout(tm);tm=setTimeout(function(){
    const box=rv.getBoundingClientRect();
    const a=[].find.call(rv.querySelectorAll('.interactive-ayah'),function(x){return x.getBoundingClientRect().bottom>box.top+40;});
    if(a){save(LR,{s:AppState.currentSurah,a:+a.querySelector('.ayah-circle-num').textContent,n:sname()});card();}},600);},{passive:true});
}
function init(){card();watch();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
