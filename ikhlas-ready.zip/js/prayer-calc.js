/* حساب مواقيت الصلاة محلياً دون إنترنت (خوارزمية فلكية معيارية). الأرقام = أرقام طرق aladhan المستخدمة في القائمة */
(function(){
const R=Math.PI/180,sin=a=>Math.sin(a*R),cos=a=>Math.cos(a*R),tan=a=>Math.tan(a*R);
const asin=x=>Math.asin(x)/R,acos=x=>Math.acos(x)/R,atan2=(y,x)=>Math.atan2(y,x)/R;
const fix=(a,b)=>{a=a-b*Math.floor(a/b);return a<0?a+b:a;};
const METHODS={5:{fajr:19.5,isha:17.5},4:{fajr:18.5,ishaMin:90},3:{fajr:18,isha:17},2:{fajr:15,isha:15},1:{fajr:18,isha:18},9:{fajr:18,isha:17.5},8:{fajr:19.5,ishaMin:90}};
function jd(y,m,d){if(m<=2){y-=1;m+=12;}const A=Math.floor(y/100),B=2-A+Math.floor(A/4);return Math.floor(365.25*(y+4716))+Math.floor(30.6001*(m+1))+d+B-1524.5;}
function sun(j){const D=j-2451545,g=fix(357.529+0.98560028*D,360),q=fix(280.459+0.98564736*D,360),L=fix(q+1.915*sin(g)+0.02*sin(2*g),360),e=23.439-3.6e-7*D;
  return{decl:asin(sin(e)*sin(L)),eqt:q/15-fix(atan2(cos(e)*sin(L),cos(L))/15,24)};}
function fmt(h){if(!isFinite(h))return '--:--';h=fix(h+0.5/60,24);const H=Math.floor(h),M=Math.floor((h-H)*60);return String(H).padStart(2,'0')+':'+String(M).padStart(2,'0');}
function times(date,lat,lng,method,opts){
  opts=opts||{};const m=METHODS[method]||METHODS[5];const tz=opts.tz!=null?opts.tz:-date.getTimezoneOffset()/60;
  const J=jd(date.getFullYear(),date.getMonth()+1,date.getDate())-lng/(15*24);
  const noon=(t)=>12-sun(J+t).eqt;
  const T=(ang,t,ccw)=>{const s=sun(J+t),v=(-sin(ang)-sin(s.decl)*sin(lat))/(cos(s.decl)*cos(lat));return (ccw?-1:1)*acos(v)/15;};
  const dh=noon(0.5)+tz-lng/15;
  const s0=sun(J+0.5);
  const asrAng=-Math.atan(1/((opts.hanafi?2:1)+tan(Math.abs(lat-s0.decl))))/R;
  const asrT=acos((-sin(asrAng)-sin(s0.decl)*sin(lat))/(cos(s0.decl)*cos(lat)))/15;
  const sunrise=dh+T(0.833,0.25,true),sunset=dh+T(0.833,0.75,false);
  const fajr=dh+T(m.fajr,0.25,true);
  const isha=m.ishaMin?sunset+m.ishaMin/60:dh+T(m.isha,0.75,false);
  return{Fajr:fmt(fajr),Sunrise:fmt(sunrise),Dhuhr:fmt(dh+2/60),Asr:fmt(dh+asrT),Maghrib:fmt(sunset+1/60),Isha:fmt(isha)};
}
window.PrayerCalc={times:times,methods:METHODS};
})();
