// تمديد الأذكار وتصنيفاتها الـ 12 بدقة شرعية كاملة دون حذف القائم

    const AppState = {
        currentView: 'home', isDarkMode: false, userLocation: { lat: 15.5007, lng: 32.5599 },
        prayerTimes: {}, tasbeehCount: 0, adhkarProgress: {}, khatmahProgress: [], fontSize: 2,
        audioUrls: [], currentIndex: 0, isPlaying: false, currentSurah: 1, lastSavedDay: 0,
        isWidgetMode: false, isRecitationMode: false, // وضع التسميع الذكي
        prayerConfig: { Fajr: true, Sunrise: false, Dhuhr: true, Asr: true, Maghrib: true, Isha: true }
    };

    let activeStackIndex = 0;
    let currentAdhkarCategory = 'morning';
    window.quranAudio = new Audio();

    function initApp() {
        loadPersistence();
        checkAutoResetEngine(); 
        initPrayerEngine(); 
        initQuranSystem(); 
        initAdhkarSystem(); 
        initTasbeehSystem();
        initKnowledgeSystem(); 
        initKhatmahSystem(); 
        initQiblaSystem();
        initVoiceSearch();
        initAutoThemeAndAdhan();
        initRippleEffects();
        initSettingsPrayerConfig();
        
        document.getElementById('theme-toggle').addEventListener('click', toggleDarkMode);
        document.getElementById('refresh-dua-btn').addEventListener('click', () => {
            const duas = ["اللهم آتنا في الدنيا حسنة وفي الآخرة حسنة", "يا مقلب القلوب ثبت قلبي على دينك", "اللهم إنك عفو كريم تحب العفو فاعف عني", "ربنا تقبل منا إنك أنت السميع العليم"];
            document.getElementById('daily-dua-text').innerText = `"${duas[Math.floor(Math.random()*duas.length)]}"`;
        });
        
        updateWorshipStats();
        updateSmartWirdEngine();
        updateTreeUI();

    }

    function loadPersistence() { const saved = localStorage.getItem('IkhlasAppState2026_v2'); if (saved) { try { Object.assign(AppState, JSON.parse(saved)); } catch(e){} } }
    function savePersistence() { localStorage.setItem('IkhlasAppState2026_v2', JSON.stringify(AppState)); updateWorshipStats(); updateTreeUI(); }
    
    function checkAutoResetEngine() {
        const currentDay = new Date().getDate();
        if (AppState.lastSavedDay !== 0 && AppState.lastSavedDay !== currentDay) {
            AppState.tasbeehCount = 0;
            AppState.adhkarProgress = {};
            triggerHapticPro(200); 
        }
        AppState.lastSavedDay = currentDay;
        savePersistence();
    }

    function initRippleEffects() {
        document.body.addEventListener('click', function(e) {
            const target = e.target.closest('.ripple-effect');
            if (!target) return;
            const rect = target.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const ripple = document.createElement('span');
            ripple.className = 'ripple-element';
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;
            
            target.appendChild(ripple);
            ripple.addEventListener('animationend', () => ripple.remove());
        });
    }

    function switchView(viewId) {
        document.querySelectorAll('.view-section').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        
        document.getElementById(`view-${viewId}`).classList.add('active');
        const activeNav = document.querySelector(`.nav-item[data-id="${viewId}"]`);
        if (activeNav) activeNav.classList.add('active');
        
        const backBtn = document.getElementById('global-back-btn');
        if (['home', 'quran', 'adhkar', 'knowledge', 'qibla'].includes(viewId)) { backBtn.style.display = 'none'; } 
        else { backBtn.style.display = 'inline-flex'; }

        const scrollTarget = document.querySelector('.app-container');
        if(window.innerWidth > 1024) { scrollTarget.scrollTop = 0; } else { window.scrollTo({ top: 0, behavior: 'smooth' }); }
        triggerHapticPro(15);
        updateSmartWirdEngine();
    }

    function updateTreeUI() {
        let score = AppState.tasbeehCount;
        for (let k in AppState.adhkarProgress) score += AppState.adhkarProgress[k];
        score += (AppState.khatmahProgress.length * 10);

        const leaves = document.querySelectorAll('.tree-leaf');
        leaves.forEach((leaf, idx) => {
            if (score > (idx * 15)) {
                leaf.style.fill = '#2dd4bf';
                leaf.style.opacity = '0.9';
                leaf.style.transform = `scale3d(${1 + (score*0.001)}, ${1 + (score*0.001)}, 1)`;
            } else {
                leaf.style.fill = '#115e59';
                leaf.style.opacity = '0.3';
                leaf.style.transform = 'scale3d(1, 1, 1)';
            }
        });

        const statusText = document.getElementById('tree-status-text');
        if(statusText) {
            if (score === 0) statusText.innerText = "اغرس أولى أوراق شجرتك بالذكر الآن";
            else if (score < 50) statusText.innerText = "جميل! شجرتك النورانية بدأت بالنمو والتفتح";
            else statusText.innerText = "ما شاء الله! شجرتك النورانية وارفة ومضيئة بذكرك";
        }
    }

    function updateWorshipStats() {
        let dhikrTotal = 0; for (let k in AppState.adhkarProgress) dhikrTotal += AppState.adhkarProgress[k];
        document.getElementById('tasbeeh-summary').innerText = `${AppState.tasbeehCount + dhikrTotal} ذِكر وتسبيح اليوم`;
        document.getElementById('khatmah-summary').innerText = AppState.khatmahProgress.length > 0 ? `أتممت ${Math.round((AppState.khatmahProgress.length/30)*100)}% من الختمة` : "خطة ٣٠ يوماً ميسرة";
    }

    function updateSmartWirdEngine() {
        const hour = new Date().getHours();
        const card = document.getElementById('smart-ai-wird-card');
        const badge = document.getElementById('ai-wird-badge');
        const title = document.getElementById('ai-wird-title');
        const desc = document.getElementById('ai-wird-desc');

        if (hour >= 1 && hour < 4) {
            badge.innerText = "ورد السحر والتهجد"; title.innerText = "الاستغفار بالأسحار وصلاة الليل";
            desc.innerText = "هذا الوقت العظيم مستجاب فيه الدعاء، نقترح عليك فتح السبحة والاستغفار ١٠٠ مرة أو تلاوة سورة الملك.";
            card.onclick = () => { switchView('tasbeeh'); document.getElementById('current-dhikr-text').innerText = "أستغفر الله وأتوب إليه"; };
        } else if (hour >= 4 && hour < 11) {
            badge.innerText = "ورد البكور والصباح"; title.innerText = "أذكار الصباح وتحصين النفس";
            desc.innerText = "أتممت صلاة الفجر؟ حان وقت جلب الطمأنينة لليوم بالبدء ببطاقات أذكار الصباح الكريستالية.";
            card.onclick = () => { switchView('adhkar'); document.querySelector('[data-category="morning"]').click(); };
        } else if (hour >= 15 && hour < 19) {
            badge.innerText = "ورد العصر والغروب"; title.innerText = "أذكار المساء المأثورة";
            desc.innerText = "مع غروب شمس اليوم، حصن روحك وجسدك بأذكار المساء المباركة لتكفيك من كل شر.";
            card.onclick = () => { switchView('adhkar'); document.querySelector('[data-category="evening"]').click(); };
        } else {
            badge.innerText = "ورد الليل الساكن"; title.innerText = "الختمة الشهرية والرقية";
            desc.innerText = "قبل نومك، نقترح عليك مراجعة جزء الختمة لليوم الحالي وقراءة أذكار النوم الهادئة.";
            card.onclick = () => { switchView('khatmah'); };
        }
    }

    function toggleDarkMode() {
        AppState.isDarkMode = !AppState.isDarkMode; 
        document.body.classList.toggle('dark-mode', AppState.isDarkMode);
        triggerHapticPro(30);
        savePersistence();
    }

    function triggerHapticPro(ms) { if (navigator.vibrate) navigator.vibrate(ms); }

    function triggerExitModal(show) {
        const modal = document.getElementById('custom-exit-modal');
        if (show) { 
            // اختيار دعاء عشوائي من الـ 50 دعاءً الحقيقية للوالدين عند رغبة الخروج
            const randomDua = PARENT_DUAS[Math.floor(Math.random() * PARENT_DUAS.length)];
            document.getElementById('exit-random-dua-text').innerText = `"${randomDua}"`;
            
            modal.style.display = 'flex'; 
            setTimeout(() => modal.classList.add('show'), 10); 
        } 
        else { modal.classList.remove('show'); setTimeout(() => modal.style.display = 'none', 300); }
    }
    
    function closeAppConfirm(exit) { if(exit) { window.close(); window.location.href = "about:blank"; } else { triggerExitModal(false); triggerHapticPro(25); } }

    function initPrayerEngine() {
        setupDualDates();
        getGeoLocation(); 
        setInterval(updateCountdown, 1000);
        document.getElementById('refresh-location').addEventListener('click', getGeoLocation);
        document.getElementById('setting-calc-method').addEventListener('change', calculatePrayerTimes);
    }

    function setupDualDates() {
        try {
            const date = new Date();
            let gDate = new Intl.DateTimeFormat('ar-EG', { day: 'numeric', month: 'long', year: 'numeric', calendar: 'gregory' }).format(date) + ' م';
            /* بعض الأنظمة تُلحق «هـ» تلقائياً وبعضها لا؛ نستخرج الأجزاء ونضيفها مرة واحدة فقط */
            let hDate = (() => {
                const parts = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', { day: 'numeric', month: 'long', year: 'numeric' }).formatToParts(date);
                return parts.filter(x => x.type !== 'era').map(x => x.value).join('').replace(/\s*ه[ـ]?\.?\s*$/, '').trim() + ' هـ';
            })();
            const dateContainer = document.getElementById('hijri-date-display');
            if (dateContainer) {
                dateContainer.style.display = 'flex'; dateContainer.style.justifyContent = 'space-between'; dateContainer.style.width = '100%'; dateContainer.style.marginTop = '4px';
                const badgeStyle = `background: var(--glass-bg); color: var(--text-main); padding: 8px 14px; border-radius: 12px; font-weight: 700; font-size: 0.85rem; border: 1px solid var(--glass-border); box-shadow: var(--shadow-inset);`;
                dateContainer.innerHTML = `<div style="${badgeStyle}">📅 ${gDate}</div><div style="${badgeStyle}">${hDate} 🌙</div>`;
            }
        } catch (e) {}
    }

    function getGeoLocation() {
        const btn = document.getElementById('refresh-location'); btn.innerText = "جاري الحساب الفلكي...";
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (pos) => { AppState.userLocation.lat = pos.coords.latitude; AppState.userLocation.lng = pos.coords.longitude; calculatePrayerTimes(); btn.innerText = "📍 تحديث الموقع الجغرافي"; },
                () => { calculatePrayerTimes(); btn.innerText = "⚠️ فشل التحديد الجغرافي (توقيت افتراضي)"; }
            );
        } else { calculatePrayerTimes(); }
    }

    async function calculatePrayerTimes() {
        // حساب محلي بالكامل: يعمل دون إنترنت
        const method = document.getElementById('setting-calc-method').value;
        AppState.prayerTimes = PrayerCalc.times(new Date(), AppState.userLocation.lat, AppState.userLocation.lng, method);
        updatePrayerUI();
        if (window.NativeAdhan) NativeAdhan.reschedule();
        if (window.DynamicSky) DynamicSky.refresh();
    }

    function updatePrayerUI() {
        const times = AppState.prayerTimes;
        const mapping = { Fajr: 'prayer-fajr', Sunrise: 'prayer-sunrise', Dhuhr: 'prayer-dhuhr', Asr: 'prayer-asr', Maghrib: 'prayer-maghrib', Isha: 'prayer-isha' };
        for (const [key, id] of Object.entries(mapping)) {
            if (times[key]) document.getElementById(id).querySelector('p').innerText = times[key];
        }
    }

    function updateCountdown() {
        if (!AppState.prayerTimes.Fajr) return;
        const now = new Date(); let nextPrayer = null; let minDiff = Infinity;
        document.querySelectorAll('.time-box').forEach(b => b.classList.remove('active-prayer'));
        
        const list = [
            {id:'prayer-fajr',n:'الفجر',t:AppState.prayerTimes.Fajr, cls:'theme-fajr'},
            {id:'prayer-sunrise',n:'الشروق',t:AppState.prayerTimes.Sunrise, cls:'theme-sunrise'},
            {id:'prayer-dhuhr',n:'الظهر',t:AppState.prayerTimes.Dhuhr, cls:'theme-dhuhr'},
            {id:'prayer-asr',n:'العصر',t:AppState.prayerTimes.Asr, cls:'theme-asr'},
            {id:'prayer-maghrib',n:'المغرب',t:AppState.prayerTimes.Maghrib, cls:'theme-maghrib'},
            {id:'prayer-isha',n:'العشاء',t:AppState.prayerTimes.Isha, cls:'theme-isha'}
        ];
        
        list.forEach(p => {
            const [h, m] = p.t.split(':'); const pDate = new Date(); pDate.setHours(h, m, 0, 0);
            let diff = pDate - now; if (diff < 0) { pDate.setDate(pDate.getDate() + 1); diff = pDate - now; }
            if (diff < minDiff) { minDiff = diff; nextPrayer = p; }
        });
        
        if (nextPrayer) {
            document.getElementById('prayer-countdown').innerText = `${Math.floor(minDiff/3600000).toString().padStart(2,'0')}:${Math.floor((minDiff%3600000)/60000).toString().padStart(2,'0')}:${Math.floor((minDiff%60000)/1000).toString().padStart(2,'0')}`;
            document.getElementById('next-prayer-name').innerText = `صلاة ${nextPrayer.n}`; 
            document.getElementById(nextPrayer.id).classList.add('active-prayer');
            
            const currentHour = now.getHours();
            document.body.className = document.body.className.replace(/theme-\S+/g, '');
            if (currentHour >= 1 && currentHour < 4) {
                document.body.classList.add('theme-twilight');
                document.getElementById('dashboard-countdown-label').innerText = "✨ ثلث الليل والتهجد .. الصلاة القادمة بعد";
            } else {
                document.body.classList.add(nextPrayer.cls);
                document.getElementById('dashboard-countdown-label').innerText = "الصلاة القادمة بعد";
            }
        }
    }

    window.muezzinAudio = new Audio('https://download.quranicaudio.com/adhan/makkah.mp3');
    window.lastPlayedAdhan = null;
    
    function initAutoThemeAndAdhan() {
        setInterval(() => {
            if (!AppState.prayerTimes || Object.keys(AppState.prayerTimes).length === 0) return;
            const now = new Date();
            const currentHHMM = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0');
            const todayDate = now.toISOString().split('T')[0];

            if (!document.getElementById('setting-adhan-enabled').checked) return;

            ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].forEach(p => {
                if (AppState.prayerTimes[p] === currentHHMM) {
                    const key = todayDate + '-' + p;
                    if (window.lastPlayedAdhan !== key) {
                        // الفحص الجراحي لإشعارات التخصيص الفردي لكل صلاة على حدة من الذاكرة
                        if (AppState.prayerConfig && AppState.prayerConfig[p] === true) {
                            window.lastPlayedAdhan = key;
                            
                            const arabicNames = { Fajr: 'الفجر', Dhuhr: 'الظهر', Asr: 'العصر', Maghrib: 'المغرب', Isha: 'العشاء' };
                            if(window.AdhanScreen){/* المراقب الجديد في adhan-screen.js يتولّى الشاشة والصوت */}else{
alert(`حان الآن موعد صلاة ${arabicNames[p]}`);
                            
                            window.muezzinAudio.currentTime = 0;
                            window.muezzinAudio.play().catch(()=>{});
                            triggerHapticPro([300, 150, 300]);
}
                        }
                    }
                }
            });
        }, 5000);
    }

    // إصلاح تخصيص قنوات التنبيه وحل الخلل والشرط المطبعي تماماً
    function initSettingsPrayerConfig() {
        const switches = document.querySelectorAll('#prayer-custom-config-switches .toggle-switch');
        switches.forEach(sw => {
            const prayerKey = sw.dataset.cfgPrayer;
            sw.classList.toggle('active', AppState.prayerConfig[prayerKey]);
            
            sw.onclick = function() {
                // إصلاح جذري للبند الثامن في التخصيص المستقل
                AppState.prayerConfig[prayerKey] = !AppState.prayerConfig[prayerKey];
                this.classList.toggle('active', AppState.prayerConfig[prayerKey]);
                triggerHapticPro(25);
                savePersistence();
            };
        });
    }

    // محرك المصحف
    let SURAHS_DATA_STORE = [];
    async function initQuranSystem() {
        try {
            const res = await fetch('https://api.alquran.cloud/v1/surah');
            const data = await res.json(); SURAHS_DATA_STORE = data.data; renderSurahs(SURAHS_DATA_STORE);
        } catch (e) { document.getElementById('surah-list').innerHTML = '<p style="padding:20px; text-align:center;">تعذر جلب الفهرس الرقمي.</p>'; }
        
        const qTabs = document.querySelectorAll('#quran-tabs-container .tab-btn');
        qTabs.forEach(t => {
            t.addEventListener('click', () => {
                qTabs.forEach(tab => tab.classList.remove('active')); t.classList.add('active');
                if (t.dataset.qtarget === 'surahs') {
                    document.getElementById('surah-list').style.display = 'grid';
                    document.getElementById('quran-ayahs-search-container').style.display = 'none';
                } else {
                    document.getElementById('surah-list').style.display = 'none';
                    document.getElementById('quran-ayahs-search-container').style.display = 'block';
                }
            });
        });

        document.getElementById('ayah-search-btn').addEventListener('click', performAdvancedAyahSearch);
        document.getElementById('reader-font-inc').addEventListener('click', () => { if(AppState.fontSize < 4){ AppState.fontSize++; applyFontSize(); } });
        document.getElementById('reader-font-dec').addEventListener('click', () => { if(AppState.fontSize > 0){ AppState.fontSize--; applyFontSize(); } });
    }

    function renderSurahs(surahs) {
        document.getElementById('surah-list').innerHTML = surahs.map(s => `<div class="card surah-card ripple-effect" onclick="openSurah(${s.number}, '${s.name}')"><div class="surah-number">${s.number}</div><div class="surah-name">${s.name}</div><div class="surah-details" style="font-size:0.75rem; color:var(--text-muted);">${s.numberOfAyahs} آية</div></div>`).join('');
    }

    function initVoiceSearch() {
        const trigger = document.getElementById('voice-search-trigger');
        const input = document.getElementById('ayah-search-input');
        const indicator = document.getElementById('voice-status-indicator');
        
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) { trigger.style.display = 'none'; return; }
        
        const recognition = new SpeechRecognition();
        recognition.lang = 'ar-SA'; recognition.interimResults = false;
        
        trigger.onclick = () => { triggerHapticPro(40); recognition.start(); };
        recognition.onstart = () => { indicator.style.display = 'block'; };
        recognition.onend = () => { indicator.style.display = 'none'; };
        recognition.onresult = (e) => {
            input.value = e.results[0][0].transcript;
            triggerHapticPro(60); performAdvancedAyahSearch();
        };
    }

    async function performAdvancedAyahSearch() {
        const query = document.getElementById('ayah-search-input').value.trim();
        const resultsBox = document.getElementById('ayah-search-results');
        if(!query) return;
        resultsBox.innerHTML = '<div class="spinner"></div>';
        try {
            const res = await fetch(`https://api.alquran.cloud/v1/search/${encodeURIComponent(query)}/all/ar`);
            const data = await res.json();
            if (data.code === 200 && data.data.matches.length > 0) {
                resultsBox.innerHTML = `<div class="badge" style="margin-bottom:10px;">تم العثور على ${data.data.count} موضع في المصحف</div>`;
                resultsBox.innerHTML += data.data.matches.slice(0, 30).map(m => `
                    <div class="card" style="border-right: 4px solid var(--primary); text-align:right;">
                        <p class="islamic-text" style="font-size:1.3rem;">${m.text} <span class="ayah-circle-num">${m.numberInSurah}</span></p>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px; border-top:1px dashed var(--glass-border); padding-top:8px;">
                            <span style="font-size:0.85rem; color:var(--text-muted);">📖 سورة ${m.surah.name}</span>
                            <button class="btn-secondary" onclick="openSurah(${m.surah.number}, '${m.surah.name}')" style="padding:5px 12px; font-size:0.8rem; border-radius:8px;">فتح السورة</button>
                        </div>
                    </div>
                `).join('');
            } else { resultsBox.innerHTML = '<p style="text-align:center; padding:20px;">لم يتم العثور على نتائج عذراً.</p>'; }
        } catch(e) { resultsBox.innerHTML = '<p style="text-align:center; padding:20px;">خطأ في الاتصال بالخادم.</p>'; }
    }

    async function openSurah(n, name) {
        AppState.currentSurah = n;
        document.getElementById('quran-reader').style.display = 'flex'; 
        document.getElementById('reader-surah-name').innerText = 'سورة ' + name; 
        document.getElementById('reader-verses').innerHTML = '<div class="spinner"></div>';
        window.stopQuranAudio();
        
        try {
            const res = await fetch(`https://api.alquran.cloud/v1/surah/${n}`);
            const data = await res.json();
            let html = (n !== 1 && n !== 9) ? `<div style="color:var(--accent); text-align:center; font-size:1.8rem; margin-bottom:15px; font-family:'Aref Ruqaa',serif;">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>` : '';
            
            data.data.ayahs.forEach((a, idx) => {
                let text = a.text;
                if (n !== 1 && n !== 9 && a.numberInSurah === 1) text = text.replace('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ', '');
                
                // هندسة السلوك السلوكي التفصيلي لوضع التسميع الذكي المتقن وتجزئة الكلمات كبنى مستقلة الاستجابة واللمس
                let processedText = text.split(' ').map(word => `<span class="recite-word" onclick="window.revealWord(this, event)">${word}</span>`).join(' ');
                
                html += `<span class="interactive-ayah" id="ayah-wrapper-${idx}" data-idx="${idx}" oncontextmenu="window.showTafsir(${n}, ${a.numberInSurah}); return false;">${processedText} <span class="ayah-circle-num">${a.numberInSurah}</span></span> `;
            });
            document.getElementById('reader-verses').innerHTML = html; 
            document.getElementById('reader-verses').scrollTop = 0; 
            applyFontSize();
            syncRecitationUIVisuals(); 
            window.fetchSurahAudioUrls();
        } catch (e) { document.getElementById('reader-verses').innerHTML = '<p style="padding:20px; text-align:center;">خطأ في تحميل السورة.</p>'; }
    }

    // محرك التسميع الذكي (الكشف الفردي والميكروي المتقن للكلمة المنسية)
    window.toggleRecitationMode = function() {
        AppState.isRecitationMode = !AppState.isRecitationMode;
        triggerHapticPro(45);
        syncRecitationUIVisuals();
    };

    function syncRecitationUIVisuals() {
        const reader = document.getElementById('quran-reader');
        const btn = document.getElementById('toggle-recitation-btn');
        if(!reader || !btn) return;
        
        if(AppState.isRecitationMode) {
            reader.classList.add('recitation-mode-active');
            btn.innerText = "🟢 وضع التسميع نشط";
            btn.style.background = "rgba(217, 119, 6, 0.15)";
        } else {
            reader.classList.remove('recitation-mode-active');
            btn.innerText = "🎚️ وضع التسميع";
            btn.style.background = "var(--glass-bg)";
            document.querySelectorAll('.recite-word').forEach(w => w.classList.remove('revealed'));
        }
    }

    window.revealWord = function(el, ev) {
        if(!AppState.isRecitationMode) return;
        ev.stopPropagation(); // منع تداخل الحدث مع النوافذ الأخرى
        el.classList.toggle('revealed');
        triggerHapticPro(15);
    };

    function closeQuranReader() { document.getElementById('quran-reader').style.display = 'none'; window.stopQuranAudio(); }
    function applyFontSize() { document.getElementById('reader-verses').style.fontSize = ['1.2rem','1.4rem','1.7rem','2.1rem','2.6rem'][AppState.fontSize]; }

    window.showTafsir = async function(surah, ayah) {
        const modal = document.getElementById('tafsir-glass-modal');
        document.getElementById('tafsir-text').innerHTML = '⏳ جاري جلب البيان الميسر فقهياً...';
        modal.classList.add('show');
        try {
            const res = await fetch(`https://api.alquran.cloud/v1/ayah/${surah}:${ayah}/ar.muyassar`);
            const data = await res.json();
            if(data.code === 200) { document.getElementById('tafsir-text').innerText = data.data.text; } 
        } catch(e) { document.getElementById('tafsir-text').innerText = 'تعذر التحميل حالياً.'; }
    };

    window.fetchSurahAudioUrls = async function() {
        const n = AppState.currentSurah; const reciter = document.getElementById('reciter-select').value;
        try {
            const res = await fetch(`https://api.alquran.cloud/v1/surah/${n}/${reciter}`);
            const data = await res.json();
            if (data.code === 200) { AppState.audioUrls = data.data.ayahs.map(a => a.audio); AppState.currentIndex = 0; }
        } catch(e) { AppState.audioUrls = []; }
    };

    window.changeReciter = function() {
        const wasPlaying = AppState.isPlaying; window.quranAudio.pause();
        window.fetchSurahAudioUrls().then(() => { if (wasPlaying) window.playCurrentAyah(); });
    };

    window.toggleQuranAudio = function() {
        if(AppState.audioUrls.length === 0) return;
        const btn = document.getElementById('audio-play-pause'); const reader = document.getElementById('quran-reader');
        if (AppState.isPlaying) {
            window.quranAudio.pause(); AppState.isPlaying = false; btn.innerHTML = '▶'; reader.classList.remove('aura-active');
        } else {
            window.playCurrentAyah(); btn.innerHTML = '⏸'; reader.classList.add('aura-active'); 
        }
    };

    window.playCurrentAyah = function() {
        if (AppState.currentIndex >= AppState.audioUrls.length) { window.stopQuranAudio(); return; }
        window.quranAudio.src = AppState.audioUrls[AppState.currentIndex];
        window.quranAudio.play().then(() => { AppState.isPlaying = true; window.highlightAyah(); }).catch(()=>{});
    };

    window.playNextAyah = function() { if(AppState.currentIndex < AppState.audioUrls.length - 1) { AppState.currentIndex++; window.playCurrentAyah(); } };
    window.playPrevAyah = function() { if(AppState.currentIndex > 0) { AppState.currentIndex--; window.playCurrentAyah(); } };
    window.stopQuranAudio = function() { window.quranAudio.pause(); AppState.isPlaying = false; AppState.currentIndex = 0; document.getElementById('audio-play-pause').innerHTML = '▶'; document.getElementById('audio-progress-bar').style.width = '0%'; window.clearHighlights(); document.getElementById('quran-reader').classList.remove('aura-active'); };

    window.highlightAyah = function() {
        window.clearHighlights();
        const wrapper = document.getElementById(`ayah-wrapper-${AppState.currentIndex}`);
        if (wrapper) {
            wrapper.classList.add('playing-highlight');
            wrapper.scrollIntoView({ behavior: 'smooth', block: 'center' });
            document.getElementById('audio-progress-bar').style.width = ((AppState.currentIndex + 1)/AppState.audioUrls.length)*100 + '%';
        }
    };

    window.clearHighlights = function() { document.querySelectorAll('.playing-highlight').forEach(el => el.classList.remove('playing-highlight')); };
    window.quranAudio.addEventListener('ended', () => { window.playNextAyah(); });

    // نظام بطاقات الأذكار ثلاثية الأبعاد
    function initAdhkarSystem() {
        const tabs = document.querySelectorAll('#view-adhkar .tab-btn');
        tabs.forEach(t => { 
            t.addEventListener('click', () => { 
                tabs.forEach(tab => tab.classList.remove('active')); t.classList.add('active'); 
                currentAdhkarCategory = t.dataset.category; activeStackIndex = 0;
                renderAdhkarStack(currentAdhkarCategory); 
            }); 
        });
        document.getElementById('stack-next-btn').onclick = () => { navigateStack(1); };
        document.getElementById('stack-prev-btn').onclick = () => { navigateStack(-1); };
        renderAdhkarStack('morning');
    }

    function renderAdhkarStack(cat) {
        const items = ADHKAR_DATA[cat] || []; const container = document.getElementById('adhkar-stack-container'); const counter = document.getElementById('stack-index-counter');
        if(items.length === 0) { container.innerHTML = '<p style="padding:20px; text-align:center;">سيتم إضافة الورد قريباً.</p>'; counter.innerText = "0 / 0"; return; }
        
        counter.innerText = `${activeStackIndex + 1} / ${items.length}`;
        container.innerHTML = items.map((i, idx) => {
            const progress = AppState.adhkarProgress[i.id] || 0; const isDone = progress >= i.target;
            let transformStyle = `translate3d(0, 24px, -100px) scale(0.9) rotateX(-2deg)`; let opacity = 0; let zIndex = 0;

            if (idx === activeStackIndex) { transformStyle = `translate3d(0, 0, 0) scale(1) rotateX(0deg)`; opacity = 1; zIndex = 10; } 
            else if (idx === activeStackIndex + 1) { transformStyle = `translate3d(0, 14px, -40px) scale(0.95) rotateX(-1deg)`; opacity = 0.75; zIndex = 9; } 
            else if (idx === activeStackIndex + 2) { transformStyle = `translate3d(0, 28px, -80px) scale(0.90) rotateX(-2deg)`; opacity = 0.35; zIndex = 8; }

            return `
                <div class="dhikr-stack-card ${isDone?'completed-card':''}" id="scard-${i.id}" style="transform: ${transformStyle}; opacity: ${opacity}; z-index: ${zIndex};">
                    <div class="dhikr-header"><span style="color:var(--accent); font-weight:800;">✨ ${i.info}</span><span class="badge">المطلوب: ${i.target}</span></div>
                    <div class="dhikr-text-container"><p class="islamic-text" style="font-size:1.35rem; width:100%;">${i.text}</p></div>
                    <div class="progress-bar-container"><div class="progress-bar-fill" id="pfill-${i.id}" style="width:${(progress/i.target)*100}%"></div></div>
                    <button class="counter-btn ripple-effect ${isDone?'done':''}" id="sbtn-${i.id}" onclick="incrementStackDhikr('${i.id}', ${i.target})">
                        ${isDone ? '✅ أتممت الورد والتحصين المبارك' : `التكرار الحالي: ${progress}`}
                    </button>
                </div>
            `;
        }).join('');
        setupDragAndSwipe(container);
    }

    function navigateStack(dir) {
        const items = ADHKAR_DATA[currentAdhkarCategory] || []; const newIdx = activeStackIndex + dir;
        if (newIdx >= 0 && newIdx < items.length) { activeStackIndex = newIdx; triggerHapticPro(25); renderAdhkarStack(currentAdhkarCategory); }
    }

    function incrementStackDhikr(id, target) {
        if (!AppState.adhkarProgress[id]) AppState.adhkarProgress[id] = 0;
        if (AppState.adhkarProgress[id] < target) {
            let p = ++AppState.adhkarProgress[id];
            document.getElementById(`pfill-${id}`).style.width = `${(p/target)*100}%`;
            let btn = document.getElementById(`sbtn-${id}`); 
            btn.innerText = p >= target ? '✅ أتممت الورد والتحصين المبارك' : `التكرار الحالي: ${p}`;
            if (p >= target) {
                btn.classList.add('done'); document.getElementById(`scard-${id}`).classList.add('completed-card');
                triggerHapticPro(100); setTimeout(() => { navigateStack(1); }, 800);
            } else { triggerHapticPro(35); }
            savePersistence();
        }
    }

    function setupDragAndSwipe(el) {
        let startY = 0; let distY = 0;
        el.onmousedown = (e) => { startY = e.clientY; };
        el.onmouseup = (e) => { distY = e.clientY - startY; if(Math.abs(distY) > 60) navigateStack(distY > 0 ? -1 : 1); };
        el.ontouchstart = (e) => { startY = e.touches[0].clientY; };
        el.ontouchend = (e) => { distY = e.changedTouches[0].clientY - startY; if(Math.abs(distY) > 50) navigateStack(distY > 0 ? -1 : 1); };
    }

    function resetAdhkarProgress() {
        const items = ADHKAR_DATA[currentAdhkarCategory] || [];
        items.forEach(i => { AppState.adhkarProgress[i.id] = 0; });
        triggerHapticPro(180); savePersistence(); activeStackIndex = 0; renderAdhkarStack(currentAdhkarCategory);
    }

    // السبحة
    function initTasbeehSystem() {
        const btn = document.getElementById('tasbeeh-btn'); const display = document.getElementById('tasbeeh-main-count'); const widgetToggle = document.getElementById('toggle-widget-btn');
        display.innerText = AppState.tasbeehCount;
        btn.onclick = () => { AppState.tasbeehCount++; display.innerText = AppState.tasbeehCount; triggerHapticPro(35); savePersistence(); };
        document.getElementById('tasbeeh-reset').onclick = () => { AppState.tasbeehCount = 0; display.innerText = '0'; triggerHapticPro(180); savePersistence(); };
        
        const phrases = ["سبحان الله وبحمده", "الحمد لله رب العالمين", "لا إله إلا الله", "الله أكبر كبيراً", "أستغفر الله وأتوب إليه", "اللهم صلِّ على محمد"];
        let idx = 0;
        document.getElementById('tasbeeh-mode').onclick = () => { idx = (idx+1)%phrases.length; document.getElementById('current-dhikr-text').innerText = phrases[idx]; triggerHapticPro(25); };

        widgetToggle.onclick = () => {
            AppState.isWidgetMode = !AppState.isWidgetMode; triggerHapticPro(50);
            if(AppState.isWidgetMode) { btn.classList.add('floating-widget'); widgetToggle.innerText = "🟢 إرجاع لحجمه الطبيعي"; } 
            else { btn.classList.remove('floating-widget'); widgetToggle.innerText = "📱 العداد العائم"; }
        };
    }

    // تتبع الختمة
    function initKhatmahSystem() {
        if (!document.getElementById("khatmah-tracker-node")) {
            const trackerNode = document.createElement("div"); trackerNode.id = "khatmah-tracker-node"; trackerNode.className = "khatmah-tracker-container";
            trackerNode.innerHTML = `<div>📈 حصيلة المتابعة: <span id="ext-khatmah-counter" style="font-weight: 900; color: var(--primary);">٠ أجزاء</span></div><div class="khatmah-badge-pill" id="ext-khatmah-medal">مرتبة البدء 🌱</div>`;
            const circle = document.getElementById("khatmah-progress-circle");
            if (circle) circle.closest('.khatmah-header-card').parentNode.insertBefore(trackerNode, document.getElementById("khatmah-days-container"));
        }
        renderKhatmah(); 
    }

    function renderKhatmah() {
        const percentage = Math.round((AppState.khatmahProgress.length/30)*100);
        document.getElementById('khatmah-percent').innerText = `${percentage}%`;
        document.getElementById('khatmah-progress-circle').style.background = `conic-gradient(var(--accent) ${percentage}%, rgba(255,255,255,0.15) ${percentage}%)`;
        document.getElementById('khatmah-status-title').innerText = AppState.khatmahProgress.length > 0 ? `الختمة جارية بهمة ونور` : "لم تبدأ الختمة الشهرية بعد";
        
        const countField = document.getElementById("ext-khatmah-counter"); const medalField = document.getElementById("ext-khatmah-medal"); const totalRead = AppState.khatmahProgress.length;
        if (countField) countField.innerText = `${totalRead} / ٣٠ جزءًا`;
        if (medalField) {
            if (totalRead >= 25) { medalField.innerHTML = "خاتم خاشع 👑"; medalField.style.background = "linear-gradient(135deg, #10b981, #047857)"; } 
            else if (totalRead >= 10) { medalField.innerHTML = "الهمّة العالية 💎"; medalField.style.background = "linear-gradient(135deg, #6366f1, #4338ca)"; } 
            else if (totalRead >= 1) { medalField.innerHTML = "مداوم قرآن 🌤️"; medalField.style.background = "linear-gradient(135deg, var(--accent), #b45309)"; } 
            else { medalField.innerHTML = "مرتبة البدء 🌱"; medalField.style.background = "linear-gradient(135deg, var(--text-muted), #475569)"; }
        }
        document.getElementById('khatmah-days-container').innerHTML = KHATMAH_PLAN.map((p, i) => `
            <div class="khatmah-day-item ripple-effect ${AppState.khatmahProgress.includes(i+1)?'completed':''}" onclick="toggleKhatmahDay(${i+1})">
                <div><h4 style="font-weight:800; color:var(--primary);">اليوم المبارك ${i+1}</h4><p style="font-size:0.85rem; color:var(--text-muted); margin-top:2px;">${p}</p></div>
                <div class="khatmah-check">✔</div>
            </div>
        `).join('');
    }

    function toggleKhatmahDay(day) {
        if (AppState.khatmahProgress.includes(day)) AppState.khatmahProgress = AppState.khatmahProgress.filter(d => d !== day);
        else { AppState.khatmahProgress.push(day); triggerHapticPro(50); }
        savePersistence(); renderKhatmah();
    }
    function resetKhatmahProgress() { AppState.khatmahProgress = []; triggerHapticPro(180); savePersistence(); renderKhatmah(); }

    // الرقائق والسنة
    function initKnowledgeSystem() {
        const tabs = document.querySelectorAll('#knowledge-tabs-nav .tab-btn');
        tabs.forEach(t => { t.addEventListener('click', function() { tabs.forEach(tab => tab.classList.remove('active')); this.classList.add('active'); renderKnowledge(this.dataset.source); }); });
        renderKnowledge('hadith');
    }

    function renderKnowledge(src) {
        const box = document.getElementById('knowledge-content'); if (!box) return;
        if (src === 'hadith') {
            box.innerHTML = MEGA_HADITH_DATA.map(c => `<div style="background:linear-gradient(135deg, var(--primary), var(--primary-dark)); color:white; padding:12px; border-radius:12px; margin:15px 0 10px; font-weight:800; font-size:0.92rem; text-align:center;">${c.chapter}</div>` + c.hadiths.map(h => `<div class="card" style="border-right: 4px solid var(--accent); text-align:right;"><div class="badge" style="margin-bottom:10px;">✨ ${h.topic}</div><p class="islamic-text" style="font-size:1.4rem; text-align: justify;">«${h.text}»</p><div class="knowledge-footer-react"><span>📚 المصدر: ${h.source}</span><span class="knowledge-react-btn" onclick="this.innerText='❤️ تم التدبر'">❤️ تأملتها</span></div></div>`).join('')).join('');
        } else if (src === 'sunnah') {
            box.innerHTML = SUNNAH_DATA.map(s => `<div class="card" style="border-right: 4px solid var(--primary); text-align:right;"><h3 style="color:var(--primary); font-weight:800; font-family:'Reem Kufi',sans-serif;">🌱 ${s.title}</h3><p style="margin-top:8px; color:var(--text-main); font-size:1.05rem; line-height:1.7; text-align: justify; font-family:var(--font-ui);">${s.desc}</p><div class="knowledge-footer-react"><span>📚 المصدر: ${s.source}</span><span class="knowledge-react-btn" onclick="this.innerText='❤️ تم العمل بها'">❤️ تطبيق السُنّة</span></div></div>`).join('');
        } else if (src === 'stories') {
            box.innerHTML = STORIES_DATA.map(s => `<div class="card" style="border-right: 4px solid #10b981; text-align:right;"><h3 style="color:var(--primary-dark); font-weight:800; font-family:'Reem Kufi',sans-serif; margin-bottom:6px;">📖 ${s.title}</h3><p style="color:var(--text-main); font-size:1.1rem; line-height:1.8; text-align: justify; font-family:var(--font-quran);">${s.desc}</p><div class="knowledge-footer-react" style="margin-top:15px;"><span style="font-weight:700; color:var(--text-muted);">${s.source}</span><span class="knowledge-react-btn" style="color:#10b981;" onclick="this.innerHTML='❤️ تم استخلاص العِبرة';">❤️ تدبر وعِبرة</span></div></div>`).join('');
        }
    }

    // بوصلة القبلة
    function initQiblaSystem() {
        const btn = document.getElementById('enable-compass');
        btn.onclick = () => {
            if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
                DeviceOrientationEvent.requestPermission().then(state => { if (state === 'granted') { window.addEventListener('deviceorientation', handleCompass, true); btn.style.display = 'none'; } });
            } else { window.addEventListener('deviceorientation', handleCompass, true); btn.style.display = 'none'; }
        };
    }
    
    function handleCompass(e) {
        let alpha = e.alpha; if (e.webkitCompassHeading) alpha = 360 - e.webkitCompassHeading;
        if (alpha === null) return; const qiblaAngle = 65; 
        document.getElementById('compass-rose').style.transform = `rotate3d(0, 0, 1, ${-alpha}deg)`;
        document.getElementById('qibla-pointer').style.transform = `translate3d(-50%, -100%, 0) rotate3d(0, 0, 1, ${(qiblaAngle - alpha)}deg)`;
        
        let diff = Math.abs(alpha - qiblaAngle);
        if (diff < 8 || diff > 352) {
            document.getElementById('compass-outer').classList.add('aligned');
            document.getElementById('qibla-text').innerHTML = '🟢 اتجاه الكعبة المشرفة صحيح 🕋';
            triggerHapticPro(30);
        } else {
            document.getElementById('compass-outer').classList.remove('aligned');
            document.getElementById('qibla-text').innerText = 'قم بتدوير الهاتف حتى يتطابق المؤشر مع القبلة';
        }
    }

    initApp();
