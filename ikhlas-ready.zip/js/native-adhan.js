/* جدولة الأذان: كود أندرويد أصلي (AlarmManager + خدمة مقدّمة + fullScreenIntent) مع رجوع تلقائي إلى LocalNotifications */
(function(){
const DAYS=7,CH='adhan',NAMES={Fajr:'الفجر',Sunrise:'الشروق',Dhuhr:'الظهر',Asr:'العصر',Maghrib:'المغرب',Isha:'العشاء'};
const IDX={Fajr:1,Sunrise:2,Dhuhr:3,Asr:4,Maghrib:5,Isha:6};
const isNative=()=>window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform();
const LN=()=>isNative()&&Capacitor.Plugins.LocalNotifications;
let _an=null;
const AN=()=>{if(!isNative())return null;try{return _an||(_an=Capacitor.registerPlugin('AdhanNative'));}catch(e){return null;}};
let busy=false,again=false;
async function ensureChannel(ln,sound){
  try{await ln.deleteChannel({id:CH});}catch(e){}
  await ln.createChannel({id:CH,name:'الأذان',description:'تنبيهات أوقات الصلاة',importance:5,visibility:1,vibration:true,sound:sound});
}
/* صلاحيات الأذان الأصلي: تُطلب مرة واحدة لكل نوع كي لا نزعج المستخدم */
async function askPerms(an){
  try{
    const s=await an.status(),ask=(k,fn)=>{if(localStorage.getItem('ikhlas_ask_'+k))return;localStorage.setItem('ikhlas_ask_'+k,'1');return fn();};
    /* المنبّه الدقيق لا يحتاج إذناً خاصاً (نستخدم setAlarmClock)؛ المهم: شاشة كاملة ثم استثناء البطارية */
    if(!s.fullScreen)await ask('fs',()=>an.requestFullScreen());
    else if(!s.ignoringBattery)await ask('bat',()=>an.openBatterySettings());
  }catch(e){}
}
async function reschedule(){
  const ln=LN(),an=AN();if(!ln&&!an)return;
  if(busy){again=true;return;}busy=true;
  try{
    if(ln){
      let granted=true;
      try{const perm=await ln.checkPermissions();granted=perm.display==='granted';if(!granted){const r=await ln.requestPermissions();granted=r.display==='granted';}}catch(e){}
      if(!granted&&!an)return; /* الأذان الأصلي يعمل دون إذن الإشعارات؛ نكتفي بالإيقاف فقط إن لم تتوفر الإضافة */
      const pending=await ln.getPending();
      if(pending.notifications.length)await ln.cancel({notifications:pending.notifications.map(n=>({id:n.id}))});
    }
    const on=document.getElementById('setting-adhan-enabled');
    if(on&&!on.checked){if(an)try{await an.cancelAll();}catch(e){}return;}
    const sound=(AdhanRegistry.fileFor(localStorage.getItem('IkhlasAdhanId')));
    const cfg=(window.AppState&&AppState.prayerConfig)||{Fajr:1,Dhuhr:1,Asr:1,Maghrib:1,Isha:1};
    const method=document.getElementById('setting-calc-method').value,L=AppState.userLocation,now=Date.now(),list=[];
    for(let d=-1;d<DAYS;d++){
      const day=new Date();day.setDate(day.getDate()+d);
      const t=PrayerCalc.times(day,L.lat,L.lng,method);
      for(const k of Object.keys(IDX)){
        if(!cfg[k])continue;
        const [h,m]=t[k].split(':').map(Number),at=new Date(day.getFullYear(),day.getMonth(),day.getDate(),h,m,0);
        const P=window.Personal;
        list.push({id:d*10+IDX[k],title:'حان الآن موعد أذان '+NAMES[k],body:P?P.line(k,at):(k==='Sunrise'?'طلعت الشمس':'حيّ على الصلاة'),
          at:at.getTime(),prayer:k,sound:sound,color:P?P.color(k):'#0d9488'});
      }
    }
    /* 1) الطريق الأصلي: خدمة أذان + شاشة كاملة */
    let done=false;
    if(an){
      try{await an.schedule({alarms:list});done=true;askPerms(an);}
      catch(e){console.warn('native adhan unavailable, falling back',e);}
    }
    /* 2) الرجوع إلى إشعارات Capacitor إن لم تتوفر الإضافة الأصلية */
    const future=list.filter(n=>n.at>now);
    if(!done&&ln&&future.length&&(await ln.checkPermissions().then(p=>p.display==='granted').catch(()=>false))){
      try{const ex=await ln.checkExactNotificationSetting();if(ex.exact_alarm!=='granted')await ln.changeExactNotificationSetting();}catch(e){}
      await ensureChannel(ln,sound);
      await ln.schedule({notifications:future.map(n=>({id:n.id,title:n.title,body:n.body,schedule:{at:new Date(n.at),allowWhileIdle:true},
        channelId:CH,sound:sound,smallIcon:'ic_stat_icon',iconColor:n.color,extra:{prayer:n.prayer}}))});
    }
  }catch(e){console.warn('adhan schedule failed',e);}
  finally{busy=false;if(again){again=false;reschedule();}}
}
window.NativeAdhan={reschedule:reschedule,setSound:function(){reschedule();},plugin:AN,
  test:function(k){const an=AN();if(!an)return;const P=window.Personal;k=k||'Dhuhr';
    return an.test({prayer:k,title:'حان الآن موعد أذان '+NAMES[k],body:P?P.line(k,new Date()):'حيّ على الصلاة',sound:AdhanRegistry.fileFor(localStorage.getItem('IkhlasAdhanId')),color:P?P.color(k):'#0d9488'});},
  stop:function(){const an=AN();return an&&an.stop();},
  setCountdown:function(on){try{localStorage.setItem('ikhlas_countdown',on?'1':'0')}catch(e){}const an=AN();return an&&an.setCountdown({enabled:!!on});},
  status:function(){const an=AN();return an?an.status():Promise.resolve(null);},
  requestFullScreen:function(){const an=AN();return an&&an.requestFullScreen();},
  openBatterySettings:function(){const an=AN();return an&&an.openBatterySettings();}};
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&window.AppState&&AppState.prayerTimes.Fajr)reschedule();});
document.addEventListener('DOMContentLoaded',()=>{
  ['setting-adhan-enabled','setting-calc-method'].forEach(id=>{const e=document.getElementById(id);if(e)e.addEventListener('change',reschedule);});
  const cd=document.getElementById('setting-countdown'),off=(function(){try{return localStorage.getItem('ikhlas_countdown')==='0'}catch(e){return false}})();
  if(cd){cd.checked=!off;cd.addEventListener('change',()=>NativeAdhan.setCountdown(cd.checked));}
  if(off){const an=AN();if(an)try{an.setCountdown({enabled:false})}catch(e){}}
});
})();
