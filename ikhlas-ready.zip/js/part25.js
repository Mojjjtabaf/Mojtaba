(function initJourneyOfLight() {
    'use strict';

    // 1. المراحل
    const STAGES = [
        { id: 1, name: "بداية الطريق", icon: "🕌", pointsReq: 0 },
        { id: 2, name: "بستان الذكر", icon: "🌿", pointsReq: 100 },
        { id: 3, name: "نهر القرآن", icon: "📖", pointsReq: 300 },
        { id: 4, name: "واحة الدعاء", icon: "🤲", pointsReq: 600 },
        { id: 5, name: "جبل الصبر", icon: "⛰️", pointsReq: 1000 },
        { id: 6, name: "مدينة النور", icon: "🌟", pointsReq: 1500 },
        { id: 7, name: "قصر الحكمة", icon: "🏛️", pointsReq: 2100 },
        { id: 8, name: "سماء النجوم", icon: "🌌", pointsReq: 2800 },
        { id: 9, name: "درب العلماء", icon: "✨", pointsReq: 3600 },
        { id: 10, name: "محطة الإخلاص", icon: "🕋", pointsReq: 4500 },
        { id: 11, name: "بحر اليقين", icon: "🌊", pointsReq: 5600 },
        { id: 12, name: "جبل عرفات", icon: "🏔️", pointsReq: 6800 },
        { id: 13, name: "روضة المحبين", icon: "🌺", pointsReq: 8200 },
        { id: 14, name: "أبواب الريان", icon: "🚪", pointsReq: 10000 },
        { id: 15, name: "الفردوس الأعلى", icon: "👑", pointsReq: 15000 }
    ];


    // 2. الإنجازات والجوائز
    const DAILY_GOAL = 10, DAILY_BONUS = 50, HINT_COST = 5;
    const ACHIEVEMENTS_DB = [
        { id: "first_blood", title: "بداية الغيث", desc: "أجبت على أول سؤال صحيح", icon: "🌱", type: "points", target: 10 },
        { id: "streak_5", title: "شعلة التركيز", desc: "أجبت 5 إجابات متتالية صحيحة", icon: "🔥", type: "streak", target: 5 },
        { id: "streak_10", title: "عقل يقظ", desc: "أجبت 10 إجابات متتالية صحيحة", icon: "🧠", type: "streak", target: 10 },
        { id: "streak_20", title: "موسوعة متحركة", desc: "أجبت 20 إجابة متتالية صحيحة", icon: "🏆", type: "streak", target: 20 },
        { id: "answered_50", title: "مجتهد", desc: "أجبت على 50 سؤالاً", icon: "📝", type: "answered", target: 50 },
        { id: "answered_200", title: "طالب همّة", desc: "أجبت على 200 سؤال", icon: "🎓", type: "answered", target: 200 },
        { id: "daily_goal", title: "وفاء بالعهد", desc: "أتممت هدف اليوم (10 أسئلة)", icon: "🎯", type: "daily", target: 1 },
        { id: "points_1000", title: "طالب علم", desc: "جمعت 1000 نقطة نورانية", icon: "📚", type: "points", target: 1000 },
        { id: "points_5000", title: "عالم رباني", desc: "جمعت 5000 نقطة نورانية", icon: "🌟", type: "points", target: 5000 }
    ];

    // 3. بنك الأسئلة (الإجابة الصحيحة أولاً في الأسئلة المضافة، ويُعاد ترتيب الخيارات عشوائياً وقت العرض)
    const BASE_BANK = [
        { cat: "القرآن الكريم", diff: "سهل", text: "ما هي أطول سورة في القرآن الكريم؟", options: ["سورة البقرة", "سورة آل عمران", "سورة النساء", "سورة المائدة"], correct: 0, explanation: "سورة البقرة هي الأطول وتتكون من 286 آية." },
        { cat: "السيرة النبوية", diff: "سهل", text: "في أي غار كان يتعبد النبي ﷺ قبل البعثة؟", options: ["غار ثور", "غار حراء", "غار المقطم", "غار أحد"], correct: 1, explanation: "كان يتعبد في غار حراء بجبل النور بمكة المكرمة." },
        { cat: "الفقه الأساسي", diff: "سهل", text: "ما هو الركن الثاني من أركان الإسلام؟", options: ["الزكاة", "صوم رمضان", "إقام الصلاة", "حج البيت"], correct: 2, explanation: "بني الإسلام على خمس: الشهادتان، ثم إقام الصلاة." },
        { cat: "الصحابة", diff: "متوسط", text: "من هو الصحابي الجليل الملقب بـ 'أمين هذه الأمة'؟", options: ["أبو بكر الصديق", "أبو عبيدة بن الجراح", "عمر بن الخطاب", "علي بن أبي طالب"], correct: 1, explanation: "لقبه النبي ﷺ بذلك لأمانته العظيمة يوم الحديبية." },
        { cat: "العقيدة", diff: "متوسط", text: "الإيمان بالقدر خيره وشره من أركان...", options: ["الإسلام", "الإيمان", "الإحسان", "التقوى"], correct: 1, explanation: "أركان الإيمان ستة، آخرها الإيمان بالقدر خيره وشره." },
        { cat: "الأنبياء", diff: "سهل", text: "من هو النبي الذي أُلقي في النار فجعلها الله برداً وسلاماً عليه؟", options: ["موسى عليه السلام", "إبراهيم عليه السلام", "عيسى عليه السلام", "يونس عليه السلام"], correct: 1, explanation: "قال تعالى: (قُلْنَا يَا نَارُ كُونِي بَرْدًا وَسَلَامًا عَلَىٰ إِبْرَاهِيمَ)." },
        { cat: "الأخلاق الإسلامية", diff: "سهل", text: "أكمل الحديث: (تبسمك في وجه أخيك لك ...)", options: ["أجر", "حسنات", "صدقة", "مغفرة"], correct: 2, explanation: "الابتسامة من أيسر أبواب الصدقات." },
        { cat: "رمضان", diff: "سهل", text: "في أي شهر هجري نزل القرآن الكريم؟", options: ["رجب", "شعبان", "رمضان", "شوال"], correct: 2, explanation: "قال تعالى: (شَهْرُ رَمَضَانَ الَّذِي أُنزِلَ فِيهِ الْقُرْآنُ)." },
        { cat: "التفسير", diff: "متوسط", text: "ما معنى كلمة 'الصمد' في سورة الإخلاص؟", options: ["الذي لا شبيه له", "السيد الذي يُقصد في الحوائج", "الخالق لكل شيء", "الغفور الرحيم"], correct: 1, explanation: "الصمد هو السيد الذي يُصمد إليه في قضاء الحوائج والرغائب." },
        { cat: "الفقه الأساسي", diff: "صعب", text: "ما هو مقدار زكاة الذهب إذا بلغ النصاب وحال عليه الحول؟", options: ["العشر", "نصف العشر", "ربع العشر (2.5%)", "الخمس"], correct: 2, explanation: "زكاة الذهب والمال هي ربع العشر أي 2.5%." }
    ];
    const Q = (cat, diff, text, options, explanation) => ({ cat, diff, text, options, correct: 0, explanation });
    const NEW_BANK = [
        Q("القرآن الكريم","سهل","كم عدد سور القرآن الكريم؟",["114 سورة","110 سور","120 سورة","100 سورة"],"عدد سور القرآن 114 سورة، أولها الفاتحة وآخرها الناس."),
        Q("القرآن الكريم","سهل","ما أقصر سورة في القرآن الكريم؟",["الكوثر","الإخلاص","العصر","الفلق"],"سورة الكوثر ثلاث آيات، وهي أقصر سور القرآن."),
        Q("القرآن الكريم","سهل","كم عدد أجزاء القرآن الكريم؟",["30 جزءاً","25 جزءاً","40 جزءاً","60 جزءاً"],"يتكون المصحف من 30 جزءاً، وكل جزء قسمان من الحزب."),
        Q("القرآن الكريم","سهل","أي سورة تُسمّى «السبع المثاني»؟",["الفاتحة","البقرة","الإخلاص","يس"],"سُمّيت الفاتحة السبع المثاني لأن آياتها سبع وتُثنّى في كل ركعة."),
        Q("القرآن الكريم","سهل","في أي سورة وردت قصة أصحاب الكهف؟",["سورة الكهف","سورة مريم","سورة الأنبياء","سورة الإسراء"],"ورد ذكر أصحاب الكهف في سورة الكهف، ويُستحب قراءتها يوم الجمعة."),
        Q("القرآن الكريم","سهل","أي سورة تعدل ثلث القرآن كما ورد في الحديث الصحيح؟",["الإخلاص","الفاتحة","الناس","الكافرون"],"قال ﷺ عن ﴿قل هو الله أحد﴾ إنها تعدل ثلث القرآن."),
        Q("القرآن الكريم","متوسط","أي سورة في القرآن لا تبدأ بالبسملة؟",["التوبة","الأنفال","يونس","الأحقاف"],"سورة التوبة هي السورة الوحيدة التي تبدأ دون بسملة."),
        Q("القرآن الكريم","متوسط","أي آية وُصفت في الحديث بأنها أعظم آية في القرآن؟",["آية الكرسي","آية الدَّين","آخر آية في البقرة","أول آية في آل عمران"],"أخبر النبي ﷺ أُبيّ بن كعب أن آية الكرسي أعظم آية في كتاب الله."),
        Q("القرآن الكريم","صعب","ما أطول آية في القرآن الكريم؟",["آية الدَّين","آية الكرسي","آية النور","آية الوضوء"],"آية الدَّين في سورة البقرة (282) هي أطول آية في القرآن."),
        Q("القرآن الكريم","صعب","في أي سورة وردت الآية: ﴿ألا بذكر الله تطمئن القلوب﴾؟",["الرعد","الحجر","الأنفال","الزمر"],"وردت الآية في سورة الرعد (الآية 28)."),
        Q("القرآن الكريم","صعب","في أي سورة ورد اسم «أحمد» صريحاً؟",["الصف","الفتح","آل عمران","الأحزاب"],"ورد في سورة الصف: ﴿ومبشراً برسول يأتي من بعدي اسمه أحمد﴾."),
        Q("الصحابة","صعب","من الصحابي الوحيد الذي ذُكر اسمه صراحة في القرآن الكريم؟",["زيد بن حارثة","أبو بكر الصديق","علي بن أبي طالب","عمر بن الخطاب"],"ذُكر زيد بن حارثة رضي الله عنه في سورة الأحزاب (الآية 37)."),

        Q("السيرة النبوية","سهل","ما اسم أم النبي ﷺ؟",["آمنة بنت وهب","خديجة بنت خويلد","حليمة السعدية","فاطمة بنت أسد"],"أمه ﷺ هي آمنة بنت وهب، وتوفيت وهو صغير."),
        Q("السيرة النبوية","سهل","في أي عام وُلد النبي ﷺ؟",["عام الفيل","عام الحزن","عام الوفود","عام الرمادة"],"وُلد ﷺ في مكة عام الفيل، وهو العام الذي حاول فيه أبرهة هدم الكعبة."),
        Q("السيرة النبوية","سهل","ما القبلة الأولى التي صلّى إليها المسلمون؟",["بيت المقدس","الكعبة","جبل حراء","مسجد قباء"],"صلّى المسلمون إلى بيت المقدس ثم حُوّلت القبلة إلى الكعبة."),
        Q("السيرة النبوية","سهل","من أول امرأة آمنت بالنبي ﷺ؟",["خديجة بنت خويلد","عائشة بنت أبي بكر","فاطمة الزهراء","أم سلمة"],"كانت خديجة رضي الله عنها أول من آمن به ﷺ وصدّقه ونصره."),
        Q("السيرة النبوية","متوسط","ما الاسم الآخر لغزوة الخندق؟",["غزوة الأحزاب","غزوة مؤتة","غزوة تبوك","غزوة حنين"],"سُمّيت الأحزاب لاجتماع قبائل العرب على حصار المدينة."),
        Q("السيرة النبوية","متوسط","في أي سنة هجرية كان فتح مكة؟",["8 هـ","6 هـ","5 هـ","10 هـ"],"كان الفتح في رمضان سنة 8 هـ، ودخلها النبي ﷺ متواضعاً وعفا عن أهلها."),
        Q("السيرة النبوية","متوسط","كم عاماً عاش النبي ﷺ؟",["63 عاماً","60 عاماً","65 عاماً","70 عاماً"],"توفي النبي ﷺ وعمره ثلاث وستون سنة."),
        Q("السيرة النبوية","متوسط","كم مدة نزول الوحي على النبي ﷺ من البعثة إلى وفاته؟",["23 سنة","13 سنة","10 سنوات","40 سنة"],"مكث ﷺ في مكة نحو 13 سنة وفي المدينة 10 سنوات بعد البعثة."),

        Q("الصحابة","سهل","من أول الخلفاء الراشدين؟",["أبو بكر الصديق","عمر بن الخطاب","عثمان بن عفان","علي بن أبي طالب"],"أبو بكر الصديق رضي الله عنه هو أول الخلفاء الراشدين."),
        Q("الصحابة","سهل","من الصحابي الملقب بـ«سيف الله المسلول»؟",["خالد بن الوليد","حمزة بن عبد المطلب","الزبير بن العوام","سعد بن أبي وقاص"],"لقّبه النبي ﷺ بسيف الله لبلائه في الفتوحات."),
        Q("الصحابة","سهل","من الصحابي الملقب بـ«الفاروق»؟",["عمر بن الخطاب","أبو بكر الصديق","علي بن أبي طالب","عثمان بن عفان"],"لُقّب بالفاروق لأن الله فرّق به بين الحق والباطل."),
        Q("الصحابة","سهل","من الصحابي الملقب بـ«ذي النورين»؟",["عثمان بن عفان","علي بن أبي طالب","الزبير بن العوام","طلحة بن عبيد الله"],"لقّب به لأنه تزوّج ابنتي النبي ﷺ رقية ثم أم كلثوم."),
        Q("الصحابة","سهل","من أول من أذّن في الإسلام؟",["بلال بن رباح","زيد بن ثابت","سلمان الفارسي","أنس بن مالك"],"كان بلال رضي الله عنه أول مؤذن في الإسلام."),
        Q("الصحابة","متوسط","من الصحابي الملقب بـ«أسد الله»؟",["حمزة بن عبد المطلب","أبو دجانة","سعد بن معاذ","عبد الله بن رواحة"],"لُقّب عمّ النبي ﷺ حمزة بأسد الله وأسد رسوله."),
        Q("الصحابة","متوسط","من أكثر الصحابة رواية للحديث؟",["أبو هريرة","عبد الله بن عمر","أنس بن مالك","عائشة"],"روى أبو هريرة رضي الله عنه أكثر من خمسة آلاف حديث."),
        Q("الصحابة","متوسط","من الصحابي الذي كناه النبي ﷺ «أبا تراب»؟",["علي بن أبي طالب","عمار بن ياسر","أبو ذر الغفاري","سلمان الفارسي"],"كنّاه به النبي ﷺ فكانت أحب كناه إليه."),
        Q("الصحابة","متوسط","أي صحابي خطب أمام النجاشي ملك الحبشة؟",["جعفر بن أبي طالب","بلال بن رباح","عثمان بن مظعون","خالد بن الوليد"],"كان جعفر بن أبي طالب متحدث المهاجرين إلى الحبشة."),

        Q("العقيدة","سهل","كم عدد أركان الإيمان؟",["ستة","خمسة","سبعة","ثمانية"],"أركان الإيمان ستة: الإيمان بالله وملائكته وكتبه ورسله واليوم الآخر والقدر."),
        Q("العقيدة","سهل","كم عدد أركان الإسلام؟",["خمسة","ستة","أربعة","سبعة"],"أركان الإسلام خمسة: الشهادتان والصلاة والزكاة والصوم والحج."),
        Q("العقيدة","سهل","ما اسم الملك الموكل بالوحي؟",["جبريل","ميكائيل","إسرافيل","مالك"],"جبريل عليه السلام هو الأمين على الوحي."),
        Q("العقيدة","متوسط","من الملك الموكل بالنفخ في الصور؟",["إسرافيل","جبريل","ميكائيل","رضوان"],"ورد في الأحاديث أن إسرافيل ينفخ في الصور."),
        Q("العقيدة","سهل","على أي نبي أُنزل الإنجيل؟",["عيسى عليه السلام","موسى عليه السلام","داود عليه السلام","إبراهيم عليه السلام"],"أُنزل الإنجيل على عيسى، والتوراة على موسى، والزبور على داود."),

        Q("الأنبياء","سهل","من أول الأنبياء عليهم السلام؟",["آدم","نوح","إبراهيم","إدريس"],"آدم عليه السلام أبو البشر وأول الأنبياء."),
        Q("الأنبياء","سهل","من النبي الذي كلّمه الله تكليماً؟",["موسى عليه السلام","عيسى عليه السلام","إبراهيم عليه السلام","يوسف عليه السلام"],"لُقّب موسى بكليم الله."),
        Q("الأنبياء","سهل","من النبي الذي ابتلعه الحوت؟",["يونس عليه السلام","أيوب عليه السلام","زكريا عليه السلام","إلياس عليه السلام"],"دعا يونس ربه في بطن الحوت: ﴿لا إله إلا أنت سبحانك إني كنت من الظالمين﴾."),
        Q("الأنبياء","سهل","من النبي الذي سُخّرت له الريح والجن؟",["سليمان عليه السلام","داود عليه السلام","صالح عليه السلام","هود عليه السلام"],"آتى الله سليمان ملكاً لا ينبغي لأحد من بعده."),
        Q("الأنبياء","سهل","من النبي الذي اشتهر بالصبر على المرض؟",["أيوب عليه السلام","يعقوب عليه السلام","يحيى عليه السلام","لوط عليه السلام"],"ضُرب أيوب مثلاً في الصبر على البلاء."),
        Q("الأنبياء","متوسط","كم عدد الرسل أولي العزم؟",["خمسة","ثلاثة","سبعة","عشرة"],"هم نوح وإبراهيم وموسى وعيسى ومحمد عليهم الصلاة والسلام."),
        Q("الأنبياء","سهل","من خليل الله من الأنبياء؟",["إبراهيم عليه السلام","موسى عليه السلام","نوح عليه السلام","عيسى عليه السلام"],"قال تعالى: ﴿واتخذ الله إبراهيم خليلاً﴾."),

        Q("الفقه الأساسي","سهل","كم عدد الصلوات المفروضة في اليوم والليلة؟",["خمس","ثلاث","ست","سبع"],"الصلوات المفروضة خمس: الفجر والظهر والعصر والمغرب والعشاء."),
        Q("الفقه الأساسي","سهل","كم ركعة صلاة الفجر؟",["ركعتان","ثلاث","أربع","ركعة"],"صلاة الفجر ركعتان جهرية."),
        Q("الفقه الأساسي","متوسط","أي صلاة ليس فيها ركوع ولا سجود؟",["صلاة الجنازة","صلاة الوتر","صلاة الكسوف","صلاة العيد"],"صلاة الجنازة قيام وتكبيرات ودعاء وتسليم."),
        Q("الفقه الأساسي","متوسط","ما ركن الحج الأعظم الذي قال فيه النبي ﷺ «الحج عرفة»؟",["الوقوف بعرفة","الطواف","رمي الجمرات","الحلق"],"من فاته الوقوف بعرفة فاته الحج."),
        Q("الفقه الأساسي","متوسط","ما الأيام البيض التي يُستحب صيامها؟",["13 و14 و15 من الشهر الهجري","1 و2 و3","27 و28 و29","20 و21 و22"],"يُستحب صيام ثلاثة أيام من كل شهر، وأفضلها الأيام البيض."),
        Q("الفقه الأساسي","سهل","ما اسم الحجر الذي يُستلم ويُقبّل عند الطواف؟",["الحجر الأسود","حجر إسماعيل","المقام","الملتزم"],"يبدأ الطواف من الحجر الأسود وينتهي عنده."),
        Q("الفقه الأساسي","سهل","ما أول بيت وُضع للناس للعبادة؟",["الكعبة المشرفة","المسجد الأقصى","مسجد قباء","المسجد النبوي"],"قال تعالى: ﴿إن أول بيت وضع للناس للذي ببكة مباركاً﴾."),

        Q("الأخلاق الإسلامية","سهل","أكمل الحديث: «إنما الأعمال بـ...»",["النيات","الأقوال","الأفعال","الأسباب"],"هذا الحديث أصل عظيم في وجوب إخلاص النية لله."),
        Q("الأخلاق الإسلامية","سهل","أكمل: «من كان يؤمن بالله واليوم الآخر فليقل خيراً أو...»",["ليصمت","ليتكلم","ليبتسم","ليسكت عن الجميع"],"الحديث متفق عليه، وفيه حفظ اللسان."),
        Q("الأخلاق الإسلامية","سهل","أكمل: «أحب الأعمال إلى الله أدومها وإن...»",["قلّ","كثر","سهل","صعب"],"الاستمرار على القليل خير من الانقطاع عن الكثير."),
        Q("الأخلاق الإسلامية","متوسط","أكمل: «الطُّهور شطر...»",["الإيمان","الصلاة","الدين","الصيام"],"رواه مسلم، وفيه فضل الطهارة."),
        Q("الأخلاق الإسلامية","سهل","أكمل: «لا يؤمن أحدكم حتى يحب لأخيه ما يحب لـ...»",["نفسه","أهله","ماله","بيته"],"حديث متفق عليه في أخوة الإيمان."),
        Q("الأخلاق الإسلامية","متوسط","أكمل: «الدِّين...»",["النصيحة","الصلاة","الصدق","العمل"],"قال ﷺ: الدين النصيحة، لله ولكتابه ولرسوله ولأئمة المسلمين وعامتهم."),

        Q("رمضان والحج","سهل","الليلة التي هي خير من ألف شهر هي:",["ليلة القدر","ليلة النصف من شعبان","ليلة الإسراء","ليلة العيد"],"قال تعالى: ﴿ليلة القدر خير من ألف شهر﴾."),
        Q("رمضان والحج","متوسط","في أي شهر هجري وقعت غزوة بدر؟",["رمضان","شوال","رجب","محرم"],"وقعت بدر في 17 رمضان سنة 2 هـ."),
        Q("رمضان والحج","متوسط","ما اسم أول مسجد بُني في الإسلام؟",["مسجد قباء","المسجد النبوي","المسجد الحرام","مسجد القبلتين"],"أسّسه النبي ﷺ في قباء عند وصوله إلى المدينة مهاجراً."),
        Q("رمضان والحج","سهل","ما اسم البئر المباركة قرب الكعبة؟",["زمزم","بئر رومة","بئر بضاعة","بئر حراء"],"نبعت زمزم لهاجر وإسماعيل عليهما السلام."),
        Q("رمضان والحج","متوسط","كم سنة عاش النبي ﷺ في المدينة بعد الهجرة؟",["10 سنوات","5 سنوات","13 سنة","8 سنوات"],"أقام في المدينة عشر سنوات حتى وفاته ﷺ.")
    ];
    // أسئلة أضافها المطوّر من «وضع المطوّر ← أسئلة» (الإجابة الصحيحة أولاً ويُعاد خلط الخيارات وقت العرض)
    const DEV_BANK = (() => {
        try {
            if (localStorage.getItem('ikh-dev-off') === '1') return [];
            const d = JSON.parse(localStorage.getItem('ikh-dev-data') || '{}');
            return (Array.isArray(d.qj) ? d.qj : [])
                .filter(q => q && q.text && Array.isArray(q.options) && q.options.length >= 3 && q.options.length <= 6)
                .map(q => ({ cat: String(q.cat || 'أسئلة المطوّر'), diff: ['سهل', 'متوسط', 'صعب'].includes(q.diff) ? q.diff : 'متوسط',
                    text: String(q.text), options: q.options.map(String), correct: 0, explanation: String(q.explanation || '') }));
        } catch (e) { return []; }
    })();
    const QUESTION_BANK = BASE_BANK.concat(NEW_BANK, DEV_BANK);


    // 4. حالة اللعبة
    const todayKey = () => new Date().toLocaleDateString('en-CA');
    const defState = () => ({ points: 0, streak: 0, highestStreak: 0, currentStageId: 1, unlockedAchievements: [],
        seen: [], wrong: [], answered: 0, correct: 0, daily: { date: '', answered: 0, done: false, skips: 0, hints: 0 } });
    let GameState = defState();
    let currentQuestion = null, currentOpts = [];
    let locked = false, hintUsed = false, selectedCat = 'all';
    let lastMsgIndex = -1, lastGain = 10;

    function ensureDaily() {
        if (!GameState.daily || GameState.daily.date !== todayKey())
            GameState.daily = { date: todayKey(), answered: 0, done: false, skips: 0, hints: 0 };
    }
    function loadGameState() {
        let saved = null;
        try { saved = JSON.parse(localStorage.getItem('IkhlasJourneyState_v2') || 'null'); } catch (e) {}
        GameState = Object.assign(defState(), saved || {});
        if (!Array.isArray(GameState.unlockedAchievements)) GameState.unlockedAchievements = [];
        ensureDaily();
        // تحميل صامت (Silent Load) لمنع ظهور الاحتفال في واجهات أخرى
        updateStageBasedOnPoints(true);
    }
    function saveGameState() {
        try { localStorage.setItem('IkhlasJourneyState_v2', JSON.stringify(GameState)); } catch (e) {}
    }
    function updateStageBasedOnPoints(isSilentLoad = false) {
        let newStage = 1;
        for (let i = 0; i < STAGES.length; i++) {
            if (GameState.points >= STAGES[i].pointsReq) newStage = STAGES[i].id;
        }
        if (newStage !== GameState.currentStageId) {
            const up = newStage > GameState.currentStageId;
            GameState.currentStageId = newStage;
            if (up && !isSilentLoad) showLevelUpCelebration(STAGES[newStage - 1]);
        }
    }
    function checkAchievements() {
        ACHIEVEMENTS_DB.forEach(ach => {
            if (GameState.unlockedAchievements.includes(ach.id)) return;
            let ok = false;
            if (ach.type === "points") ok = GameState.points >= ach.target;
            if (ach.type === "streak") ok = GameState.streak >= ach.target;
            if (ach.type === "answered") ok = GameState.answered >= ach.target;
            if (ach.type === "daily") ok = GameState.daily.done;
            if (ok) {
                GameState.unlockedAchievements.push(ach.id);
                showAchievementPopup(ach);
                renderAchievementsUI();
            }
        });
    }

    // 5. حقن الأنماط (CSS)
    function injectStyles() {
        if (document.getElementById('journey-css-v2')) return;
        const style = document.createElement('style');
        style.id = 'journey-css-v2';
        style.innerHTML = `
            /* تحسينات الواجهة العلوية */
            .journey-header { display: flex; justify-content: space-between; align-items: center; padding: 20px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; border-radius: 0 0 30px 30px; box-shadow: 0 10px 30px var(--theme-glow); position: relative; overflow: hidden; }
            .journey-header::after { content: ''; position: absolute; top: -50%; right: -20%; width: 200px; height: 200px; background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%); border-radius: 50%; }
            .journey-stats { display: flex; gap: 10px; z-index: 2; }
            .stat-pill { background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); padding: 8px 12px; border-radius: 20px; font-weight: 800; font-size: 0.9rem; display: flex; align-items: center; gap: 5px; box-shadow: inset 0 1px 2px rgba(255,255,255,0.3); transition: transform 0.3s; }
            .stat-pill.animate-pop { transform: scale(1.2); background: rgba(253, 224, 71, 0.4); }
            
            /* خريطة المراحل */
            .map-container { display: flex; overflow-x: auto; gap: 15px; padding: 20px; scroll-snap-type: x mandatory; scrollbar-width: none; }
            .map-container::-webkit-scrollbar { display: none; }
            .stage-node { scroll-snap-align: center; flex: 0 0 100px; display: flex; flex-direction: column; align-items: center; gap: 8px; opacity: 0.4; filter: grayscale(1); transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); position: relative; }
            .stage-node::after { content: ''; position: absolute; top: 30px; left: -25px; width: 35px; height: 3px; background: var(--glass-border); z-index: -1; }
            .stage-node:first-child::after { display: none; }
            .stage-icon { width: 60px; height: 60px; border-radius: 50%; background: var(--glass-bg); border: 2px solid var(--glass-border); display: flex; align-items: center; justify-content: center; font-size: 1.8rem; box-shadow: var(--shadow-glass); transition: all 0.5s; }
            .stage-name { font-size: 0.75rem; font-weight: 800; color: var(--text-main); text-align: center; }
            
            .stage-node.unlocked { opacity: 1; filter: none; }
            .stage-node.unlocked::after { background: var(--primary); box-shadow: 0 0 10px var(--theme-glow); }
            .stage-node.unlocked .stage-icon { border-color: var(--primary); }
            .stage-node.current { transform: scale(1.15); opacity: 1; filter: none; }
            .stage-node.current .stage-icon { background: linear-gradient(135deg, var(--accent), #fde047); border-color: white; box-shadow: 0 0 25px rgba(253, 224, 71, 0.6); animation: pulse-node 2s infinite alternate; }
            @keyframes pulse-node { to { transform: scale(1.05); } }

            /* شريط التقدم */
            .journey-progress-wrapper { padding: 0 20px; margin-bottom: 15px; }
            .journey-progress-bar { width: 100%; height: 12px; background: rgba(128,128,128,0.2); border-radius: 10px; overflow: hidden; position: relative; box-shadow: inset 0 2px 5px rgba(0,0,0,0.1); }
            .journey-progress-fill { height: 100%; background: linear-gradient(90deg, var(--primary), var(--accent), #fde047); background-size: 200% 100%; width: 0%; transition: width 0.8s cubic-bezier(0.16, 1, 0.3, 1); animation: gradientMove 3s infinite linear; position: relative; }
            .journey-progress-fill::after { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(rgba(255,255,255,0.4), rgba(255,255,255,0)); }
            @keyframes gradientMove { 0% { background-position: 100% 0; } 100% { background-position: -100% 0; } }

            /* قسم الإنجازات والأوسمة */
            .achievements-tray { display: flex; gap: 10px; padding: 0 20px 15px; overflow-x: auto; scrollbar-width: none; }
            .achievements-tray::-webkit-scrollbar { display: none; }
            .ach-badge { width: 45px; height: 45px; border-radius: 50%; background: var(--glass-bg-solid); border: 2px solid var(--accent); display: flex; align-items: center; justify-content: center; font-size: 1.3rem; box-shadow: 0 4px 10px rgba(217, 119, 6, 0.2); flex-shrink: 0; filter: grayscale(1); opacity: 0.5; position: relative; }
            .ach-badge.unlocked { filter: grayscale(0); opacity: 1; border-color: #fde047; box-shadow: 0 0 15px rgba(253, 224, 71, 0.5); background: linear-gradient(135deg, rgba(255,255,255,0.9), rgba(253, 224, 71, 0.2)); }
            .ach-badge.unlocked::before { content: '✨'; position: absolute; top: -5px; right: -5px; font-size: 0.6rem; animation: twinkle 1.5s infinite alternate; }

            /* بطاقة السؤال المتقدمة */
            .question-box { background: var(--glass-bg-solid); border: 1px solid var(--glass-border); border-radius: 25px; padding: 35px 20px 25px; margin: 0 20px 30px; box-shadow: var(--shadow-glass); text-align: center; position: relative; transition: all 0.3s; }
            .question-box.shake { animation: shakeError 0.4s cubic-bezier(0.36, 0.07, 0.19, 0.97) both; }
            .q-category-tag { position: absolute; top: -15px; left: 50%; transform: translateX(-50%); display: flex; gap: 5px; }
            .q-cat { background: var(--primary); color: white; padding: 5px 15px; border-radius: 15px; font-size: 0.8rem; font-weight: 800; box-shadow: 0 5px 15px var(--theme-glow); }
            .q-diff { background: var(--accent); color: white; padding: 5px 15px; border-radius: 15px; font-size: 0.8rem; font-weight: 800; }
            .q-text { font-family: var(--font-quran); font-size: 1.6rem; color: var(--text-main); margin: 15px 0 25px; line-height: 1.5; }
            
            /* الخيارات */
            .options-grid { display: grid; grid-template-columns: 1fr; gap: 12px; }
            .option-btn { background: var(--glass-bg); border: 2px solid var(--glass-border); color: var(--text-main); padding: 15px; border-radius: 16px; font-family: var(--font-ui); font-size: 1.05rem; font-weight: 700; cursor: pointer; transition: 0.3s; text-align: center; position: relative; overflow: hidden; }
            .option-btn:hover { border-color: var(--primary); background: rgba(13, 148, 136, 0.05); transform: translateY(-2px); }
            .option-btn.correct { background: #10b981 !important; border-color: #047857 !important; color: white !important; box-shadow: 0 0 20px rgba(16, 185, 129, 0.4); transform: scale(1.02); z-index: 2; }
            .option-btn.wrong { background: #ef4444 !important; border-color: #b91c1c !important; color: white !important; opacity: 0.8; }
            
            /* صندوق الشرح التعليمي */
            .explanation-box { display: none; margin-top: 15px; padding: 15px; background: rgba(16, 185, 129, 0.1); border: 1px dashed #10b981; border-radius: 15px; font-size: 0.9rem; color: var(--text-main); font-weight: bold; animation: viewFadeIn 0.4s ease; }
            .explanation-box.show { display: block; }
            .explanation-box.error { background: rgba(239, 68, 68, 0.1); border-color: #ef4444; }

            /* تأثيرات احترافية */
            .star-particle { position: absolute; width: 6px; height: 6px; background: #fde047; border-radius: 50%; pointer-events: none; z-index: 100; box-shadow: 0 0 8px #fde047; }
            @keyframes shakeError { 10%, 90% { transform: translate3d(-2px, 0, 0); } 20%, 80% { transform: translate3d(4px, 0, 0); } 30%, 50%, 70% { transform: translate3d(-6px, 0, 0); } 40%, 60% { transform: translate3d(6px, 0, 0); } }

            /* النوافذ المنبثقة (Toast & Modal) */
            .feedback-toast { position: fixed; bottom: -100px; left: 50%; transform: translateX(-50%); background: var(--glass-bg-solid); backdrop-filter: blur(20px); border: 2px solid; padding: 15px 25px; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.2); z-index: 10000; font-weight: 800; text-align: center; opacity: 0; transition: 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275); display: flex; align-items: center; gap: 10px; flex-direction: column; width: 85%; max-width: 350px; }
            .feedback-toast.show { bottom: 90px; opacity: 1; }
            .toast-header { display: flex; align-items: center; gap: 10px; font-size: 1.1rem; }
            .toast-body { font-size: 0.85rem; opacity: 0.9; line-height: 1.4; }

            .achievement-popup { position: fixed; top: -150px; left: 50%; transform: translateX(-50%); background: linear-gradient(135deg, #fbbf24, #d97706); color: white; padding: 15px 25px; border-radius: 25px; box-shadow: 0 10px 30px rgba(217, 119, 6, 0.4); z-index: 10010; display: flex; align-items: center; gap: 15px; transition: 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
            .achievement-popup.show { top: 30px; }
            
            /* شاشة الاحتفال بمرحلة جديدة */
            .level-up-screen { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.85); backdrop-filter: blur(15px); z-index: 10005; display: flex; flex-direction: column; align-items: center; justify-content: center; opacity: 0; pointer-events: none; transition: 0.5s; color: white; text-align: center; }
            .level-up-screen.active { opacity: 1; pointer-events: all; }
            .level-icon-huge { font-size: 6rem; filter: drop-shadow(0 0 30px var(--accent)); animation: popIn 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
            @keyframes popIn { 0% { transform: scale(0); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
        `;
        document.head.appendChild(style);
    }

    function injectStyles2() {
        if (document.getElementById('journey-css-v3')) return;
        const st = document.createElement('style');
        st.id = 'journey-css-v3';
        st.textContent = `
            .j-cats{display:flex;gap:8px;overflow-x:auto;padding:0 20px 12px;scrollbar-width:none}
            .j-cats::-webkit-scrollbar{display:none}
            .j-chip{flex:0 0 auto;padding:6px 14px;border-radius:16px;border:1px solid var(--glass-border);background:var(--glass-bg);color:var(--text-main);font:700 .78rem 'Tajawal',sans-serif;cursor:pointer}
            .j-chip.on{background:var(--primary);color:#fff;border-color:var(--primary)}
            .j-meta{display:flex;justify-content:space-between;gap:8px;padding:0 20px 12px;font-size:.78rem;font-weight:700;color:var(--text-muted);flex-wrap:wrap}
            .j-daily{height:6px;border-radius:6px;background:rgba(128,128,128,.2);margin:0 20px 12px;overflow:hidden}
            .j-daily i{display:block;height:100%;background:linear-gradient(90deg,#f59e0b,#fde047);transition:width .5s}
            .j-tools{display:flex;gap:10px;margin-top:14px}
            .j-tool{flex:1;padding:10px;border-radius:14px;border:1px dashed var(--glass-border);background:transparent;color:var(--text-main);font:700 .85rem 'Tajawal',sans-serif;cursor:pointer}
            .j-tool:disabled{opacity:.4}
            .j-next{display:none;width:100%;margin-top:14px;padding:14px;border:0;border-radius:16px;background:var(--primary);color:#fff;font:800 1rem 'Tajawal',sans-serif;cursor:pointer}
            .j-next.show{display:block}
            .option-btn.gone{display:none}
        `;
        document.head.appendChild(st);
    }

    // 6. حقن الواجهة (DOM Injection)
    function injectUI() {
        if (document.getElementById('view-journey')) {
            document.getElementById('view-journey').remove(); 
        }
        
        const journeyViewHTML = `
            <section id="view-journey" class="view-section">
                <div class="journey-header">
                    <div>
                        <h2 style="font-family:'Aref Ruqaa',serif; font-size:2.2rem; line-height:1; text-shadow:0 2px 10px rgba(0,0,0,0.2);">رحلة النور</h2>
                        <span style="font-size:0.85rem; opacity:0.9; font-weight:bold;">مغامرة المعرفة الإسلامية</span>
                    </div>
                    <div class="journey-stats">
                        <div class="stat-pill" id="pill-points"><span style="color:#fde047;">🏆</span> <span id="j-points">0</span></div>
                        <div class="stat-pill" id="pill-streak"><span style="color:#fde047;">🔥</span> <span id="j-streak">0</span></div>
                    </div>
                </div>

                <div class="map-container" id="j-map"></div>

                <div class="journey-progress-wrapper">
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem; font-weight:bold; color:var(--text-muted); margin-bottom:6px;">
                        <span>تقدمك نحو المحطة التالية</span>
                        <span id="j-progress-text">0%</span>
                    </div>
                    <div class="journey-progress-bar">
                        <div class="journey-progress-fill" id="j-progress-fill"></div>
                    </div>
                </div>

                <div class="j-meta" id="j-meta"></div><div class="j-daily"><i id="j-daily-fill"></i></div>
                <div class="achievements-tray" id="j-achievements-tray"></div>
                <div class="j-cats" id="j-cats"></div>

                <div class="question-box" id="j-question-box">
                    <div class="q-category-tag">
                        <div class="q-cat" id="j-q-category">القسم</div>
                        <div class="q-diff" id="j-q-diff">المستوى</div>
                    </div>
                    <h3 class="q-text" id="j-q-text">جاري تحضير السؤال...</h3>
                    <div class="options-grid" id="j-options"></div>
                    <div class="explanation-box" id="j-explanation"></div>
                    <div class="j-tools">
                        <button class="j-tool" id="j-hint" onclick="window.journeyHint()">💡 حذف خيارين</button>
                        <button class="j-tool" id="j-skip" onclick="window.journeySkip()">⏭ تخطي</button>
                    </div>
                    <button class="j-next" id="j-next" onclick="window.journeyNext()">السؤال التالي ◀</button>
                </div>
            </section>
        `;
        
        const appContainer = document.querySelector('.app-container');
        appContainer.insertAdjacentHTML('beforeend', journeyViewHTML);

        if (!document.getElementById('journey-entry-card')) {
            const homeSection = document.getElementById('view-home');
            if (homeSection) {
                const entryCardHTML = `
                    <div id="journey-entry-card" class="card ripple-effect" onclick="window.switchView('journey')" style="background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; border: none; padding: 25px; margin-bottom: 20px; cursor: pointer; position: relative; overflow: hidden; box-shadow: 0 10px 30px var(--theme-glow);">
                        <div style="position: absolute; right: -20px; bottom: -30px; font-size: 8rem; opacity: 0.15; transform: rotate(-15deg);">🕌</div>
                        <h3 style="font-family:'Aref Ruqaa',serif; font-size:2rem; margin-bottom:5px;">رحلة النور ✨</h3>
                        <p style="font-size:0.9rem; opacity:0.9; max-width:80%;">العب، تعلم، وارتقِ في محطات المعرفة الإسلامية الممتعة يومياً.</p>
                        <div style="margin-top: 15px; display: inline-flex; background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; font-weight:bold; font-size:0.8rem; backdrop-filter:blur(5px);">
                            استكمل رحلتك <svg class="ic" aria-hidden="true"><use href="#ic-chevleft"/></svg>
                        </div>
                    </div>
                `;
                const aiWirdCard = document.getElementById('smart-ai-wird-card');
                if (aiWirdCard) aiWirdCard.insertAdjacentHTML('afterend', entryCardHTML);
                else homeSection.insertAdjacentHTML('afterbegin', entryCardHTML);
            }
        }

        if (!document.getElementById('j-levelup-screen')) {
            const levelUpHTML = `
                <div class="level-up-screen" id="j-levelup-screen">
                    <div class="level-icon-huge" id="lvl-icon">🕌</div>
                    <h2 style="font-family:'Aref Ruqaa',serif; font-size:3rem; margin:20px 0 10px; color:var(--accent);">مبارك!</h2>
                    <p style="font-size:1.2rem; margin-bottom:30px;">لقد وصلت إلى محطة</p>
                    <div style="background:white; color:var(--primary-dark); padding:10px 30px; border-radius:30px; font-weight:900; font-size:1.5rem;" id="lvl-name">اسم المحطة</div>
                    <button class="btn-primary" style="margin-top:40px; background:var(--accent); color:white; border:none; padding:15px 40px; border-radius:20px; font-size:1.1rem; font-weight:bold;" onclick="document.getElementById('j-levelup-screen').classList.remove('active')">متابعة الرحلة</button>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', levelUpHTML);
        }

        if (!document.getElementById('j-toast')) {
            const toastHTML = `
                <div class="feedback-toast" id="j-toast">
                    <div class="toast-header"><span id="j-toast-icon"></span> <span id="j-toast-title"></span></div>
                    <div class="toast-body" id="j-toast-msg"></div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', toastHTML);
        }

        if (!document.getElementById('j-ach-popup')) {
            const achPopupHTML = `
                <div class="achievement-popup" id="j-ach-popup">
                    <div style="font-size:2rem;" id="j-ach-icon">🏆</div>
                    <div>
                        <div style="font-size:0.75rem; font-weight:bold; opacity:0.9;">تم فتح إنجاز جديد!</div>
                        <div style="font-size:1.1rem; font-weight:900;" id="j-ach-title">اسم الإنجاز</div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', achPopupHTML);
        }
    }

    // 7. منطق الواجهة والرسم
    function renderMap() {
        const mapEl = document.getElementById('j-map');
        if (!mapEl) return;
        
        mapEl.innerHTML = STAGES.map(s => {
            const isUnlocked = GameState.points >= s.pointsReq;
            const isCurrent = s.id === GameState.currentStageId;
            return `
                <div class="stage-node ${isUnlocked ? 'unlocked' : ''} ${isCurrent ? 'current' : ''}" id="stage-${s.id}">
                    <div class="stage-icon">${s.icon}</div>
                    <div class="stage-name">${s.name}</div>
                </div>
            `;
        }).join('');

        setTimeout(() => {
            const currentEl = document.getElementById(`stage-${GameState.currentStageId}`);
            if (currentEl) currentEl.scrollIntoView({ behavior: 'smooth', inline: 'center' });
        }, 300);
    }

    function renderAchievementsUI() {
        const tray = document.getElementById('j-achievements-tray');
        if (!tray) return;
        
        tray.innerHTML = ACHIEVEMENTS_DB.map(ach => {
            const isUnlocked = GameState.unlockedAchievements.includes(ach.id);
            return `<div class="ach-badge ${isUnlocked ? 'unlocked' : ''}" title="${ach.title}\n${ach.desc}">${ach.icon}</div>`;
        }).join('');
    }

    function accuracy() { return GameState.answered ? Math.round(GameState.correct / GameState.answered * 100) : 0; }
    function updateStatsUI() {
        document.getElementById('j-points').innerText = GameState.points;
        document.getElementById('j-streak').innerText = GameState.streak;

        let nextStage = STAGES.find(s => s.id === GameState.currentStageId + 1);
        if (!nextStage) nextStage = STAGES[STAGES.length - 1];
        const currentStage = STAGES[GameState.currentStageId - 1];
        const pointsNeeded = nextStage.pointsReq - currentStage.pointsReq;
        const gained = GameState.points - currentStage.pointsReq;
        let percentage = 100;
        if (pointsNeeded > 0) percentage = Math.min(100, Math.max(0, gained / pointsNeeded * 100));
        document.getElementById('j-progress-fill').style.width = `${percentage}%`;
        document.getElementById('j-progress-text').innerText = `${Math.floor(percentage)}%`;

        ensureDaily();
        const d = Math.min(GameState.daily.answered, DAILY_GOAL);
        const meta = document.getElementById('j-meta');
        if (meta) meta.innerHTML = `<span>🎯 هدف اليوم ${d}/${DAILY_GOAL}${GameState.daily.done ? ' ✅' : ''}</span><span>✅ الدقة ${accuracy()}%</span><span>📚 ${GameState.answered} سؤالاً</span>`;
        const df = document.getElementById('j-daily-fill');
        if (df) df.style.width = (d / DAILY_GOAL * 100) + '%';
        const hb = document.getElementById('j-hint'), sb = document.getElementById('j-skip');
        if (hb) hb.textContent = `💡 حذف خيارين (−${HINT_COST}) · ${Math.max(0, 3 - GameState.daily.hints)}`;
        if (sb) sb.textContent = `⏭ تخطي · ${Math.max(0, 3 - GameState.daily.skips)}`;
    }

    function renderCats() {
        const el = document.getElementById('j-cats');
        if (!el) return;
        const cats = ['all'].concat([...new Set(QUESTION_BANK.map(q => q.cat))]);
        el.innerHTML = '';
        cats.forEach(c => {
            const b = document.createElement('button');
            b.className = 'j-chip' + (c === selectedCat ? ' on' : '');
            b.textContent = c === 'all' ? 'الكل' : c;
            b.onclick = () => { if (locked) return; selectedCat = c; renderCats(); loadNextQuestion(); };
            el.appendChild(b);
        });
    }

    function pickQuestion() {
        let pool = QUESTION_BANK.filter(q => selectedCat === 'all' || q.cat === selectedCat);
        let fresh = pool.filter(q => !GameState.seen.includes(q.text));
        if (!fresh.length) { // انتهت الأسئلة: نبدأ دورة جديدة
            GameState.seen = GameState.seen.filter(t => !pool.some(q => q.text === t));
            fresh = pool;
        }
        // إعادة سؤال أخطأت فيه سابقاً بنسبة 25%
        const retry = pool.filter(q => GameState.wrong.includes(q.text));
        if (retry.length && Math.random() < 0.25) return retry[Math.floor(Math.random() * retry.length)];
        // الصعوبة تتدرج مع المحطة
        const st = GameState.currentStageId;
        const w = st <= 3 ? { "سهل": 6, "متوسط": 3, "صعب": 1 } : st <= 8 ? { "سهل": 3, "متوسط": 4, "صعب": 2 } : { "سهل": 1, "متوسط": 3, "صعب": 5 };
        const weights = fresh.map(q => w[q.diff] || 1);
        let r = Math.random() * weights.reduce((a, b) => a + b, 0);
        for (let i = 0; i < fresh.length; i++) { r -= weights[i]; if (r <= 0) return fresh[i]; }
        return fresh[fresh.length - 1];
    }

    function loadNextQuestion() {
        const exp = document.getElementById('j-explanation');
        exp.classList.remove('show', 'error');
        document.getElementById('j-next').classList.remove('show');
        locked = false; hintUsed = false;

        currentQuestion = pickQuestion();
        document.getElementById('j-q-category').innerText = currentQuestion.cat;
        document.getElementById('j-q-diff').innerText = currentQuestion.diff;
        document.getElementById('j-q-text').innerText = currentQuestion.text;

        currentOpts = currentQuestion.options.map((t, i) => ({ t, i }));
        for (let i = currentOpts.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [currentOpts[i], currentOpts[j]] = [currentOpts[j], currentOpts[i]]; }

        const box = document.getElementById('j-options');
        box.innerHTML = '';
        currentOpts.forEach(o => {
            const b = document.createElement('button');
            b.className = 'option-btn ripple-effect';
            b.textContent = o.t;
            b.dataset.i = o.i;
            b.onclick = () => window.submitJourneyAnswer(o.i, b);
            box.appendChild(b);
        });
        updateStatsUI();
    }

    function quickToast(icon, title, msg) {
        const t = document.getElementById('j-toast');
        document.getElementById('j-toast-icon').innerText = icon;
        document.getElementById('j-toast-title').innerText = title;
        document.getElementById('j-toast-msg').innerText = msg;
        t.style.borderColor = 'var(--accent)'; t.style.color = 'var(--accent)';
        t.classList.add('show');
        setTimeout(() => t.classList.remove('show'), 2500);
    }

    window.journeyHint = function () {
        if (locked || !currentQuestion) return;
        ensureDaily();
        if (hintUsed) return quickToast('💡', 'استخدمتها', 'حذفنا خيارين بالفعل لهذا السؤال.');
        if (GameState.daily.hints >= 3) return quickToast('💡', 'انتهت المحاولات', 'لديك 3 تلميحات يومياً.');
        if (currentOpts.length < 4) return quickToast('💡', 'غير متاح', 'التلميح للأسئلة ذات 4 خيارات.');
        hintUsed = true; GameState.daily.hints++;
        GameState.points = Math.max(0, GameState.points - HINT_COST);
        const wrong = [...document.querySelectorAll('#j-options .option-btn')].filter(b => +b.dataset.i !== currentQuestion.correct);
        wrong.sort(() => Math.random() - 0.5).slice(0, 2).forEach(b => b.classList.add('gone'));
        saveGameState(); updateStatsUI();
    };
    window.journeySkip = function () {
        if (locked || !currentQuestion) return;
        ensureDaily();
        if (GameState.daily.skips >= 3) return quickToast('⏭', 'انتهت المحاولات', 'لديك 3 تخطيات يومياً.');
        GameState.daily.skips++;
        if (!GameState.seen.includes(currentQuestion.text)) GameState.seen.push(currentQuestion.text);
        saveGameState(); loadNextQuestion();
    };
    window.journeyNext = function () { loadNextQuestion(); };

    // 8. محرك الإجابات والتأثيرات
    window.submitJourneyAnswer = function (selectedIndex, btnElement) {
        if (locked || !currentQuestion) return;
        locked = true;

        const isCorrect = selectedIndex === currentQuestion.correct;
        const allBtns = document.querySelectorAll('#j-options .option-btn');
        const qBox = document.getElementById('j-question-box');
        const expBox = document.getElementById('j-explanation');
        allBtns.forEach(b => { b.style.pointerEvents = 'none'; if (+b.dataset.i === currentQuestion.correct) b.classList.add('correct'); });

        ensureDaily();
        GameState.answered++; GameState.daily.answered++;
        if (!GameState.seen.includes(currentQuestion.text)) GameState.seen.push(currentQuestion.text);

        if (isCorrect) {
            if (navigator.vibrate) navigator.vibrate([30, 50, 30]);
            animatePill('pill-points'); animatePill('pill-streak');
            triggerStarExplosion(btnElement);

            const base = { "سهل": 10, "متوسط": 15, "صعب": 25 }[currentQuestion.diff] || 10;
            GameState.streak += 1;
            const bonus = GameState.streak >= 3 ? Math.min(20, (GameState.streak - 2) * 2) : 0;
            lastGain = (hintUsed ? Math.ceil(base / 2) : base) + bonus;
            GameState.points += lastGain;
            GameState.correct++;
            GameState.wrong = GameState.wrong.filter(t => t !== currentQuestion.text);
            if (GameState.streak > GameState.highestStreak) GameState.highestStreak = GameState.streak;
            showSmartPositiveFeedback();
            expBox.innerText = "💡 " + (currentQuestion.explanation || "إجابة صحيحة");
            expBox.classList.add('show');
        } else {
            btnElement.classList.add('wrong');
            if (navigator.vibrate) navigator.vibrate(40);
            qBox.classList.add('shake');
            setTimeout(() => qBox.classList.remove('shake'), 400);
            GameState.streak = 0;
            if (!GameState.wrong.includes(currentQuestion.text)) GameState.wrong.push(currentQuestion.text);
            showSmartLearningFeedback();
            expBox.innerText = "📚 للتوضيح: " + (currentQuestion.explanation || "راجع المعلومة.");
            expBox.classList.add('error', 'show');
        }

        if (GameState.daily.answered >= DAILY_GOAL && !GameState.daily.done) {
            GameState.daily.done = true;
            GameState.points += DAILY_BONUS;
            setTimeout(() => quickToast('🎯', 'أتممت هدف اليوم!', `مكافأة +${DAILY_BONUS} نقطة نورانية.`), 2700);
        }

        saveGameState();
        updateStatsUI();
        updateStageBasedOnPoints(false);
        renderMap();
        checkAchievements();
        document.getElementById('j-next').classList.add('show');
    };


    // 9. التأثيرات البصرية
    function triggerStarExplosion(element) {
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;

        for (let i = 0; i < 15; i++) {
            const star = document.createElement('div');
            star.className = 'star-particle';
            document.body.appendChild(star);

            const angle = Math.random() * Math.PI * 2;
            const velocity = 50 + Math.random() * 50;
            const tx = Math.cos(angle) * velocity;
            const ty = Math.sin(angle) * velocity;

            star.style.left = centerX + 'px';
            star.style.top = centerY + 'px';

            star.animate([
                { transform: 'translate(0, 0) scale(1)', opacity: 1 },
                { transform: `translate(${tx}px, ${ty}px) scale(0)`, opacity: 0 }
            ], { duration: 600 + Math.random() * 400, easing: 'cubic-bezier(0, .9, .57, 1)' });

            setTimeout(() => star.remove(), 1000);
        }
    }

    function animatePill(id) {
        const pill = document.getElementById(id);
        if(pill) {
            pill.classList.add('animate-pop');
            setTimeout(() => pill.classList.remove('animate-pop'), 300);
        }
    }

    // 10. نظام الرسائل
    function showSmartPositiveFeedback() {
        const toast = document.getElementById('j-toast');
        const icon = document.getElementById('j-toast-icon');
        const title = document.getElementById('j-toast-title');
        const msg = document.getElementById('j-toast-msg');
        
        toast.style.borderColor = '#10b981'; toast.style.color = '#047857';
        document.body.classList.contains('dark-mode') ? toast.style.color = '#34d399' : null;

        if (GameState.streak === 3) { icon.innerText = "🌟"; title.innerText = "رائع!"; msg.innerText = "أنت تتقدم بثبات، 3 إجابات صحيحة متتالية."; }
        else if (GameState.streak === 5) { icon.innerText = "✨"; title.innerText = "أحسنت!"; msg.innerText = "استمر فالمعرفة نور، 5 إجابات متتالية."; }
        else if (GameState.streak === 10) { icon.innerText = "🔥"; title.innerText = "عقل يقظ!"; msg.innerText = "أداء مذهل، وصلت لـ 10 إجابات متتالية."; }
        else if (GameState.streak === 20) { icon.innerText = "🌿"; title.innerText = "ما شاء الله!"; msg.innerText = "تركيزك ممتاز اليوم، 20 إجابة متتالية لا يخطئ فيها إلا قليل."; }
        else {
            const msgs = [
                { t: "إجابة موفقة!", m: `أضفت ${lastGain} نقطة لرصيدك النوراني.` },
                { t: "أحسنت صنعاً", m: "معلومة صحيحة تماماً." },
                { t: "بارك الله فيك", m: "إجابة دقيقة وفي محلها." },
                { t: "استمر", m: "أنت تبني حصيلة معرفية ممتازة." }
            ];
            let rand; do { rand = Math.floor(Math.random() * msgs.length); } while (rand === lastMsgIndex && msgs.length > 1);
            lastMsgIndex = rand;
            
            icon.innerText = "✅"; title.innerText = msgs[rand].t; msg.innerText = msgs[rand].m;
        }

        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2500);
    }

    function showSmartLearningFeedback() {
        const toast = document.getElementById('j-toast');
        const icon = document.getElementById('j-toast-icon');
        const title = document.getElementById('j-toast-title');
        const msg = document.getElementById('j-toast-msg');
        
        toast.style.borderColor = 'var(--accent)'; toast.style.color = 'var(--accent)';

        const msgs = [
            { t: "لا بأس", m: "راجع المعلومة وحاول مرة أخرى في المرات القادمة." },
            { t: "استفادة جديدة", m: "تعلم معلومة جديدة أفضل من عدم المحاولة." },
            { t: "كنت قريباً", m: "الخطأ هو طريقك الأكيد للتعلم المستدام." }
        ];
        
        let rand; do { rand = Math.floor(Math.random() * msgs.length); } while (rand === lastMsgIndex && msgs.length > 1);
        lastMsgIndex = rand;

        icon.innerText = "💡"; title.innerText = msgs[rand].t; msg.innerText = msgs[rand].m;

        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2500);
    }

    function showAchievementPopup(ach) {
        const popup = document.getElementById('j-ach-popup');
        document.getElementById('j-ach-icon').innerText = ach.icon;
        document.getElementById('j-ach-title').innerText = ach.title;
        
        if (navigator.vibrate) navigator.vibrate([100, 50, 100]);
        
        popup.classList.add('show');
        setTimeout(() => popup.classList.remove('show'), 4000);
    }

    function showLevelUpCelebration(stageObj) {
        if(window.navigator.vibrate) window.navigator.vibrate([100, 50, 100, 50, 200]);
        
        const el = document.getElementById('j-points');
        triggerStarExplosion(el);
        triggerStarExplosion(el);
        
        document.getElementById('lvl-icon').innerText = stageObj.icon;
        document.getElementById('lvl-name').innerText = stageObj.name;
        document.getElementById('j-levelup-screen').classList.add('active');
    }


    // 11. الإقلاع
    window.addEventListener('DOMContentLoaded', () => {
        try {
            injectStyles();
            injectStyles2();
            injectUI();
            loadGameState();
            renderMap();
            renderAchievementsUI();
            renderCats();
            loadNextQuestion();
            console.log("🕌 تم تشغيل محرك 'رحلة النور' المطور بنجاح تام.");
        } catch (e) {
            console.error("خطأ في تشغيل رحلة النور المطورة: ", e);
        }
    });

})();
