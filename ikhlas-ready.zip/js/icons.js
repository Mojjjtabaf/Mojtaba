/* نظام الأيقونات: يستبدل الإيموجي (الثابت والديناميكي) بأيقونات SVG احترافية */
(function(){
const P={
navhome:'<path d="M4 21v-8.5a8 8 0 0 1 16 0V21Z"/><path d="M12 4.5V2M9.5 21v-4a2.5 2.5 0 0 1 5 0v4"/>',
navtasbih:'<circle cx="12" cy="4.6" r="1.7"/><circle cx="17.4" cy="7" r="1.7"/><circle cx="19" cy="12.4" r="1.7"/><circle cx="16.4" cy="16.9" r="1.7"/><circle cx="7.6" cy="16.9" r="1.7"/><circle cx="5" cy="12.4" r="1.7"/><circle cx="6.6" cy="7" r="1.7"/><path d="M12 18.4V22"/>',
navsunnah:'<path d="M5 4.5A2.5 2.5 0 0 1 7.5 2H19v15H7.5A2.5 2.5 0 0 0 5 19.5V4.5Z"/><path d="M5 19.5A2.5 2.5 0 0 0 7.5 22H19v-5M10 7h5M10 11h5"/>',
leaf:'<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10Z"/><path d="M2 21c0-3 1.9-5.4 5.1-6.5C9.7 13.6 12 13 14 11"/>',
mosque:'<path d="M12 2c2 2 3 3.5 3 5a3 3 0 0 1-6 0c0-1.5 1-3 3-5Z"/><path d="M5 22V12l3-2M19 22V12l-3-2M3 22h18M9 22v-5a3 3 0 0 1 6 0v5"/>',
check:'<path d="M20 6 9 17l-5-5"/>',
volume:'<path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/>',
sparkle:'<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z"/><path d="M19 16v4M17 18h4"/>',
book:'<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2V4Z"/><path d="M22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7V4Z"/>',
heart:'<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7 7-7Z"/>',
hands:'<path d="M7 11V6a2 2 0 1 1 4 0v5M11 11V4a2 2 0 1 1 4 0v7M15 11V7a2 2 0 1 1 4 0v8a7 7 0 0 1-7 7h-1a7 7 0 0 1-6-3.5L3 14a2 2 0 0 1 3-2l1 1.5"/>',
beads:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/>',
mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4"/>',
flame:'<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.4-.5-2-1-3-1.1-2.1-.2-4 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.2.4-2.4 1-3 0 2.2 1.1 3 2.5 3Z"/>',
music:'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
phone:'<rect x="6" y="2" width="12" height="20" rx="2"/><path d="M11 18h2"/>',
gem:'<path d="M6 3h12l4 6-10 13L2 9l4-6Z"/><path d="M2 9h20M12 22 8 9l4-6 4 6-4 13"/>',
shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>',
moon:'<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
stars:'<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z"/>',
star:'<path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8-6.2-3.3L5.8 21 7 14.2 2 9.3l6.9-1L12 2Z"/>',
building:'<path d="M3 22h18M5 22V9l7-6 7 6v13M9 22v-6h6v6M9 12h.01M15 12h.01"/>',
news:'<path d="M4 22h14a2 2 0 0 0 2-2V4H8v16a2 2 0 0 1-4 0V8h4"/><path d="M12 8h4M12 12h4M12 16h4"/>',
calendar:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
search:'<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
compass:'<circle cx="12" cy="12" r="10"/><path d="m16.2 7.8-2.1 6.3-6.3 2.1 2.1-6.3 6.3-2.1Z"/>',
kaaba:'<path d="M12 2 3 6.5v11L12 22l9-4.5v-11L12 2Z"/><path d="M3 6.5 12 11l9-4.5M12 11v11M7 9.5v3"/>',
bulb:'<path d="M15 14c.2-1 .7-1.7 1.5-2.5A6 6 0 1 0 7.5 11.5c.8.8 1.3 1.5 1.5 2.5M9 18h6M10 22h4"/>',
timer:'<circle cx="12" cy="14" r="8"/><path d="M12 10v4l2 2M9 2h6"/>',
hourglass:'<path d="M5 22h14M5 2h14M17 22v-4.2a2 2 0 0 0-.6-1.4L12 12l-4.4 4.4a2 2 0 0 0-.6 1.4V22M7 2v4.2a2 2 0 0 0 .6 1.4L12 12l4.4-4.4A2 2 0 0 0 17 6.2V2"/>',
pause:'<rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>',
stop:'<rect x="5" y="5" width="14" height="14" rx="2"/>',
sunrise:'<path d="M12 2v6M4.9 10.9l1.4 1.4M2 18h2M20 18h2M17.7 12.3l1.4-1.4M22 22H2M8 6l4-4 4 4M16 18a4 4 0 0 0-8 0"/>',
sunset:'<path d="M12 10V2M4.9 10.9l1.4 1.4M2 18h2M20 18h2M17.7 12.3l1.4-1.4M22 22H2M16 6l-4 4-4-4M16 18a4 4 0 0 0-8 0"/>',
sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M6.3 17.7l-1.4 1.4M19.1 4.9l-1.4 1.4"/>',
home:'<path d="M3 10.5 12 3l9 7.5V21a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1V10.5Z"/>',
user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
clock:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
trophy:'<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6M18 9h1.5a2.5 2.5 0 0 0 0-5H18M4 22h16M10 14.7V17c0 .6-.5 1-1.2 1.2C7.8 18.7 7 20 7 22M14 14.7V17c0 .6.5 1 1.2 1.2 1 .5 1.8 1.8 1.8 3.8M18 2H6v7a6 6 0 0 0 12 0V2Z"/>',
pin:'<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
refresh:'<path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5"/>',
rocket:'<path d="M4.5 16.5c-1.5 1.3-2 5-2 5s3.7-.5 5-2c.7-.8.7-2.1-.1-2.9a2.2 2.2 0 0 0-2.9-.1ZM12 15l-3-3a22 22 0 0 1 2-3.9A12.9 12.9 0 0 1 22 2c0 2.7-.8 7.5-6 11a22 22 0 0 1-4 2Z"/>',
alert:'<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0ZM12 9v4M12 17h.01"/>',
door:'<path d="M14 2H6v20h12V6l-4-4ZM14 2v4h4M10 12h.01"/>',
crown:'<path d="m2 6 5 5 5-8 5 8 5-5-2 14H4L2 6Z"/>',
brain:'<path d="M9.5 2A3.5 3.5 0 0 0 6 5.5 3.5 3.5 0 0 0 4 9a3.5 3.5 0 0 0 1 6 3.5 3.5 0 0 0 4.5 5A2.5 2.5 0 0 0 12 19.5V4.5A2.5 2.5 0 0 0 9.5 2ZM14.5 2A3.5 3.5 0 0 1 18 5.5 3.5 3.5 0 0 1 20 9a3.5 3.5 0 0 1-1 6 3.5 3.5 0 0 1-4.5 5"/>',
lock:'<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
x:'<path d="M18 6 6 18M6 6l12 12"/>',
back:'<path d="m9 14-5-5 5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',
pen:'<path d="M17 3a2.8 2.8 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3Z"/>',
settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>',
laptop:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M2 20h20"/>',
sliders:'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
dot:'<circle cx="12" cy="12" r="5" fill="currentColor"/>',
eye:'<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
zap:'<path d="M13 2 3 14h9l-1 8 10-12h-9l1-8Z"/>',
radio:'<circle cx="12" cy="12" r="2"/><path d="M16.2 7.8a6 6 0 0 1 0 8.4M7.8 16.2a6 6 0 0 1 0-8.4M19.1 4.9a10 10 0 0 1 0 14.2M4.9 19.1a10 10 0 0 1 0-14.2"/>',
wrench:'<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.8-3.8a6 6 0 0 1-7.9 7.9l-6.9 6.9a2.1 2.1 0 0 1-3-3l6.9-6.9a6 6 0 0 1 7.9-7.9l-3.8 3.8Z"/>',
utensils:'<path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2M7 2v20M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/>',
car:'<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9L18 10l-2.7-3.6A2 2 0 0 0 13.7 5H8.3a2 2 0 0 0-1.6.9L4 10l-2.5 1.1C.7 11.3 0 12.1 0 13v3c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>',
globe:'<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20Z"/>',
key:'<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
bell:'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
mountain:'<path d="m8 3 4 8 5-5 5 15H2L8 3Z"/>',
waves:'<path d="M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/>',
flower:'<circle cx="12" cy="12" r="3"/><path d="M12 9a4.5 4.5 0 1 1 3.5 1.7M15 12a4.5 4.5 0 1 1-1.7 3.5M12 15a4.5 4.5 0 1 1-3.5-1.7M9 12a4.5 4.5 0 1 1 1.7-3.5"/>',
ban:'<circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/>',
chart:'<path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 5-6"/>',
target:'<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
party:'<path d="m4 20 3-11 8 8-11 3ZM14 4v2M20 10h2M18 6l1.5-1.5M15 10l1-1"/>',
clipboard:'<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>',
sword:'<path d="m14.5 17.5-8.5-8.5V3h6l8.5 8.5M13 19l6-6M16 16l4 4M19 21l2-2"/>',
tree:'<path d="M12 22v-6M12 16a5 5 0 0 1-5-5c-2 0-3-2-3-4a4 4 0 0 1 5-3.8A4.5 4.5 0 0 1 19 7a4 4 0 0 1 1 4 5 5 0 0 1-8 5Z"/>',
scroll:'<path d="M8 21h12a2 2 0 0 0 2-2v-2H10v2a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v3h4M19 17V5a2 2 0 0 0-2-2H4"/>',
bird:'<path d="M16 7h.01M3.4 18H12a8 8 0 0 0 8-8V7a4 4 0 0 0-7.3-2.3L3 18M20 7l2 .5-2 .5M10 18v3M14 17.8V21"/>',
map:'<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3V6ZM9 3v15M15 6v15"/>',
play:'<path d="M6 4v16l14-8L6 4Z"/>',
skipnext:'<path d="M5 4v16l10-8L5 4Z"/><path d="M19 5v14"/>',
skipprev:'<path d="M19 4v16L9 12l10-8Z"/><path d="M5 5v14"/>',
repeat:'<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
palette:'<circle cx="13.5" cy="6.5" r=".8"/><circle cx="17.5" cy="10.5" r=".8"/><circle cx="8.5" cy="7.5" r=".8"/><circle cx="6.5" cy="12.5" r=".8"/><path d="M12 2a10 10 0 0 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1.1.9-2 2-2H18a4 4 0 0 0 4-4c0-5-4.5-9-10-9Z"/>',
calc:'<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 19h.01M12 19h4"/>',
gift:'<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5C11 3 12 8 12 8s1-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
graduation:'<path d="M22 10 12 5 2 10l10 5 10-5Z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/><path d="M22 10v6"/>',
save:'<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
chevup:'<path d="m18 15-6-6-6 6"/>',
chevdown:'<path d="m6 9 6 6 6-6"/>',
chevleft:'<path d="m15 18-6-6 6-6"/>',
chevright:'<path d="m9 18 6-6-6-6"/>',
arrowr:'<path d="M5 12h14M13 6l6 6-6 6"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
ship:'<path d="M12 3v12"/><path d="M12 4 5 13h7"/><path d="m12 6 6 8h-6"/><path d="M3 18h18l-2 3H5l-2-3Z"/>',
flag:'<path d="M4 22V4M4 4h13l-2 4 2 4H4"/>',
scale:'<path d="M12 3v18M6 21h12M5 7h14"/><path d="m5 7-3 7a3 3 0 0 0 6 0L5 7ZM19 7l-3 7a3 3 0 0 0 6 0l-3-7Z"/>',
flask:'<path d="M9 2h6M10 2v6L4.5 19a2 2 0 0 0 1.8 3h11.4a2 2 0 0 0 1.8-3L14 8V2M7 15h10"/>',
castle:'<path d="M3 22h18M5 22V8h3v3h2V8h4v3h2V8h3v14M10 22v-4a2 2 0 0 1 4 0v4"/>',
ruler:'<path d="M3 17 17 3l4 4L7 21l-4-4Z"/><path d="m7.5 12.5 2 2M10.5 9.5l2 2M13.5 6.5l2 2"/>',
hash:'<path d="M4 9h16M4 15h16M10 3 8 21M16 3l-2 18"/>',
help:'<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01"/>',
upload:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
trash:'<path d="M3 6h18M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
bellOff:'<path d="M8.7 3A6 6 0 0 1 18 8c0 2.7.6 4.6 1.2 5.8M17 17H3s3-2 3-9c0-.5.1-1 .2-1.5M10.3 21a1.9 1.9 0 0 0 3.4 0M2 2l20 20"/>',
bookmark:'<path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16Z"/>',
cloudsun:'<path d="M12 2v2M4.9 4.9l1.4 1.4M20 12h2M19.1 4.9l-1.4 1.4"/><path d="M15.9 12.7a4 4 0 0 0-5.9-4.2"/><path d="M13 22H7a5 5 0 1 1 4.9-6H13a3 3 0 0 1 0 6Z"/>'
};
const M={'🌿':'leaf','🌱':'leaf','🌳':'tree','🌺':'flower','🌷':'flower','🕌':'mosque','✅':'check','✓':'check','🔊':'volume','✨':'sparkle','📖':'book','📚':'book','📑':'book','❤':'heart','💖':'heart','🤍':'heart','🤲':'hands','📿':'beads','🎙':'mic','🔥':'flame','🎵':'music','📱':'phone','💎':'gem','🛡':'shield','🌌':'stars','🌙':'moon','🌟':'star','⭐':'star','★':'star','🏛':'building','🏡':'home','🏠':'home','📰':'news','📅':'calendar','🔍':'search','🧭':'compass','🕋':'kaaba','💡':'bulb','⏱':'timer','⏳':'hourglass','⏸':'pause','⏹':'stop','🌅':'sunrise','🌄':'sunrise','🌇':'sunset','🌆':'sunset','☀':'sun','🌞':'sun','👤':'user','👨':'user','🕰':'clock','🏆':'trophy','📍':'pin','🔄':'refresh','🚀':'rocket','⚠':'alert','🚪':'door','👑':'crown','🧠':'brain','🔒':'lock','✖':'x','🔙':'back','✍':'pen','⚙':'settings','💻':'laptop','🎚':'sliders','🟢':'dot','👁':'eye','⚡':'zap','📡':'radio','🛠':'wrench','🍽':'utensils','🚗':'car','🌍':'globe','🔑':'key','🔔':'bell','⛰':'mountain','🏔':'mountain','🏞':'mountain','🌊':'waves','🛑':'ban','📊':'chart','🎯':'target','🎉':'party','📋':'clipboard','🪞':'sparkle','⚔':'sword','🦅':'bird','📜':'scroll','🗺':'map','🌤':'sun','▶':'play','▷':'play','◀':'chevleft','▲':'chevup','▼':'chevdown','⏭':'skipnext','⏮':'skipprev','🔁':'repeat','🎨':'palette','🧮':'calc','🎁':'gift','🎓':'graduation','💾':'save','➕':'plus','⛵':'ship','🪄':'sparkle','🐪':'map','🏹':'target','⛏':'wrench','🌾':'leaf','🚩':'flag','⚖':'scale','🏙':'building','⚗':'flask','🗡':'sword','🥁':'music','🏰':'castle','📐':'ruler','🩺':'heart','🔢':'hash','🔭':'eye','➡':'arrowr','🏅':'trophy','❌':'x','❔':'help','❓':'help','📝':'pen','📈':'chart','✔':'check','📤':'upload','📥':'download','🗑':'trash','↩':'back','📳':'phone','🔕':'bellOff','↺':'refresh','🔖':'bookmark'};
const RE=new RegExp('('+Object.keys(M).join('|')+')[\\uFE0E\\uFE0F]?','g');
const NS='http://www.w3.org/2000/svg';
/* ثنائي اللون: الأشكال المغلقة تُملأ بلون النص بشفافية خفيفة فتبدو الأيقونات متناسقة */
function duo(x){return x.replace(/<(circle|rect)\b(?![^>]*fill=)/g,'<$1 fill="currentColor" fill-opacity=".14"').replace(/<path d="([^"]*[Zz])"(?![^>]*fill=)/g,'<path d="$1" fill="currentColor" fill-opacity=".14"')}
function mount(){
  if(document.getElementById('ic-sprite'))return;
  const s=document.createElementNS(NS,'svg');s.id='ic-sprite';s.setAttribute('aria-hidden','true');s.style.cssText='position:absolute;width:0;height:0;overflow:hidden';
  s.innerHTML=Object.keys(P).map(k=>'<symbol id="ic-'+k+'" viewBox="0 0 24 24">'+duo(P[k])+'</symbol>').join('');
  document.body.prepend(s);
}
function svg(name){
  const e=document.createElementNS(NS,'svg');e.setAttribute('class','ic');e.setAttribute('aria-hidden','true');
  const u=document.createElementNS(NS,'use');u.setAttribute('href','#ic-'+name);e.appendChild(u);return e;
}
const ANY=/[\u{1F000}-\u{1FAFF}\u{2190}-\u{21FF}\u{2300}-\u{23FF}\u{2460}-\u{24FF}\u{25A0}-\u{25FF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\uFE0E\uFE0F]\s?/gu;
const HAS=/[\u{1F000}-\u{1FAFF}\u{2190}-\u{21FF}\u{2300}-\u{23FF}\u{2460}-\u{24FF}\u{25A0}-\u{25FF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}]/u;
/* حيث لا يمكن عرض SVG (قوائم منسدلة، placeholder، title، رسائل alert) تُحذف الرموز بدل تركها */
function strip(s){return String(s).replace(ANY,'').replace(/[ \t]{2,}/g,' ').trim();}
const ATTR=['placeholder','title','aria-label','alt'],PLAIN={TEXTAREA:1,OPTION:1,TITLE:1};
function cleanEl(e){ATTR.forEach(function(a){const v=e.getAttribute(a);if(v&&HAS.test(v))e.setAttribute(a,strip(v));});}
['alert','confirm','prompt'].forEach(function(k){const o=window[k];if(typeof o==='function')window[k]=function(m,d){return o.call(window,m==null?m:strip(m),d);};});
const SKIP={SCRIPT:1,STYLE:1,TEXTAREA:1,INPUT:1,OPTION:1,SVG:1,TITLE:1,CODE:1};
function walk(n){
  if(n.nodeType===3){
    const t=n.nodeValue;RE.lastIndex=0;if(!RE.test(t)&&!(n.parentNode&&PLAIN[n.parentNode.nodeName.toUpperCase()]&&HAS.test(t)))return;
    const p=n.parentNode;if(!p)return;
    if(PLAIN[p.nodeName.toUpperCase()]){n.nodeValue=strip(t);return;}
    if(SKIP[p.nodeName.toUpperCase()])return;
    const f=document.createDocumentFragment();let i=0,m;RE.lastIndex=0;
    while((m=RE.exec(t))){f.append(t.slice(i,m.index));f.append(svg(M[m[1]]));i=m.index+m[0].length;}
    f.append(t.slice(i));p.replaceChild(f,n);return;
  }
  if(n.nodeType!==1)return;
  cleanEl(n);
  if(SKIP[n.nodeName.toUpperCase()]&&!PLAIN[n.nodeName.toUpperCase()])return;
  Array.from(n.childNodes).forEach(walk);
}
function html(name){return '<svg class="ic" aria-hidden="true"><use href="#ic-'+name+'"/></svg>';}
window.Icons={svg:svg,html:html,strip:strip,names:Object.keys(P),iconize:walk};
function start(){
  mount();walk(document.body);
  let busy=false;
  new MutationObserver(function(ms){
    if(busy)return;busy=true;
    ms.forEach(function(r){r.addedNodes.forEach(walk);if(r.type==='characterData')walk(r.target);});
    busy=false;
  }).observe(document.body,{childList:true,subtree:true,characterData:true});
}
/* السكربت آخر الـ body: نبدّل فوراً حتى لا يلمح المستخدم الإيموجي قبل الأيقونة */
if(document.body)start();else document.addEventListener('DOMContentLoaded',start);
})();
