// 9. نظام تسجيل الأخطاء المؤقت الاستباقي الشامل لاعتراض أي استثناء فوراً ومنع توقف الـ JavaScript
    window.onerror = function(msg, src, line, col, err){
        console.error("خطأ تم التقاطه في تطبيق إخلاص: ", msg, "المصدر: ", src, "السطر: ", line, "العمود: ", col, err);
        return false;
    };

    // قاعدة البيانات الكلية والموسعة بشكل آمن وصارم (الأذكار والأوراد الـ 12 كاملة)
    const ADHKAR_DATA = {
        morning: [
            { id: "m1", text: "أعوذ بالله من الشيطان الرجيم: {اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ...} [آية الكرسي]", target: 1, info: "من قالها حين يصبح أجير من الجن حتى يمسي" },
            { id: "m2", text: "قراءة سورة الإخلاص، وسورة الفلق، وسورة الناس.", target: 3, info: "تكفيك من كل شيء حتى تمسي" },
            { id: "m3", text: "أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.", target: 1, info: "من أذكار الصباح المأثورة - رواه مسلم" },
            { id: "m4", text: "سيد الاستغفار: اللهم أنت ربي لا إله إلا أنت، خلقتني وأنا عبدك، وأنا على عهدك ووعدك ما استطعت، أعوذ بك من شر ما صنعت...", target: 1, info: "من قالها موقناً بها ومات من يومه دخل الجنة" },
            { id: "m5", text: "بسم الله الذي لا يضر مع اسمه شيء في الأرض ولا في السماء وهو السميع العليم.", target: 3, info: "لم يضره من الله شيء في ذلك اليوم" }
        ],
        evening: [
            { id: "e1", text: "أعوذ بالله من الشيطان الرجيم: {اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّوم...}", target: 1, info: "آية الكرسي - حفظ من الجن حتى يصبح" },
            { id: "e2", text: "قراءة سورة الإخلاص، وسورة الفلق، وسورة الناس.", target: 3, info: "تكفيك من كل شر حتى تصبح" },
            { id: "e3", text: "أمسينا وأمسى الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له...", target: 1, info: "رواه مسلم" },
            { id: "e4", text: "أعوذ بكلمات الله التامات من شر ما خلق.", target: 3, info: "لم تضره لدغة في تلك الليلة" }
        ],
        after_prayer: [
            { id: "p1", text: "أستغفر الله (ثلاثاً) .. اللهم أنت السلام ومنك السلام، تباركت يا ذا الجلال والإكرام", target: 1, info: "تقال مباشرة فور السلام من الفريضة" },
            { id: "p2", text: "سُبْحَانَ اللهِ (33) ، الحَمْدُ للهِ (33) ، اللهُ أَكْبَرُ (33)", target: 1, info: "ويختم المائة بـ لا إله إلا الله وحده لا شريك له..." }
        ],
        sleep: [
            { id: "s1", text: "قراءة آية الكرسي قبل النوم", target: 1, info: "لا يزال عليك من الله حافظ ولا يقربك شيطان" },
            { id: "s2", text: "باسمك ربي وضعت جنبي وبك أرفعه، إن أمسكت نفسي فارحمها، وإن أرسلتها فاحفظها...", target: 1, info: "متفق عليه" }
        ],
        protection: [
            { id: "pr1", text: "اللهم إني أعوذ بك من جهد البلاء، ودرك الشقاء، وسوء القضاء، وشماتة الأعداء.", target: 1, info: "حصن وقائي نبوي شامل - متفق عليه" }
        ],
        ruqyah: [
            { id: "rq1", text: "قراءة سورة الفاتحة بتدبر ويقين شفائي تام.", target: 7, info: "السبع المثاني وهي أعظم رقية للمريض" },
            { id: "rq2", text: "أذهب البأس رب الناس، واشف أنت الشافي، لا شفاء إلا شفاؤك، شفاءً لا يغادر سقماً.", target: 3, info: "رقية الرسول ﷺ لمداواة المرضى" }
        ],
        quranic: [
            { id: "qu1", text: "{رَبَّنَا تَقَبَّلْ مِنَّا ۖ إِنَّكَ أَنتَ السَّمِيعُ الْعَلِيمُ} [البقرة: 127]", target: 1, info: "أذكار القرآن الكريم الشريفة" },
            { id: "qu2", text: "{رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ} [البقرة: 201]", target: 1, info: "من أجمع دعوات القرآن الكريمة" }
        ],
        prophetic: [
            { id: "prp1", text: "يا حي يا قيوم برحمتك أستغيث، أصلح لي شأني كله ولا تكلني إلى نفسي طرفة عين.", target: 1, info: "وصية النبي ﷺ لفاطمة رضي الله عنها" },
            { id: "prp2", text: "اللهم إني أسألك العفو والعافية في الدنيا والآخرة، اللهم إني أسألك العفو والعافية في ديني ودنياي وأهلي ومالي...", target: 1, info: "كان النَّبِيُّ ﷺ لا يدع هؤلاء الدعوات حين يصبح ويمسي" }
        ],
        wakeup: [
            { id: "wk1", text: "الحمد لله الذي أحيانا بعد ما أماتنا وإليه النشور.", target: 1, info: "يقال فور الاستيقاظ المبارك من النوم" }
        ],
        travel: [
            { id: "tr1", text: "الله أكبر، الله أكبر، الله أكبر، سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ...", target: 1, info: "ذكر ودعاء السفر المأثور عن النبي ﷺ" }
        ],
        food: [
            { id: "fd1", text: "بسم الله (وإذا نسي في أوله فليقل: بسم الله في أوله وآخره).", target: 1, info: "من سُنن التسمية عند البدء في تناول الطعام" }
        ],
        occasions: [
            { id: "oc1", text: "الحمد لله الذي كفاني وآواني، وأطعمني وسقاني، والذي مَنّ عليّ فأفضل...", target: 1, info: "من أذكار المناسبات وحمد النعمة الباطنة والظاهرة" }
        ]
    };

    // موسوعة القصص والعبر التثقيفية الموثقة ومواقف السلف الصالح الشاملة
    const STORIES_DATA = [
        { title: "صبر وتضرع نبي الله أيوب عليه السلام", desc: "إن نبي الله أيوب عليه السلام عاش في نعيم وافر من المال والولد والصحة، فابتلاه الله عز وجل بذهاب ذلك كله. فقد أمواله وتوفي أولاده جميعاً، ثم ابتُلي في جسده بمرض شديد مكث فيه ثماني عشرة سنة، حتى جفاه القريب والبعيد ولم يبق معه إلا زوجته البارة الوفية التي كانت تخدم الناس لتطعمه. ورغم هذا البلاء العظيم، لم يفتر لسانه عن ذكر الله والثناء عليه. وعندما بلغ البلاء غايته، تضرع إلى ربه بأدب الأنبياء الشريف قائلاً: {أَنِّي مَسَّنِيَ الضُّرُّ وَأَنتَ أَرْحَمُ الرَّاحِمِينَ}. فجاء الاستجابة الإلهية الفورية: {فَاسْتَجَبْنَا لَهُ فَكَشَفْنَا مَا بِهِ مِن ضُرٍّ}، وأُمر أن يضرب الأرض برجله فنبعت عين ماء بارد، اغتسل منها فشُفي ظاهره، وشرب منها فشُفي باطنه، وعوضه الله عن كل ما فقد رحمةً وضياءً لكل صابر.", source: "القرآن الكريم وسير الأنبياء لابن كثير" },
        { title: "يقين نبي الله يوسف في غيابات الجب والتمكين", desc: "بدأت محنة نبي الله يوسف عليه السلام بحسد إخوته له وكيدهم به، حيث أخذوه وألقوه في قاع بئر عميقة (الجب) وهو طفل صغير لا يملك لنفسه نفعاً ولا ضراً. ولكن الرعاية الإلهية أوحت إليه في تلك الظلمات أن الفرج قادم. بيع يوسف بثمن بخس، ودخل دار العزيز، ثم واجه فتنة امرأة العزيز فآثر السجن على المعصية قائلاً: {السِّجْنُ أَحَبُّ إِلَيَّ مِمَّا يَدْعُونَنِي إِلَيْهِ}. لبث في السجن بضع سنين صابراً محتسباً يعلم الناس التوحيد، حتى أظهر الله براءته على رؤوس الأشهاد بفضل علمه بتأويل الرؤى، فخرج ليصبح عزيز مصر والمشرف الأول على خزائنها، وتأتي سجدة إخوته له في النهاية تحقيقاً لرؤياه القديمة، لتثبت القصة أن التدبير الإلهي للمؤمن أفضل من تدبيره لنفسه.", source: "سورة يوسف وتفسير القرطبي" },
        { title: "بذل وثبات الصديق أبي بكر رضي الله عنه", desc: "يُعد أبو بكر الصديق رضي الله عنه النموذج الأسمى في التصديق والبذل لدين الله. ففي غزوة تبوك، حث النبي ﷺ الصحابة على النفقة لتجهيز جيش العسرة، فجاء عمر بن الخطاب بنصف ماله وظن أنه سيسبق أبا بكر، ولكن الصديق جاء بكل ما يملك وبكل ماله ووضعه في حجر النبي ﷺ. فسأله الرسول الكريم: 'يا أبا بكر، ما أبقيت لأهلك؟' فقال بلسان اليقين: 'أبقيت لهم الله ورسوله'. ولم يقتصر فضله على المال، بل كان الصديق طوداً شامخاً بعد وفاة النبي ﷺ، حيث ثبت الأمة وواجه الفتن وحروب الردة بحزم وقوة أعادت للإسلام هيبته وحمت المدينة المنورة من الضياع والانهيار.", source: "السيرة النبوية لابن هشام" },
        { title: "عدل الفاروق عمر بن الخطاب وهيبته وزهده", desc: "كان عمر بن الخطاب رضي الله عنه مثالاً حياً للعدل والزهد والورع الإنساني. يروى أن رسولاً من ملك الروم جاء ليقابل أمير المؤمنين، وتوقع أن يجده في قصر منيع يحفه الحراس، فلما سأل عنه وجده نائماً تحت ظل شجرة على الأرض متوسداً بردته وبلا أي حراسة. فوقف رسول الروم مذهولاً وقال كلمته التي خلدها التاريخ: 'حكمت فعدلت فأمنت فنمت يا عمر'. كان الفاروق يخرج بالليل متخفياً (يعس) ليتفقد أحوال المسلمين بنفسه، وذات ليلة وجد امرأة وأطفالها يبكون وحولهم قدر فيه ماء حصى تعللهم به حتى يناموا من الجوع، فهرع عمر إلى بيت المال وحمل كيس الدقيق والزيت على ظهره ورفض أن يحمله خادمه عنه قائلاً: 'أأنت تحمل عني وزري يوم القيامة؟' وطبخ لهم بنفسه حتى شبعوا وصحوا.", source: "تاريخ الخلفاء للسيوطي" },
        { title: "أمانة وورع الخليفة الزاهد عمر بن عبد العزيز", desc: "دخل عمر بن عبد العزيز الخليفة الأموي الراشد ذات ليلة مكتبه الخاص ليفحص شؤون الرعية ومظالم المسلمين على ضوء شمعة مملوكة لبيت مال المسلمين. فجاءه أحد أصدقائه المقربين وبدأ يحدثه عن شأن خاص بأسرة عمر وأحوال أولاده، فما كان من الخليفة الورع إلا أن أطفأ الشمعة فوراً وأشعل سراجاً صغيراً خاصاً به من ماله الخاص. وعندما سُئل مذهولاً عن ذلك، أجاب بكل هدوء وتقوى: 'إن الشمعة الأولى كانت لمال المسلمين وكنت أسأل في مصالحهم، فلما صرت في حديثي الخاص معك أطفأتها حتى لا أحرق مال المسلمين في شأني الشخصي'.", source: "سير أعلام النبلاء للذهبي" }
    ];

    // موسوعة السنن المهجورة المأثورة والثابتة فقهياً عن الحبيب ﷺ
    const SUNNAH_DATA = [
        { title: "استعمال السواك الطبيعي المطهر", desc: "استعمال السواك عند الوضوء، ودبر كل صلاة، وعند الاستيقاظ من النوم لتطبيق السُنّة المطهّرة التي ترضي الرحمن وتطهر الفم.", source: "صحيح مسلم" },
        { title: "الاضطجاع على الشق الأيمن وتحصين النوم", desc: "الخلود إلى النوم على طهارة كاملة والاضطجاع الشامل على الشق الأيمن مع وضع كف اليد اليمنى تحت الخد الأيمن وقراءة المعوذات.", source: "رواه البخاري ومسلم" },
        { title: "صلاة ركعتي الضحى (صلاة الأوابين)", desc: "أداء صلاة الضحى ركعتين أو أربع ركعات حين ترمض الفصال، وهي تجزئ عن صدقة كل سلامى (مفصل) من عظام جسد الإنسان يومياً.", source: "صحيح مسلم" },
        { title: "سُنّة نفض الفراش قبل النوم والتسمية", desc: "إذا أوى أحدكم إلى فراشه فلينفض فراشه بداخله إزاره فإنه لا يدري ما خلفه عليه وليقل: باسمك ربي وضعت جنبي وبك أرفعه.", source: "صحيح البخاري" }
    ];

    // الأحاديث النبوية الشريفة المبوبة بدقة بالغة
    const MEGA_HADITH_DATA = [
        { 
            chapter: "الفصل ١: الإيمان والنية والتوحيد الخالص", 
            hadiths: [
                { topic: "الإخلاص وصحة النية", text: "إنَّما الأعْمَالُ بالنِّيَّاتِ، وإنَّما لِكُلِّ امْرِئٍ ما نَوَى، فمَن كَانَتْ هِجْرَتُهُ إلى اللَّهِ ورَسولِهِ، فهِجْرَتُهُ إلى اللَّهِ ورَسولِهِ...", source: "متفق عليه" },
                { topic: "عقوبة الرياء والسمعة", text: "مَنْ سَمَّعَ سَمَّعَ اللَّهُ بِهِ ، وَمَنْ يُرَائِي يُرَائِي اللَّهُ بِهِ. فصلاح القلوب أساس قبول العبادات.", source: "صحيح البخاري" },
                { topic: "فضل كلمة التوحيد الخالص", text: "من قال لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير في يوم مائة مرة كانت له عدل عشر رقاب وكتبت له مائة حسنة.", source: "متفق عليه" }
            ] 
        },
        { 
            chapter: "الفصل ٢: فضل العلم والقرآن والذكر الحكيم", 
            hadiths: [
                { topic: "الخيرية المطلقة وتلاوة القرآن", text: "خَيْرُكُمْ مَن تَعَلَّمَ القُرْآنَ وعَلَّمَهُ، وإن البيت الذي يقرأ فيه القرآن يتسع بأهله ويكثر خيره.", source: "رواه البخاري" },
                { topic: "منزلة الماهر بالقرآن العظيم", text: "الْمَاهِرُ بِالْقُرْآنِ مَعَ السَّفَرَةِ الْكِرَامِ الْبَرَرَةِ، وَالَّذِي يَقْرَأُ الْقُرْآنَ وَيَتَتَعْتَعُ فِيهِ وَهُوَ عَلَيْهِ شَاقٌّ لَهُ أَجْرَانِ.", source: "صحيح مسلم" },
                { topic: "فضل كثرة ذكر الله تعالى", text: "ألا أنبئكم بخير أعمالكم، وأزكاها عند مليككم، وأرفعها في درجاتكم... قالوا: بلى، قال: ذكر الله تعالى.", source: "رواه الترمذي بسند صحيح" }
            ] 
        }
    ];

    const KHATMAH_PLAN = [
        "الجزء ١: الفاتحة حتى البقرة ١٤١", "الجزء ٢: البقرة ١٤٢ إلى البقرة ٢٥٢", "الجزء ٣: البقرة ٢٥٣ إلى آل عمران ٩٢",
        "الجزء ٤: آل عمران ٩٣ إلى النساء ٢٣", "الجزء ٥: النساء ٢٤ إلى النساء ١٤٧", "الجزء ٦: النساء ١٤٨ إلى المائدة ٨١",
        "الجزء ٧: المائدة ٨٢ إلى الأنعام ١١٠", "الجزء ٨: الأنعام ١١١ إلى الأعراف ٨٧", "الجزء ٩: الأعراف ٨٨ إلى الأنفال ٤٠",
        "الجزء ١٠: الأنفال ٤١ إلى التوبة ٩٢", "الجزء ١١: التوبة ٩٣ إلى هود ٥", "الجزء ١٢: هود ٦ إلى يوسف ٥٢",
        "الجزء ١٣: يوسف ٥٣ إلى إبراهيم ٥٢", "الجزء ١٤: الحجر ١ إلى النحل ١٢٨", "الجزء ١٥: الإسراء ١ إلى الكهف ٧٤",
        "الجزء ١٦: الكهف ٧٥ إلى طه ١٣٥", "الجزء ١٧: الأنبياء ١ إلى الحج ٧٨", "الجزء ١٨: المؤمنون ١ إلى الفرقان ٢٠",
        "الجزء ١٩: الفرقان ٢١ إلى النمل ٥٥", "الجزء ٢٠: النمل ٥٦ إلى العنكبوت ٤٥", "الجزء ٢١: العنكبوت 46 إلى الأحزاب 30",
        "الجزء ٢٢: الأحزاب ٣١ إلى يس ٢٧", "الجزء ٢٣: يس ٢٨ إلى الزمر ٣١", "الجزء ٢٤: الزمر ٣٢ إلى فصلت ٤٦",
        "الجزء ٢٥: فصلت ٤٧ إلى الجاثية ٣٧", "الجزء ٢٦: الأحقاف ١ إلى الذاريات ٣٠", "الجزء ٢٧: الذاريات ٣١ إلى الحديد ٢٩",
        "الجزء ٢٨: المجادلة ١ إلى التحريم ١٢", "الجزء ٢٩: الملك ١ إلى المرسلات ٥٠", "الجزء ٣٠: النبأ ١ إلى الناس ٦"
    ];

    // مصفوفة الـ 50 دعاء لبر الوالدين المستدعاة عشوائياً عند رغبة الخروج
    const PARENT_DUAS = [
        "رب اغفر لي ولوالدي وارحمهما كما ربياني صغيراً.",
        "اللهم اجعل والديّ من السعداء في الدارين ولا تحرمهما شفاعة الحبيب المصطفى.",
        "اللهم ارحم والدّي واغفر لهما وتجاوز عن سيئاتهما وأسكنهما فسيح جناتك.",
        "اللهم ارزق والديّ الصحة والعافية وطول العمر في طاعتك ورضاك.",
        "اللهم اغفر لوالديّ المطور مجتبى صديق ولوالديهما ولكل من عاون المؤمنين.",
        "اللهم يا باسط اليدين بالعطايا، ارزق والديّ عيشاً قاراً، ورزقاً داراً، وعملاً باراً.",
        "اللهم ارحمهما فوق الأرض، وتحت الأرض، ويوم العرض عليك.",
        "اللهم عافهما في أبدانهما وأسماعهما وأبصارهما وألبسهما ثوب التقوى.",
        "اللهم اجعل أوقاتهما بذكرك معمورة، وسعادتها في تقواك موصولة.",
        "اللهم ارزقني برهما طاعةً وحباً وإحساناً طوال حياتهما وبعد مماتهما.",
        "اللهم تقبل من والديّ صالح الأعمال واغسل خطيئاتهما بالماء والثلج والبرد.",
        "اللهم لا تجعل لوالديّ حاجة عند أحد من خلقك وأغنهما بفضلك عمن سواك.",
        "اللهم اجعل أمي ممن تقول لها النار اعبري فإن نوركِ أطفأ لهبي وتقول لها الجنة أقبلي.",
        "اللهم احفظ أبي بحفظك الشامل واكفّه نوائب الدهر وشرور خلقك.",
        "اللهم شفّع في والديّ الصيام والقيام والقرآن الكريم يوم القيامة.",
        "اللهم اكتب لوالديّ براءة من النار وأماناً من العذاب العظيم.",
        "اللهم ارفع درجات والديّ في عليين مع النبيين والصديقين والشهداء والصالحين.",
        "اللهم ارزق والدي` الفردوس الأعلى بلا حساب ولا سابقة عذاب.",
        "اللهم اجعل والديّ مستجابين الدعوة ممتلئين نوراً وإيماناً تاما.",
        "اللهم أسعد قلوب والديّ واصرف عنهما كل كرب وهمّ وحزن.",
        "اللهم إنك عفو كريم تحب العفو فاعف عن والديّ واغفر لهما.",
        "اللهم رضّ والديّ عليّ واجعلني قرة عين لهما في الدنيا والآخرة.",
        "اللهم احشر والديّ مع زمرة المتقين الأبرار تحت ظل عرشك الكريم.",
        "اللهم بارك في عمر أمي وفي صحة أبي واحفظهما من كل سوء مكروه.",
        "اللهم ارزق والديّ الجنة وما قرب إليها من قول أو عمل.",
        "اللهم نجّ والديّ من كربات يوم القيامة وثبت أقدامهما على الصراط.",
        "اللهم أسقِ والديّ من حوض نبيك الكريم شربةً هنيئةً لا يظمآن بعدها أبداً.",
        "اللهم اجعل أمي سيدة من سيدات أهل الجنة وأبي من الوجهاء المقربين.",
        "اللهم أصلح شأن والديّ كله ولا تكلهم لغيرك طرفة عين.",
        "اللهم يا غفار الذنوب اغفر لوالديّ ما تقدم من ذنبهما وما تأخر.",
        "اللهم صبّ الخير والبركة على والديّ صباً صباً ولا تجعل عيشهما كداً.",
        "اللهم اجعل ذكر والديّ مباركاً وعملهما خالصاً لوجهك الكريم.",
        "اللهم لا تجعل والدّي يشتكيان وجعاً ولا حزناً إلا وفرجته عنهما.",
        "اللهم اجعلنا مطيعين لوالدينا بارّين بهم مخلصين لهما في السر والعلن.",
        "اللهم تقبل دعاء والديّ لنا واجعله حجاباً لنا من النار.",
        "اللهم يسر لوالديّ كل عسير وافتح لهما أبواب رحمتك الواسعة.",
        "اللهم نوّر قبر من رحل من والدينا واجعله روضة من رياض الجنة.",
        "اللهم آنس وحشة من فارقنا من الآباء والأمهات وضاعف حسناتهم.",
        "اللهم اجمعنا بوالدينا في جنات النعيم على سرر متقابلين.",
        "اللهم اجعل أعمالنا الصالحة في ميزان حسنات والدينا برحمتك يا أرحم الراحمين.",
        "اللهم احفظ أمهات وآباء المسلمين جميعاً وأصلح أحوالهم.",
        "اللهم املأ قلب والديّ بالسكينة والرضا التام واليقين الصادق.",
        "اللهم نقّ والديّ من الخطايا كما ينقى الثوب الأبيض من الدنس.",
        "اللهم اجعل ليل والديّ سلاماً ونهارهما ضياءً وتوفيقاً.",
        "اللهم ارزق والديّ شكر نعمتك وحسن عبادتك حتى يأتيهما اليقين.",
        "اللهم تجاوز عن هفوات والديّ وأبدل سيئاتهما حسنات مضاعفة.",
        "اللهم اجعل أبي وأمي من السبعين ألفاً الذين يدخلون الجنة بلا حساب.",
        "اللهم يمّن كتاب والديّ ويسّر حسابهما وثقّل ميزانهما بالحسنات.",
        "اللهم أفرغ الصبر واليقين في قلوب والديّ واكفهما كل شرور الدنيا.",
        "اللهم اغفر لآبائنا وأمهاتنا وارحمهم برحمتك الواسعة يا الله."
    ];

    const AppState = {
        currentView: 'home', isDarkMode: false, userLocation: { lat: 15.5007, lng: 32.5599 },
        prayerTimes: {}, tasbeehCount: 0, adhkarProgress: {}, khatmahProgress: [], fontSize: 2,
        audioUrls: [], currentIndex: 0, isPlaying: false, currentSurah: 1, lastSavedDay: 0,
        isWidgetMode: false, isRecitationMode: false,
        prayerConfig: { Fajr: true, Sunrise: false, Dhuhr: true, Asr: true, Maghrib: true, Isha: true }
    };

    let activeStackIndex = 0;
    let currentAdhkarCategory = 'morning';
    window.quranAudio = new Audio();

    // 7. التأكد من أن دالة initApp تعمل بالكامل وتتحقق من وجود كافة العناصر (if element) قبل ربطها لمنع الـ TypeError
    function initApp() {
        try {
            // حقن وتفعيل أصول الـ PWA الممتدة والهوية المحيطية للتطبيق (Manifest) ديناميكياً لتسجيلها بامتياز في المتصفح والنظام
            injectDynamicPWAManifest();

            loadPersistence();
            checkAutoResetEngine(); 
            initPrayerEngine(); 
            initQuranSystem(); 
            initAdhkarSystem(); 
            initTasbeehSystem();
            initKnowledgeSystem(); 
            initKhatmahSystem(); 
            initQiblaSystem();
            initVoiceSearch();
            initAutoThemeAndAdhan();
            initRippleEffects();
            initSettingsPrayerConfig();
            requestNotificationPermission();
            
            // 1. فحص صارم وإعادة ربط أزرار التحكم وعناصر النوافذ التفاعلية بالأحداث
            const themeToggleBtn = document.getElementById('theme-toggle');
            if(themeToggleBtn) themeToggleBtn.addEventListener('click', toggleDarkMode);

            const settingsTriggerBtn = document.getElementById('settings-trigger');
            if(settingsTriggerBtn) settingsTriggerBtn.addEventListener('click', () => switchView('settings'));

            const globalBackBtn = document.getElementById('global-back-btn');
            if(globalBackBtn) globalBackBtn.addEventListener('click', () => switchView('home'));

            const refreshDuaBtn = document.getElementById('refresh-dua-btn');
            if(refreshDuaBtn) {
                refreshDuaBtn.addEventListener('click', () => {
                    const duas = ["اللهم آتنا في الدنيا حسنة وفي الآخرة حسنة", "يا مقلب القلوب ثبت قلبي على دينك", "اللهم إنك عفو كريم تحب العفو فاعف عني", "ربنا تقبل منا إنك أنت السميع العليم"];
                    const dailyDuaText = document.getElementById('daily-dua-text');
                    if(dailyDuaText) dailyDuaText.innerText = `"${duas[Math.floor(Math.random() * duas.length)]}"`;
                });
            }

            const appExitTriggerBtn = document.getElementById('app-exit-trigger');
            if(appExitTriggerBtn) appExitTriggerBtn.addEventListener('click', () => triggerExitModal(true));

            const btnConfirmExit = document.getElementById('btn-confirm-exit');
            if(btnConfirmExit) btnConfirmExit.addEventListener('click', () => closeAppConfirm(true));

            const btnCancelExit = document.getElementById('btn-cancel-exit');
            if(btnCancelExit) btnCancelExit.addEventListener('click', () => closeAppConfirm(false));

            const navCardKhatmah = document.getElementById('nav-card-khatmah');
            if(navCardKhatmah) navCardKhatmah.addEventListener('click', () => switchView('khatmah'));

            const navCardTasbeeh = document.getElementById('nav-card-tasbeeh');
            if(navCardTasbeeh) navCardTasbeeh.addEventListener('click', () => switchView('tasbeeh'));

            const btnResetAdhkar = document.getElementById('btn-reset-adhkar-progress');
            if(btnResetAdhkar) btnResetAdhkar.addEventListener('click', resetAdhkarProgress);

            const btnResetKhatmah = document.getElementById('btn-reset-khatmah-progress');
            if(btnResetKhatmah) btnResetKhatmah.addEventListener('click', resetKhatmahProgress);

            const toggleRecitationBtn = document.getElementById('toggle-recitation-btn');
            if(toggleRecitationBtn) toggleRecitationBtn.addEventListener('click', () => window.toggleRecitationMode());

            const btnCloseQuranReader = document.getElementById('btn-close-quran-reader');
            if(btnCloseQuranReader) btnCloseQuranReader.addEventListener('click', closeQuranReader);

            const btnCloseTafsir = document.getElementById('btn-close-tafsir');
            if(btnCloseTafsir) btnCloseTafsir.addEventListener('click', () => {
                const tafsirModal = document.getElementById('tafsir-glass-modal');
                if(tafsirModal) tafsirModal.classList.remove('show');
            });

            // تأمين تسجيل شريط التنقل السفلي والتحقق من وجود الكلاسات
            document.querySelectorAll('.bottom-nav .nav-item').forEach(item => {
                item.addEventListener('click', function() {
                    const viewId = this.getAttribute('data-id');
                    if(viewId) switchView(viewId);
                });
            });
            
            updateWorshipStats();
            updateSmartWirdEngine();
            updateTreeUI();
            
            console.log("تم تحميل تطبيق إخلاص وتأمين كافة الأحداث بنجاح ١٠٠٪.");
        } catch (e) {
            console.error("استثناء تم التقاطه أثناء تشغيل النواة التطبيقية: ", e);
        }
    }

    // دالة إنشاء وحقن الـ PWA Manifest المطور لتعريف تدويل النظام، الأيقونات المتجاورة والوصف التعريفي
    function injectDynamicPWAManifest() {
        try {
            const pwaManifest = {
                "name": "إخلاص | صديق الجنة",
                "short_name": "إخلاص",
                "description": "منصة إسلامية متكاملة ومطورة لعام 2026، تقدم مواقيت الصلاة الدقيقة، أذكار وأوراد مأثورة، مصحف رقمي تفاعلي مع وضع التسميع الذكي وبوصلة القبلة المتوهجة.",
                "lang": "ar",
                "dir": "rtl",
                "start_url": "index.html",
                "display": "standalone",
                "background_color": "#eef2f5",
                "theme_color": "#0d9488",
                "icons": [
                    { "src": "icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
                    { "src": "icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" },
                    { "src": "icon-maskable-192.png", "sizes": "192x192", "type": "image/png", "purpose": "maskable" },
                    { "src": "icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
                ]
            };
            const manifestStr = JSON.stringify(pwaManifest);
            const blob = new Blob([manifestStr], { type: 'application/json' });
            const manifestURL = URL.createObjectURL(blob);
            let manifestLink = document.querySelector('link[rel="manifest"]');
            if (!manifestLink) {
                manifestLink = document.createElement('link');
                manifestLink.rel = 'manifest';
                document.head.appendChild(manifestLink);
            }
            manifestLink.href = manifestURL;
        } catch (pwaErr) {
            console.error("فشل حقن الـ Manifest ديناميكياً: ", pwaErr);
        }
    }

    function loadPersistence() { const saved = localStorage.getItem('IkhlasAppState2026_v2'); if (saved) { try { Object.assign(AppState, JSON.parse(saved)); } catch(e){} } }
    function savePersistence() { localStorage.setItem('IkhlasAppState2026_v2', JSON.stringify(AppState)); updateWorshipStats(); updateTreeUI(); }
    
    function checkAutoResetEngine() {
        const currentDay = new Date().getDate();
        if (AppState.lastSavedDay !== 0 && AppState.lastSavedDay !== currentDay) {
            AppState.tasbeehCount = 0;
            AppState.adhkarProgress = {};
            triggerHapticPro(200); 
        }
        AppState.lastSavedDay = currentDay;
        savePersistence();
    }

    function initRippleEffects() {
        document.body.addEventListener('click', function(e) {
            const target = e.target.closest('.ripple-effect');
            if (!target) return;
            const rect = target.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const ripple = document.createElement('span');
            ripple.className = 'ripple-element';
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;
            
            target.appendChild(ripple);
            ripple.addEventListener('animationend', () => ripple.remove());
        });
    }

    // 5. إصلاح وتأمين نظام استعراض وتناوب الصفحات switchView() والتحقق من وجود كل قسم
    function switchView(viewId) {
        const targetSection = document.getElementById(`view-${viewId}`);
        if (!targetSection) {
            console.warn(`القسم المستهدف view-${viewId} غير متواجد بالـ DOM الحالي.`);
            return;
        }

        document.querySelectorAll('.view-section').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        
        targetSection.classList.add('active');
        const activeNav = document.querySelector(`.nav-item[data-id="${viewId}"]`);
        if (activeNav) activeNav.classList.add('active');
        
        const backBtn = document.getElementById('global-back-btn');
        if (backBtn) {
            if (['home', 'quran', 'adhkar', 'knowledge', 'qibla'].includes(viewId)) { 
                backBtn.style.display = 'none'; 
            } else { 
                backBtn.style.display = 'inline-flex'; 
            }
        }

        const scrollTarget = document.querySelector('.app-container');
        if (scrollTarget) {
            if(window.innerWidth > 1024) { scrollTarget.scrollTop = 0; } else { window.scrollTo({ top: 0, behavior: 'smooth' }); }
        }
        triggerHapticPro(15);
        updateSmartWirdEngine();
    }

    function updateTreeUI() {
        let score = AppState.tasbeehCount;
        for (let k in AppState.adhkarProgress) score += AppState.adhkarProgress[k];
        score += (AppState.khatmahProgress.length * 10);

        const leaves = document.querySelectorAll('.tree-leaf');
        leaves.forEach((leaf, idx) => {
            if (score > (idx * 15)) {
                leaf.style.fill = '#2dd4bf';
                leaf.style.opacity = '0.9';
                leaf.style.transform = `scale3d(${1 + (score*0.001)}, ${1 + (score*0.001)}, 1)`;
            } else {
                leaf.style.fill = '#115e59';
                leaf.style.opacity = '0.3';
                leaf.style.transform = 'scale3d(1, 1, 1)';
            }
        });

        const statusText = document.getElementById('tree-status-text');
        if(statusText) {
            if (score === 0) statusText.innerText = "اغرس أولى أوراق شجرتك بالذكر الآن";
            else if (score < 50) statusText.innerText = "جميل! شجرتك النورانية بدأت بالنمو والتفتح";
            else statusText.innerText = "ما شاء الله! شجرتك النورانية وارفة ومضيئة بذكرك";
        }
    }

    function updateWorshipStats() {
        let dhikrTotal = 0; for (let k in AppState.adhkarProgress) dhikrTotal += AppState.adhkarProgress[k];
        const tasbeehSummary = document.getElementById('tasbeeh-summary');
        if(tasbeehSummary) tasbeehSummary.innerText = `${AppState.tasbeehCount + dhikrTotal} ذِكر وتسبيح اليوم`;
        
        const khatmahSummary = document.getElementById('khatmah-summary');
        if(khatmahSummary) khatmahSummary.innerText = AppState.khatmahProgress.length > 0 ? `أتممت ${Math.round((AppState.khatmahProgress.length/30)*100)}% من الختمة` : "خطة ٣٠ يوماً ميسرة";
    }

    function updateSmartWirdEngine() {
        const hour = new Date().getHours();
        const card = document.getElementById('smart-ai-wird-card');
        if (!card) return;
        
        const badge = document.getElementById('ai-wird-badge');
        const title = document.getElementById('ai-wird-title');
        const desc = document.getElementById('ai-wird-desc');

        if (hour >= 1 && hour < 4) {
            if(badge) badge.innerText = "ورد السحر والتهجد"; if(title) title.innerText = "الاستغفار بالأسحار وصلاة الليل";
            if(desc) desc.innerText = "هذا الوقت العظيم مستجاب فيه الدعاء، نقترح عليك فتح السبحة والاستغفار ١٠٠ مرة أو تلاوة سورة الملك.";
            card.onclick = () => { 
                switchView('tasbeeh'); 
                const txt = document.getElementById('current-dhikr-text');
                if(txt) txt.innerText = "أستغفر الله وأتوب إليه"; 
            };
        } else if (hour >= 4 && hour < 11) {
            if(badge) badge.innerText = "ورد البكور والصباح"; if(title) title.innerText = "أذكار الصباح وتحصين النفس";
            if(desc) desc.innerText = "أتممت صلاة الفجر؟ حان وقت جلب الطمأنينة لليوم بالبدء ببطاقات أذكار الصباح الكريستالية.";
            card.onclick = () => { 
                switchView('adhkar'); 
                const tab = document.querySelector('[data-category="morning"]');
                if(tab) tab.click(); 
            };
        } else if (hour >= 15 && hour < 19) {
            if(badge) badge.innerText = "ورد العصر والغروب"; if(title) title.innerText = "أذكار المساء المأثورة";
            if(desc) desc.innerText = "مع غروب شمس اليوم، حصن روحك وجسدك بأذكار المساء المباركة لتكفيك من كل شر.";
            card.onclick = () => { 
                switchView('adhkar'); 
                const tab = document.querySelector('[data-category="evening"]');
                if(tab) tab.click(); 
            };
        } else {
            if(badge) badge.innerText = "ورد الليل الساكن"; if(title) title.innerText = "الختمة الشهرية والرقية";
            if(desc) desc.innerText = "قبل نومك، نقترح عليك مراجعة جزء الختمة لليوم الحالي وقراءة أذكار النوم الهادئة.";
            card.onclick = () => { switchView('khatmah'); };
        }
    }

    function toggleDarkMode() {
        AppState.isDarkMode = !AppState.isDarkMode; 
        document.body.classList.toggle('dark-mode', AppState.isDarkMode);
        triggerHapticPro(30);
        savePersistence();
    }

    function triggerHapticPro(ms) { if (navigator.vibrate) navigator.vibrate(ms); }

    function triggerExitModal(show) {
        const modal = document.getElementById('custom-exit-modal');
        if (!modal) return;
        if (show) { 
            const randomDua = PARENT_DUAS[Math.floor(Math.random() * PARENT_DUAS.length)];
            const exitDuaText = document.getElementById('exit-random-dua-text');
            if(exitDuaText) exitDuaText.innerText = `"${randomDua}"`;
            modal.style.display = 'flex'; 
            setTimeout(() => modal.classList.add('show'), 10); 
        } 
        else { modal.classList.remove('show'); setTimeout(() => modal.style.display = 'none', 300); }
    }
    
    function closeAppConfirm(exit) { if(exit) { window.close(); window.location.href = "about:blank"; } else { triggerExitModal(false); triggerHapticPro(25); } }

    function initPrayerEngine() {
        setupDualDates();
        getGeoLocation(); 
        setInterval(updateCountdown, 1000);
        const refreshLocBtn = document.getElementById('refresh-location');
        if(refreshLocBtn) refreshLocBtn.addEventListener('click', getGeoLocation);
        
        const calcMethodSelect = document.getElementById('setting-calc-method');
        if(calcMethodSelect) calcMethodSelect.addEventListener('change', calculatePrayerTimes);
    }

    // 2. إعادة تفعيل وعرض التاريخ الميلادي والهجري (Umm Al-Qura) تلقائياً داخل العنصر المحدد
    function setupDualDates() {
        try {
            const date = new Date();
            let gDate = new Intl.DateTimeFormat('ar-EG', { day: 'numeric', month: 'long', year: 'numeric', calendar: 'gregory' }).format(date) + ' م';
            let hDate = new Intl.DateTimeFormat('ar-SA', { day: 'numeric', month: 'long', year: 'numeric', calendar: 'islamic-umalqura' }).format(date) + ' هـ';
            
            const dateContainer = document.getElementById('hijri-date-display');
            if (dateContainer) {
                dateContainer.style.display = 'flex'; dateContainer.style.justifyContent = 'space-between'; dateContainer.style.width = '100%'; dateContainer.style.marginTop = '4px';
                const badgeStyle = `background: var(--glass-bg); color: var(--text-main); padding: 8px 14px; border-radius: 12px; font-weight: 700; font-size: 0.85rem; border: 1px solid var(--glass-border); box-shadow: var(--shadow-inset);`;
                dateContainer.innerHTML = `<div style="${badgeStyle}">📅 ${gDate}</div><div style="${badgeStyle}">${hDate} 🌙</div>`;
            }
        } catch (e) {
            console.error("فشل في معالجة أو حقن التواريخ المزدوجة: ", e);
        }
    }

    function getGeoLocation() {
        const btn = document.getElementById('refresh-location'); 
        if(btn) btn.innerText = "جاري الحساب الفلكي...";
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (pos) => { AppState.userLocation.lat = pos.coords.latitude; AppState.userLocation.lng = pos.coords.longitude; calculatePrayerTimes(); if(btn) btn.innerText = "📍 تحديد الموقع وتحديث المواقيت حالياً"; },
                () => { calculatePrayerTimes(); if(btn) btn.innerText = "⚠️ فشل التحديد الجغرافي (توقيت افتراضي)"; }
            );
        } else { calculatePrayerTimes(); }
    }

    async function calculatePrayerTimes() {
        const methodSelect = document.getElementById('setting-calc-method');
        const method = methodSelect ? methodSelect.value : "5";
        try {
            const res = await fetch(`https://api.aladhan.com/v1/timings?latitude=${AppState.userLocation.lat}&longitude=${AppState.userLocation.lng}&method=${method}`);
            const data = await res.json();
            if (data.code === 200) { AppState.prayerTimes = data.data.timings; updatePrayerUI(); }
        } catch (e) {}
    }

    function updatePrayerUI() {
        const times = AppState.prayerTimes;
        const mapping = { Fajr: 'prayer-fajr', Sunrise: 'prayer-sunrise', Dhuhr: 'prayer-dhuhr', Asr: 'prayer-asr', Maghrib: 'prayer-maghrib', Isha: 'prayer-isha' };
        for (const [key, id] of Object.entries(mapping)) {
            const container = document.getElementById(id);
            if (times[key] && container) {
                const paragraph = container.querySelector('p');
                if(paragraph) paragraph.innerText = times[key];
            }
        }
    }

    function updateCountdown() {
        if (!AppState.prayerTimes || !AppState.prayerTimes.Fajr) return;
        const now = new Date(); let nextPrayer = null; let minDiff = Infinity;
        document.querySelectorAll('.time-box').forEach(b => b.classList.remove('active-prayer'));
        
        const list = [
            {id:'prayer-fajr',n:'الفجر',t:AppState.prayerTimes.Fajr, cls:'theme-fajr'},
            {id:'prayer-sunrise',n:'الشروق',t:AppState.prayerTimes.Sunrise, cls:'theme-sunrise'},
            {id:'prayer-dhuhr',n:'الظهر',t:AppState.prayerTimes.Dhuhr, cls:'theme-dhuhr'},
            {id:'prayer-asr',n:'العصر',t:AppState.prayerTimes.Asr, cls:'theme-asr'},
            {id:'prayer-maghrib',n:'المغرب',t:AppState.prayerTimes.Maghrib, cls:'theme-maghrib'},
            {id:'prayer-isha',n:'العشاء',t:AppState.prayerTimes.Isha, cls:'theme-isha'}
        ];
        
        list.forEach(p => {
            if(p.t) {
                const [h, m] = p.t.split(':'); const pDate = new Date(); pDate.setHours(h, m, 0, 0);
                let diff = pDate - now; if (diff < 0) { pDate.setDate(pDate.getDate() + 1); diff = pDate - now; }
                if (diff < minDiff) { minDiff = diff; nextPrayer = p; }
            }
        });
        
        if (nextPrayer) {
            const timerDisplay = document.getElementById('prayer-countdown');
            if(timerDisplay) timerDisplay.innerText = `${Math.floor(minDiff/3600000).toString().padStart(2,'0')}:${Math.floor((minDiff%3600000)/60000).toString().padStart(2,'0')}:${Math.floor((minDiff%60000)/1000).toString().padStart(2,'0')}`;
            
            const nameDisplay = document.getElementById('next-prayer-name');
            if(nameDisplay) nameDisplay.innerText = `صلاة ${nextPrayer.n}`; 
            
            const activeBox = document.getElementById(nextPrayer.id);
            if(activeBox) activeBox.classList.add('active-prayer');
            
            const currentHour = now.getHours();
            document.body.className = document.body.className.replace(/theme-\S+/g, '');
            
            const cdLabel = document.getElementById('dashboard-countdown-label');
            if (currentHour >= 1 && currentHour < 4) {
                document.body.classList.add('theme-twilight');
                if(cdLabel) cdLabel.innerText = "✨ ثلث الليل والتهجد .. الصلاة القادمة بعد";
            } else {
                document.body.classList.add(nextPrayer.cls);
                if(cdLabel) cdLabel.innerText = "الصلاة القادمة بعد";
            }
        }
    }

    function requestNotificationPermission() {
        if ("Notification" in window) {
            if (Notification.permission !== "granted" && Notification.permission !== "denied") {
                Notification.requestPermission();
            }
        }
    }

    function triggerSystemNotification(title, bodyText) {
        const adhanEnabledCheckbox = document.getElementById('setting-adhan-enabled');
        if (adhanEnabledCheckbox && !adhanEnabledCheckbox.checked) return;
        
        if ("Notification" in window && Notification.permission === "granted") {
            try {
                new Notification(title, { body: bodyText, icon: 'icon.png', dir: 'rtl' });
            } catch (e) {
                if (navigator.serviceWorker && navigator.serviceWorker.ready) {
                    navigator.serviceWorker.ready.then(registration => {
                        registration.showNotification(title, { body: bodyText, icon: 'icon.png' });
                    });
                }
            }
        }
    }

    window.muezzinAudio = new Audio('https://download.quranicaudio.com/adhan/makkah.mp3');
    window.lastPlayedAdhan = null;
    
    // ربط إرسال التنبيه وبث صوت الأذان والإشعار المنبثق الرسمي وقت الصلاة المحددة
    function initAutoThemeAndAdhan() {
        setInterval(() => {
            if (!AppState.prayerTimes || Object.keys(AppState.prayerTimes).length === 0) return;
            const now = new Date();
            const currentHHMM = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0');
            const todayDate = now.toISOString().split('T')[0];

            const adhanCheckbox = document.getElementById('setting-adhan-enabled');
            if (adhanCheckbox && !adhanCheckbox.checked) return;

            ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].forEach(p => {
                if (AppState.prayerTimes[p] === currentHHMM) {
                    const key = todayDate + '-' + p;
                    if (window.lastPlayedAdhan !== key) {
                        if (AppState.prayerConfig && AppState.prayerConfig[p] === true) {
                            window.lastPlayedAdhan = key;
                            
                            const arabicNames = { Fajr: 'الفجر', Dhuhr: 'الظهر', Asr: 'العصر', Maghrib: 'المغرب', Isha: 'العشاء' };
                            const titleStr = `حان الآن موعد صلاة ${arabicNames[p]}`;
                            const bodyStr = `تطبيق إخلاص: أقم صلاتك لوقتها، ذكر بالله ونور يملأ قلبك الآن.`;
                            
                            triggerSystemNotification(titleStr, bodyStr);
                            
                            // 4. الفحص الصارم لوجد عنصر الـ Popover وقنوات التنبيه في الخلفية
                            const adhanTitle = document.getElementById('adhan-popup-title');
                            const adhanPopover = document.getElementById('global-adhan-popover');
                            if(adhanTitle) adhanTitle.innerText = titleStr;
                            if(adhanPopover) adhanPopover.style.display = 'block';

                            alert(titleStr);
                            
                            window.muezzinAudio.currentTime = 0;
                            window.muezzinAudio.play().catch(()=>{});
                            triggerHapticPro([300, 150, 300]);
                        }
                    }
                }
            });
        }, 5000);
    }

    // 3. إصلاح الخلل البرمجي الجذري في تخصيص قنوات التنبيه المستقلة ومنع توقف كود الصفحة بالكامل
    function initSettingsPrayerConfig() {
        const switchesContainer = document.getElementById('prayer-custom-config-switches');
        if (!switchesContainer) return;

        const switches = switchesContainer.querySelectorAll('.toggle-switch');
        switches.forEach(sw => {
            const prayerKey = sw.dataset.cfgPrayer;
            if(prayerKey && AppState.prayerConfig) {
                sw.classList.toggle('active', !!AppState.prayerConfig[prayerKey]);
                
                sw.onclick = function() {
                    AppState.prayerConfig[prayerKey] = !AppState.prayerConfig[prayerKey];
                    this.classList.toggle('active', AppState.prayerConfig[prayerKey]);
                    triggerHapticPro(25);
                    savePersistence();
                };
            }
        });
    }

    let SURAHS_DATA_STORE = [];
    async function initQuranSystem() {
        const surahListContainer = document.getElementById('surah-list');
        try {
            const res = await fetch('https://api.alquran.cloud/v1/surah');
            const data = await res.json(); 
            SURAHS_DATA_STORE = data.data; 
            renderSurahs(SURAHS_DATA_STORE);
        } catch (e) { 
            if(surahListContainer) surahListContainer.innerHTML = '<p style="padding:20px; text-align:center;">تعذر جلب الفهرس الرقمي.</p>'; 
        }
        
        const tabsContainer = document.getElementById('quran-tabs-container');
        if(tabsContainer) {
            const qTabs = tabsContainer.querySelectorAll('.tab-btn');
            qTabs.forEach(t => {
                t.addEventListener('click', () => {
                    qTabs.forEach(tab => tab.classList.remove('active')); t.classList.add('active');
                    const searchContainer = document.getElementById('quran-ayahs-search-container');
                    if (t.dataset.qtarget === 'surahs') {
                        if(surahListContainer) surahListContainer.style.display = 'grid';
                        if(searchContainer) searchContainer.style.display = 'none';
                    } else {
                        if(surahListContainer) surahListContainer.style.display = 'none';
                        if(searchContainer) searchContainer.style.display = 'block';
                    }
                });
            });
        }

        const fontIncBtn = document.getElementById('reader-font-inc');
        if(fontIncBtn) fontIncBtn.addEventListener('click', () => { if(AppState.fontSize < 4){ AppState.fontSize++; applyFontSize(); } });
        
        const fontDecBtn = document.getElementById('reader-font-dec');
        if(fontDecBtn) fontDecBtn.addEventListener('click', () => { if(AppState.fontSize > 0){ AppState.fontSize--; applyFontSize(); } });
    }

    function renderSurahs(surahs) {
        const surahListContainer = document.getElementById('surah-list');
        if(!surahListContainer) return;
        surahListContainer.innerHTML = surahs.map(s => `<div class="card surah-card ripple-effect" onclick="openSurah(${s.number}, '${s.name}')"><div class="surah-number">${s.number}</div><div class="surah-name">${s.name}</div><div class="surah-details" style="font-size:0.75rem; color:var(--text-muted);">${s.numberOfAyahs} آية</div></div>`).join('');
    }

    function initVoiceSearch() {
        const trigger = document.getElementById('voice-search-trigger');
        const input = document.getElementById('ayah-search-input');
        const indicator = document.getElementById('voice-status-indicator');
        
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition || !trigger) { if(trigger) trigger.style.display = 'none'; return; }
        
        const recognition = new SpeechRecognition();
        recognition.lang = 'ar-SA'; recognition.interimResults = false;
        
        trigger.onclick = () => { triggerHapticPro(40); recognition.start(); };
        recognition.onstart = () => { if(indicator) indicator.style.display = 'block'; };
        recognition.onend = () => { if(indicator) indicator.style.display = 'none'; };
        recognition.onresult = (e) => {
            if(input) {
                input.value = e.results[0][0].transcript;
                triggerHapticPro(60); performAdvancedAyahSearch();
            }
        };
    }

    async function performAdvancedAyahSearch() {
        const searchInput = document.getElementById('ayah-search-input');
        const query = searchInput ? searchInput.value.trim() : "";
        const resultsBox = document.getElementById('ayah-search-results');
        if(!query || !resultsBox) return;
        resultsBox.innerHTML = '<div class="spinner"></div>';
        try {
            const res = await fetch(`https://api.alquran.cloud/v1/search/${encodeURIComponent(query)}/all/ar`);
            const data = await res.json();
            if (data.code === 200 && data.data.matches.length > 0) {
                resultsBox.innerHTML = `<div class="badge" style="margin-bottom:10px;">تم العثور على ${data.data.count} موضع في المصحف</div>`;
                resultsBox.innerHTML += data.data.matches.slice(0, 30).map(m => `
                    <div class="card" style="border-right: 4px solid var(--primary); text-align:right;">
                        <p class="islamic-text" style="font-size:1.3rem;">${m.text} <span class="ayah-circle-num">${m.numberInSurah}</span></p>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px; border-top:1px dashed var(--glass-border); padding-top:8px;">
                            <span style="font-size:0.85rem; color:var(--text-muted);">📖 سورة ${m.surah.name}</span>
                            <button class="btn-secondary" onclick="openSurah(${m.surah.number}, '${m.surah.name}')" style="padding:5px 12px; font-size:0.8rem; border-radius:8px;">فتح السورة</button>
                        </div>
                    </div>
                `).join('');
            } else { resultsBox.innerHTML = '<p style="text-align:center; padding:20px;">لم يتم العثور على نتائج عذراً.</p>'; }
        } catch(e) { resultsBox.innerHTML = '<p style="text-align:center; padding:20px;">خطأ في الاتصال بالخادم.</p>'; }
    }

    async function openSurah(n, name) {
        AppState.currentSurah = n;
        const readerModal = document.getElementById('quran-reader');
        const nameDisplay = document.getElementById('reader-surah-name');
        const versesContainer = document.getElementById('reader-verses');
        
        if(readerModal) readerModal.style.display = 'flex'; 
        if(nameDisplay) nameDisplay.innerText = 'سورة ' + name; 
        if(versesContainer) versesContainer.innerHTML = '<div class="spinner"></div>';
        window.stopQuranAudio();
        
        try {
            const res = await fetch(`https://api.alquran.cloud/v1/surah/${n}`);
            const data = await res.json();
            let html = (n !== 1 && n !== 9) ? `<div style="color:var(--accent); text-align:center; font-size:1.8rem; margin-bottom:15px; font-family:'Aref Ruqaa',serif;">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>` : '';
            
            data.data.ayahs.forEach((a, idx) => {
                let text = a.text;
                if (n !== 1 && n !== 9 && a.numberInSurah === 1) text = text.replace('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ', '');
                
                // بناء وضع التسميع والتحجب التدريجي الفوري لكل كلمة على حدة
                let processedText = text.split(' ').map(word => `<span class="recite-word" onclick="window.revealWord(this, event)">${word}</span>`).join(' ');
                html += `<span class="interactive-ayah" id="ayah-wrapper-${idx}" data-idx="${idx}" oncontextmenu="window.showTafsir(${n}, ${a.numberInSurah}); return false;">${processedText} <span class="ayah-circle-num">${a.numberInSurah}</span></span> `;
            });
            if(versesContainer) {
                versesContainer.innerHTML = html; 
                versesContainer.scrollTop = 0;
            }
            applyFontSize();
            syncRecitationUIVisuals(); 
            window.fetchSurahAudioUrls();
        } catch (e) { if(versesContainer) versesContainer.innerHTML = '<p style="padding:20px; text-align:center;">خطأ في تحميل السورة.</p>'; }
    }

    window.toggleRecitationMode = function() {
        AppState.isRecitationMode = !AppState.isRecitationMode;
        triggerHapticPro(45);
        syncRecitationUIVisuals();
    };

    function syncRecitationUIVisuals() {
        const reader = document.getElementById('quran-reader');
        const btn = document.getElementById('toggle-recitation-btn');
        if(!reader || !btn) return;
        
        if(AppState.isRecitationMode) {
            reader.classList.add('recitation-mode-active');
            btn.innerText = "🟢 وضع التسميع نشط";
            btn.style.background = "rgba(217, 119, 6, 0.15)";
        } else {
            reader.classList.remove('recitation-mode-active');
            btn.innerText = "🎚️ وضع التسميع";
            btn.style.background = "var(--glass-bg)";
            document.querySelectorAll('.recite-word').forEach(w => w.classList.remove('revealed'));
        }
    }

    window.revealWord = function(el, ev) {
        if(!AppState.isRecitationMode) return;
        ev.stopPropagation();
        el.classList.toggle('revealed');
        triggerHapticPro(15);
    };

    function closeQuranReader() { 
        const reader = document.getElementById('quran-reader');
        if(reader) reader.style.display = 'none'; 
        window.stopQuranAudio(); 
    }
    
    function applyFontSize() { 
        const verses = document.getElementById('reader-verses');
        if(verses) verses.style.fontSize = ['1.2rem','1.4rem','1.7rem','2.1rem','2.6rem'][AppState.fontSize]; 
    }

    window.showTafsir = async function(surah, ayah) {
        const modal = document.getElementById('tafsir-glass-modal');
        const textContainer = document.getElementById('tafsir-text');
        if(textContainer) textContainer.innerHTML = '⏳ جاري جلب البيان الميسر فقهياً...';
        if(modal) modal.classList.add('show');
        try {
            const res = await fetch(`https://api.alquran.cloud/v1/ayah/${surah}:${ayah}/ar.muyassar`);
            const data = await res.json();
            if(data.code === 200 && textContainer) { textContainer.innerText = data.data.text; } 
        } catch(e) { if(textContainer) textContainer.innerText = 'تعذر التحميل حالياً.'; }
    };

    window.fetchSurahAudioUrls = async function() {
        const n = AppState.currentSurah; 
        const reciterSelect = document.getElementById('reciter-select');
        const reciter = reciterSelect ? reciterSelect.value : "ar.alafasy";
        try {
            const res = await fetch(`https://api.alquran.cloud/v1/surah/${n}/${reciter}`);
            const data = await res.json();
            if (data.code === 200) { AppState.audioUrls = data.data.ayahs.map(a => a.audio); AppState.currentIndex = 0; }
        } catch(e) { AppState.audioUrls = []; }
    };

    const reciterSelectElement = document.getElementById('reciter-select');
    if(reciterSelectElement) {
        reciterSelectElement.addEventListener('change', function() {
            const wasPlaying = AppState.isPlaying; window.quranAudio.pause();
            window.fetchSurahAudioUrls().then(() => { if (wasPlaying) window.playCurrentAyah(); });
        });
    }

    const audioPlayPauseBtn = document.getElementById('audio-play-pause');
    if(audioPlayPauseBtn) {
        audioPlayPauseBtn.addEventListener('click', function() {
            if(AppState.audioUrls.length === 0) return;
            const reader = document.getElementById('quran-reader');
            if (AppState.isPlaying) {
                window.quranAudio.pause(); AppState.isPlaying = false; this.innerHTML = '▶'; if(reader) reader.classList.remove('aura-active');
            } else {
                window.playCurrentAyah(); this.innerHTML = '⏸'; if(reader) reader.classList.add('aura-active'); 
            }
        });
    }

    const audioNextBtn = document.getElementById('btn-audio-next');
    if(audioNextBtn) audioNextBtn.addEventListener('click', () => { if(AppState.currentIndex < AppState.audioUrls.length - 1) { AppState.currentIndex++; window.playCurrentAyah(); } });

    const audioPrevBtn = document.getElementById('btn-audio-prev');
    if(audioPrevBtn) audioPrevBtn.addEventListener('click', () => { if(AppState.currentIndex > 0) { AppState.currentIndex--; window.playCurrentAyah(); } });

    window.playCurrentAyah = function() {
        if (AppState.currentIndex >= AppState.audioUrls.length) { window.stopQuranAudio(); return; }
        window.quranAudio.src = AppState.audioUrls[AppState.currentIndex];
        window.quranAudio.play().then(() => { AppState.isPlaying = true; window.highlightAyah(); }).catch(()=>{});
    };

    window.stopQuranAudio = function() { 
        window.quranAudio.pause(); 
        AppState.isPlaying = false; 
        AppState.currentIndex = 0; 
        const btn = document.getElementById('audio-play-pause');
        if(btn) btn.innerHTML = '▶'; 
        const bar = document.getElementById('audio-progress-bar');
        if(bar) bar.style.width = '0%'; 
        window.clearHighlights(); 
        const reader = document.getElementById('quran-reader');
        if(reader) reader.classList.remove('aura-active'); 
    };

    window.highlightAyah = function() {
        window.clearHighlights();
        const wrapper = document.getElementById(`ayah-wrapper-${AppState.currentIndex}`);
        if (wrapper) {
            wrapper.classList.add('playing-highlight');
            wrapper.scrollIntoView({ behavior: 'smooth', block: 'center' });
            const bar = document.getElementById('audio-progress-bar');
            if(bar) bar.style.width = ((AppState.currentIndex + 1)/AppState.audioUrls.length)*100 + '%';
        }
    };

    window.clearHighlights = function() { document.querySelectorAll('.playing-highlight').forEach(el => el.classList.remove('playing-highlight')); };
    window.quranAudio.addEventListener('ended', () => { if(AppState.currentIndex < AppState.audioUrls.length - 1) { AppState.currentIndex++; window.playCurrentAyah(); } else { window.stopQuranAudio(); } });

    // نظام بطاقات الأذكار ثلاثية الأبعاد
    function initAdhkarSystem() {
        const container = document.getElementById('adhkar-tabs-container');
        if(container) {
            const tabs = container.querySelectorAll('.tab-btn');
            tabs.forEach(t => { 
                t.addEventListener('click', () => { 
                    tabs.forEach(tab => tab.classList.remove('active')); t.classList.add('active'); 
                    currentAdhkarCategory = t.dataset.category; activeStackIndex = 0;
                    renderAdhkarStack(currentAdhkarCategory); 
                }); 
            });
        }
        const nextBtn = document.getElementById('stack-next-btn');
        if(nextBtn) nextBtn.onclick = () => { navigateStack(1); };
        const prevBtn = document.getElementById('stack-prev-btn');
        if(prevBtn) prevBtn.onclick = () => { navigateStack(-1); };
        renderAdhkarStack('morning');
    }

    function renderAdhkarStack(cat) {
        const items = ADHKAR_DATA[cat] || []; const container = document.getElementById('adhkar-stack-container'); const counter = document.getElementById('stack-index-counter');
        if(!container) return;
        if(items.length === 0) { container.innerHTML = '<p style="padding:20px; text-align:center;">سيتم إضافة الورد قريباً.</p>'; if(counter) counter.innerText = "0 / 0"; return; }
        
        if(counter) counter.innerText = `${activeStackIndex + 1} / ${items.length}`;
        container.innerHTML = items.map((i, idx) => {
            const progress = AppState.adhkarProgress[i.id] || 0; const isDone = progress >= i.target;
            let transformStyle = `translateZ(-100px) translateY(24px) scale(0.9) rotateX(-2deg)`; let opacity = 0; let zIndex = 0;

            if (idx === activeStackIndex) { transformStyle = `translateZ(0px) translateY(0px) scale(1) rotateX(0deg)`; opacity = 1; zIndex = 10; } 
            else if (idx === activeStackIndex + 1) { transformStyle = `translateZ(-40px) translateY(14px) scale(0.95) rotateX(-1deg)`; opacity = 0.75; zIndex = 9; } 
            else if (idx === activeStackIndex + 2) { transformStyle = `translateZ(-80px) translateY(28px) scale(0.90) rotateX(-2deg)`; opacity = 0.35; zIndex = 8; }

            return `
                <div class="dhikr-stack-card ${isDone?'completed-card':''}" id="scard-${i.id}" style="transform: ${transformStyle}; opacity: ${opacity}; z-index: ${zIndex};">
                    <div class="dhikr-header"><span style="color:var(--accent); font-weight:800;">✨ ${i.info}</span><span class="badge">المطلوب: ${i.target}</span></div>
                    <div class="dhikr-text-container"><p class="islamic-text" style="font-size:1.35rem; width:100%;">${i.text}</p></div>
                    <div class="progress-bar-container"><div class="progress-bar-fill" id="pfill-${i.id}" style="width:${(progress/i.target)*100}%"></div></div>
                    <button class="counter-btn ripple-effect ${isDone?'done':''}" id="sbtn-${i.id}" onclick="incrementStackDhikr('${i.id}', ${i.target})">
                        ${isDone ? '✅ أتممت الورد والتحصين المبارك' : `التكرار الحالي: ${progress}`}
                    </button>
                </div>
            `;
        }).join('');
        setupDragAndSwipe(container);
    }

    function navigateStack(dir) {
        const items = ADHKAR_DATA[currentAdhkarCategory] || []; const newIdx = activeStackIndex + dir;
        if (newIdx >= 0 && newIdx < items.length) { activeStackIndex = newIdx; triggerHapticPro(25); renderAdhkarStack(currentAdhkarCategory); }
    }

    window.incrementStackDhikr = function(id, target) {
        if (!AppState.adhkarProgress[id]) AppState.adhkarProgress[id] = 0;
        if (AppState.adhkarProgress[id] < target) {
            let p = ++AppState.adhkarProgress[id];
            const fill = document.getElementById(`pfill-${id}`);
            if(fill) fill.style.width = `${(p/target)*100}%`;
            
            let btn = document.getElementById(`sbtn-${id}`); 
            if(btn) btn.innerText = p >= target ? '✅ أتممت الورد والتحصين المبارك' : `التكرار الحالي: ${p}`;
            
            if (p >= target) {
                if(btn) btn.classList.add('done'); 
                const card = document.getElementById(`scard-${id}`);
                if(card) card.classList.add('completed-card');
                triggerHapticPro(100); setTimeout(() => { navigateStack(1); }, 800);
            } else { triggerHapticPro(35); }
            savePersistence();
        }
    };

    function resetAdhkarProgress() {
        const items = ADHKAR_DATA[currentAdhkarCategory] || [];
        items.forEach(i => { AppState.adhkarProgress[i.id] = 0; });
        triggerHapticPro(180); savePersistence(); activeStackIndex = 0; renderAdhkarStack(currentAdhkarCategory);
    }

    // السبحة
    function initTasbeehSystem() {
        const btn = document.getElementById('tasbeeh-btn'); const display = document.getElementById('tasbeeh-main-count'); const widgetToggle = document.getElementById('toggle-widget-btn');
        if(display) display.innerText = AppState.tasbeehCount;
        
        if(btn) {
            btn.onclick = () => { 
                AppState.tasbeehCount++; 
                if(display) display.innerText = AppState.tasbeehCount; 
                triggerHapticPro(35); 
                savePersistence(); 
            };
        }
        const resetBtn = document.getElementById('tasbeeh-reset');
        if(resetBtn) resetBtn.onclick = () => { AppState.tasbeehCount = 0; if(display) display.innerText = '0'; triggerHapticPro(180); savePersistence(); };
        
        const phrases = ["سبحان الله وبحمده", "الحمد لله رب العالمين", "لا إله إلا الله", "الله أكبر كبيراً", "أستغفر الله وأتوب إليه", "اللهم صلِّ على محمد"];
        let idx = 0;
        
        const modeBtn = document.getElementById('tasbeeh-mode');
        if(modeBtn) {
            modeBtn.onclick = () => { 
                idx = (idx+1)%phrases.length; 
                const txt = document.getElementById('current-dhikr-text');
                if(txt) txt.innerText = phrases[idx]; 
                triggerHapticPro(25); 
            };
        }
        if(widgetToggle) {
            widgetToggle.onclick = function() {
                AppState.isWidgetMode = !AppState.isWidgetMode; triggerHapticPro(50);
                if(AppState.isWidgetMode) { if(btn) btn.classList.add('floating-widget'); this.innerText = "🟢 إرجاع لحجمه الطبيعي"; } 
                else { if(btn) btn.classList.remove('floating-widget'); this.innerText = "📱 العداد العائم"; }
            };
        }
    }

    // تتبع الختمة
    function initKhatmahSystem() {
        const headerCard = document.querySelector('.khatmah-header-card');
        if (headerCard && !document.getElementById("khatmah-tracker-node")) {
            const trackerNode = document.createElement("div"); trackerNode.id = "khatmah-tracker-node"; trackerNode.className = "khatmah-tracker-container";
            trackerNode.innerHTML = `<div>📈 حصيلة المتابعة: <span id="ext-khatmah-counter" style="font-weight: 900; color: var(--primary);">٠ أجزاء</span></div><div class="khatmah-badge-pill" id="ext-khatmah-medal">مرتبة البدء 🌱</div>`;
            headerCard.parentNode.insertBefore(trackerNode, document.getElementById("khatmah-days-container"));
        }
        renderKhatmah(); 
    }

    function renderKhatmah() {
        const percentage = Math.round((AppState.khatmahProgress.length/30)*100);
        const percentDisplay = document.getElementById('khatmah-percent');
        if(percentDisplay) percentDisplay.innerText = `${percentage}%`;
        
        const circle = document.getElementById('khatmah-progress-circle');
        if(circle) circle.style.background = `conic-gradient(var(--accent) ${percentage}%, rgba(255,255,255,0.15) ${percentage}%)`;
        
        const title = document.getElementById('khatmah-status-title');
        if(title) title.innerText = AppState.khatmahProgress.length > 0 ? `الختمة جارية بهمة ونور` : "لم تبدأ الختمة الشهرية بعد";
        
        const countField = document.getElementById("ext-khatmah-counter"); const medalField = document.getElementById("ext-khatmah-medal"); const totalRead = AppState.khatmahProgress.length;
        if (countField) countField.innerText = `${totalRead} / ٣٠ جزءًا`;
        if (medalField) {
            if (totalRead >= 25) { medalField.innerHTML = "خاتم خاشع 👑"; medalField.style.background = "linear-gradient(135deg, #10b981, #047857)"; } 
            else if (totalRead >= 10) { medalField.innerHTML = "الهمّة العالية 💎"; medalField.style.background = "linear-gradient(135deg, #6366f1, #4338ca)"; } 
            else if (totalRead >= 1) { medalField.innerHTML = "مداوم قرآن 🌤️"; medalField.style.background = "linear-gradient(135deg, var(--accent), #b45309)"; } 
            else { medalField.innerHTML = "مرتبة البدء 🌱"; medalField.style.background = "linear-gradient(135deg, var(--text-muted), #475569)"; }
        }
        
        const daysContainer = document.getElementById('khatmah-days-container');
        if(daysContainer) {
            daysContainer.innerHTML = KHATMAH_PLAN.map((p, i) => `
                <div class="khatmah-day-item ripple-effect ${AppState.khatmahProgress.includes(i+1)?'completed':''}" onclick="toggleKhatmahDay(${i+1})">
                    <div><h4 style="font-weight:800; color:var(--primary);">اليوم المبارك ${i+1}</h4><p style="font-size:0.85rem; color:var(--text-muted); margin-top:2px;">${p}</p></div>
                    <div class="khatmah-check">✔</div>
                </div>
            `).join('');
        }
    }

    window.toggleKhatmahDay = function(day) {
        if (AppState.khatmahProgress.includes(day)) AppState.khatmahProgress = AppState.khatmahProgress.filter(d => d !== day);
        else { AppState.khatmahProgress.push(day); triggerHapticPro(50); }
        savePersistence(); renderKhatmah();
    };
    function resetKhatmahProgress() { AppState.khatmahProgress = []; triggerHapticPro(180); savePersistence(); renderKhatmah(); }

    // الرقائق
    function initKnowledgeSystem() {
        const container = document.getElementById('knowledge-tabs-nav');
        if(container) {
            const tabs = container.querySelectorAll('.tab-btn');
            tabs.forEach(t => { t.addEventListener('click', function() { tabs.forEach(tab => tab.classList.remove('active')); this.classList.add('active'); renderKnowledge(this.dataset.source); }); });
        }
        renderKnowledge('hadith');
    }

    function renderKnowledge(src) {
        const box = document.getElementById('knowledge-content'); if (!box) return;
        if (src === 'hadith') {
            box.innerHTML = MEGA_HADITH_DATA.map(c => `<div style="background:linear-gradient(135deg, var(--primary), var(--primary-dark)); color:white; padding:12px; border-radius:12px; margin:15px 0 10px; font-weight:800; font-size:0.92rem; text-align:center;">${c.chapter}</div>` + c.hadiths.map(h => `<div class="card" style="border-right: 4px solid var(--accent); text-align:right;"><div class="badge" style="margin-bottom:10px;">✨ ${h.topic}</div><p class="islamic-text" style="font-size:1.4rem; text-align: justify;">«${h.text}»</p><div class="knowledge-footer-react"><span>📚 المصدر: ${h.source}</span><span class="knowledge-react-btn" onclick="this.innerText='❤️ تم التدبر'">❤️ تأملتها</span></div></div>`).join('')).join('');
        } else if (src === 'sunnah') {
            box.innerHTML = SUNNAH_DATA.map(s => `<div class="card" style="border-right: 4px solid var(--primary); text-align:right;"><h3 style="color:var(--primary); font-weight:800; font-family:'Reem Kufi',sans-serif;">🌱 ${s.title}</h3><p style="margin-top:8px; color:var(--text-main); font-size:1.05rem; line-height:1.7; text-align: justify; font-family:var(--font-ui);">${s.desc}</p><div class="knowledge-footer-react"><span>📚 المصدر: ${s.source}</span><span class="knowledge-react-btn" onclick="this.innerText='❤️ تم العمل بها'">❤️ تطبيق السُنّة</span></div></div>`).join('');
        } else if (src === 'stories') {
            box.innerHTML = STORIES_DATA.map(s => `<div class="card" style="border-right: 4px solid #10b981; text-align:right;"><h3 style="color:var(--primary-dark); font-weight:800; font-family:'Reem Kufi',sans-serif; margin-bottom:6px;">📖 ${s.title}</h3><p style="color:var(--text-main); font-size:1.1rem; line-height:1.8; text-align: justify; font-family:var(--font-quran);">${s.desc}</p><div class="knowledge-footer-react" style="margin-top:15px;"><span style="font-weight:700; color:var(--text-muted);">${s.source}</span><span class="knowledge-react-btn" style="color:#10b981;" onclick="this.innerHTML='❤️ تم استخلاص العِبرة';">❤️ تدبر وعِبرة</span></div></div>`).join('');
        }
    }

    // البوصلة التفاعلية وشاشة القبلة المتوهجة
    function initQiblaSystem() {
        const btn = document.getElementById('enable-compass');
        if(btn) {
            btn.onclick = () => {
                if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
                    DeviceOrientationEvent.requestPermission().then(state => { if (state === 'granted') { window.addEventListener('deviceorientation', handleCompass, true); btn.style.display = 'none'; } });
                } else { window.addEventListener('deviceorientation', handleCompass, true); btn.style.display = 'none'; }
            };
        }
    }
    
    function handleCompass(e) {
        let alpha = e.alpha; if (e.webkitCompassHeading) alpha = 360 - e.webkitCompassHeading;
        if (alpha === null) return; const qiblaAngle = 65; 
        
        const rose = document.getElementById('compass-rose');
        if(rose) rose.style.transform = `rotate3d(0, 0, 1, ${-alpha}deg)`;
        
        const pointer = document.getElementById('qibla-pointer');
        if(pointer) pointer.style.transform = `translate3d(-50%, -100%, 0) rotate3d(0, 0, 1, ${(qiblaAngle - alpha)}deg)`;
        
        let diff = Math.abs(alpha - qiblaAngle);
        const outerCompass = document.getElementById('compass-outer');
        const qiblaText = document.getElementById('qibla-text');
        
        if (diff < 8 || diff > 352) {
            if(outerCompass) outerCompass.classList.add('aligned');
            if(qiblaText) qiblaText.innerHTML = '🟢 اتجاه الكعبة المشرفة صحيح 🕋';
            triggerHapticPro(30);
        } else {
            if(outerCompass) outerCompass.classList.remove('aligned');
            if(qiblaText) qiblaText.innerText = 'قم بتدوير الهاتف حتى يتطابق المؤشر مع القبلة';
        }
    }

    // إقلاع وتأمين المحرك التطبيقي بالكامل بعد فحص وتطهير الشفرة المصدريّة
    initApp();
