/**
 * 🎵 محرك أصوات الأذان المحلي (Offline Native Adhan Engine)
 * الإصدار 6.0.0.1 | برمجة: مجتبى صديق
 */
(function initNativeOfflineAdhan() {
    'use strict';

    // قائمة الروابط المحلية داخل مجلد الـ audio
    const ADHAN_SOUNDS = [
        { name: "مكة المكرمة (الحرم المكي)", url: "audio/makkah.mp3" },
        { name: "المدينة المنورة (الحرم المدني)", url: "audio/madinah.mp3" },
        { name: "المسجد الأقصى المبارك", url: "audio/alaqsa.mp3" },
        { name: "مشاري راشد العفاسي", url: "audio/mishary_alafasy.mp3" },
        { name: "عبد الباسط عبد الصمد", url: "audio/abdulbasit.mp3" }
    ];

    // حقن القائمة في الإعدادات
    function injectUI() {
        const settingsView = document.getElementById('view-settings');
        if (settingsView && !document.getElementById('adhan-sound-settings-card')) {
            const optionsHTML = ADHAN_SOUNDS.map(s => `<option value="${s.url}">${s.name}</option>`).join('');
            const card = `
                <div class="card" id="adhan-sound-settings-card" style="border-right: 4px solid var(--accent);">
                    <h3 style="margin-bottom: 15px; color: var(--primary);">🎵 صوت الأذان (محلي)</h3>
                    <select id="setting-adhan-sound" style="width: 100%; padding: 12px; border-radius: 12px; background: var(--glass-bg-solid); color: var(--text-main); font-weight: bold;">
                        ${optionsHTML}
                    </select>
                    <button class="btn-secondary" id="test-adhan-btn" style="margin-top: 15px; width: 100%;">🔊 استماع تجريبي</button>
                </div>
            `;
            settingsView.insertAdjacentHTML('afterbegin', card);
        }
    }

    // ربط المنطق البرمجي
    function bindLogic() {
        const select = document.getElementById('setting-adhan-sound');
        const btn = document.getElementById('test-adhan-btn');
        if (!select || !btn) return;

        // تحميل الصوت المختار
        let audio = new Audio(localStorage.getItem('AdhanSoundUrl') || ADHAN_SOUNDS[0].url);
        select.value = localStorage.getItem('AdhanSoundUrl') || ADHAN_SOUNDS[0].url;

        select.addEventListener('change', () => {
            localStorage.setItem('AdhanSoundUrl', select.value);
            audio.src = select.value;
        });

        btn.addEventListener('click', () => {
            if (audio.paused) {
                audio.play();
                btn.innerText = "⏹ إيقاف";
            } else {
                audio.pause();
                audio.currentTime = 0;
                btn.innerText = "🔊 استماع تجريبي";
            }
        });
        
        audio.onended = () => btn.innerText = "🔊 استماع تجريبي";

        // تحديث الدالة الأساسية لتشغيل الصوت المحلي عند دخول وقت الصلاة
        window.playFullAdhanNative = function() {
            const soundUrl = localStorage.getItem('AdhanSoundUrl') || ADHAN_SOUNDS[0].url;
            const adhan = new Audio(soundUrl);
            adhan.play().catch(e => console.log("خطأ في تشغيل الأذان المحلي:", e));
            if (navigator.vibrate) navigator.vibrate([1000, 500, 1000]);
        };
    }

    // التنفيذ
    setTimeout(() => { injectUI(); bindLogic(); }, 1000);
})();
