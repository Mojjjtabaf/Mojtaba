1. cd worker && npx wrangler kv namespace create RL  (انسخ المعرّف إلى wrangler.toml)
2. npx wrangler secret put ANTHROPIC_API_KEY
3. npx wrangler deploy  ثم ضع رابط الـWorker في js/assistant.js (ASSISTANT_URL)
الحدود: 30 سؤالاً يومياً لكل جهاز، 6 في الدقيقة، 120 يومياً لكل IP (عدّلها في index.js).
