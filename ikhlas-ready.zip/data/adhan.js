/* سجل المؤذنين: ملف محلي داخل الحزمة (web للتطبيق، file لصوت إشعار أندرويد) وبديل من الإنترنت */
(function(){
const LIST=[
 {id:'makkah',name:'أذان الحرم المكي',file:'adhan_makkah.mp3',remote:'https://download.quranicaudio.com/adhan/makkah.mp3'},
 {id:'madinah',name:'أذان الحرم المدني',file:'adhan_madinah.mp3',remote:'https://download.quranicaudio.com/adhan/madinah.mp3'},
 {id:'alaqsa',name:'أذان المسجد الأقصى',file:'adhan_alaqsa.mp3',remote:'https://download.quranicaudio.com/adhan/alaqsa.mp3'},
 {id:'alafasy',name:'مشاري العفاسي',file:'adhan_alafasy.mp3',remote:'https://download.quranicaudio.com/adhan/mishary_alafasy.mp3'},
 {id:'abdulbasit',name:'عبد الباسط عبد الصمد',file:'adhan_abdulbasit.mp3',remote:'https://download.quranicaudio.com/adhan/abdulbasit.mp3'}];
const have={};
LIST.forEach(s=>{s.web='audio/adhan/'+s.id+'.mp3';fetch(s.web,{method:'HEAD'}).then(r=>{have[s.id]=r.ok;}).catch(()=>{have[s.id]=false;});});
window.ADHAN_REGISTRY=LIST;
window.AdhanRegistry={
  list:LIST,
  get:id=>LIST.find(s=>s.id===id)||LIST[0],
  urlFor(id){const s=this.get(id);return have[s.id]?s.web:s.remote;},
  fileFor(id){return this.get(id).file;}
};
})();
