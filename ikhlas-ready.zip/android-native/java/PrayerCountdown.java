package __PKG__;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.SystemClock;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;
import java.util.Calendar;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * إشعار دائم «الصلاة القادمة» بتصميم زجاجي: عدّاد تنازلي يحرّكه النظام (Chronometer)،
 * وفي الحالة الموسّعة صفّ مواقيت اليوم الخمسة مع تمييز الصلاة القادمة.
 * يتجدّد عند كل أذان وعند الإقلاع وعند كل جدولة. إن غابت ملفات التصميم يرجع إلى إشعار عادي.
 */
final class PrayerCountdown {
    static final String CHANNEL = "prayer_next_v2";
    static final int NOTIF_ID = 4712;
    private static final String PREFS = "ikhlas_adhan";
    private static final String KEY_ON = "countdown_on";
    private static final String[] ORDER = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};

    static boolean enabled(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ON, true);
    }

    static void setEnabled(Context c, boolean on) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ON, on).apply();
        update(c);
    }

    static void cancel(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIF_ID);
    }

    static String arName(String k) {
        switch (k == null ? "" : k) {
            case "Fajr": return "الفجر";
            case "Sunrise": return "الشروق";
            case "Dhuhr": return "الظهر";
            case "Asr": return "العصر";
            case "Maghrib": return "المغرب";
            case "Isha": return "العشاء";
            default: return "الصلاة";
        }
    }

    private static String clock(long at) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(at);
        int h = cal.get(Calendar.HOUR_OF_DAY), m = cal.get(Calendar.MINUTE);
        return ((h % 12 == 0) ? 12 : h % 12) + ":" + (m < 10 ? "0" : "") + m + (h < 12 ? " ص" : " م");
    }

    private static int dayKey(long at) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(at);
        return cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR);
    }

    private static int rid(Context c, String name, String type) {
        return c.getResources().getIdentifier(name, type, c.getPackageName());
    }

    private static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "الصلاة القادمة", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("عدّ تنازلي دائم لموعد الصلاة القادمة");
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setShowBadge(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    /** يملأ الجزء المشترك بين الحالتين: الخلفية الزجاجية والشارة والعنوان والعدّاد. */
    private static void fillHeader(Context c, RemoteViews rv, String prayer, long best, long now, int accent,
                                   int bgW, int bgH, float radius, int badge, boolean withTime) {
        rv.setImageViewBitmap(rid(c, "g_bg", "id"), GlassArt.card(bgW, bgH, radius, accent));
        rv.setImageViewBitmap(rid(c, "g_badge", "id"), GlassArt.badge(badge, accent, prayer));
        rv.setTextViewText(rid(c, "g_name", "id"), arName(prayer));
        rv.setTextViewText(rid(c, "g_kicker", "id"), "الصلاة القادمة · " + clock(best));
        int cid = rid(c, "g_count", "id");
        rv.setChronometer(cid, SystemClock.elapsedRealtime() + (best - now), null, true);
        if (Build.VERSION.SDK_INT >= 24) rv.setChronometerCountDown(cid, true);
    }

    /** يقرأ القائمة المحفوظة ويعرض أقرب موعد قادم؛ يزيل الإشعار إن لم يوجد. */
    static void update(Context c) {
        try {
            if (!enabled(c)) { cancel(c); return; }
            JSONArray list = AdhanStore.load(c);
            long now = System.currentTimeMillis(), best = Long.MAX_VALUE;
            JSONObject next = null;
            for (int i = 0; i < list.length(); i++) {
                JSONObject o = list.optJSONObject(i);
                if (o == null) continue;
                long at = o.optLong("at");
                if (at > now && at < best) { best = at; next = o; }
            }
            if (next == null) { cancel(c); return; }

            ensureChannel(c);
            String prayer = next.optString("prayer");
            int accent;
            try { accent = Color.parseColor(next.optString("color", "#0d9488")); } catch (Exception e) { accent = 0xFF0D9488; }
            int icon = rid(c, "ic_stat_icon", "drawable");
            if (icon == 0) icon = android.R.drawable.ic_lock_idle_alarm;

            Intent open = new Intent(c, MainActivity.class)
                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(c, 4712, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL)
                    .setSmallIcon(icon)
                    .setColor(accent)
                    .setContentTitle("الصلاة القادمة: " + arName(prayer))
                    .setContentText("الموعد " + clock(best))
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setSilent(true)
                    .setLocalOnly(true)
                    .setShowWhen(false)
                    .setCategory(NotificationCompat.CATEGORY_STATUS)
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setContentIntent(pi);

            int lSmall = rid(c, "notif_next_collapsed", "layout"), lBig = rid(c, "notif_next_expanded", "layout");
            if (lSmall != 0 && lBig != 0) {
                float d = c.getResources().getDisplayMetrics().density;
                int w = Math.min(c.getResources().getDisplayMetrics().widthPixels, 1100);

                RemoteViews small = new RemoteViews(c.getPackageName(), lSmall);
                fillHeader(c, small, prayer, best, now, accent, w, (int) (44 * d), 14 * d, (int) (32 * d), false);

                RemoteViews big = new RemoteViews(c.getPackageName(), lBig);
                fillHeader(c, big, prayer, best, now, accent, w, (int) (128 * d), 18 * d, (int) (36 * d), true);

                // صفّ مواقيت اليوم (أو الغد إن كانت الصلاة القادمة بعد العشاء)
                int day = dayKey(best);
                int pill = rid(c, "notif_pill", "drawable");
                for (String k : ORDER) {
                    long at = 0;
                    for (int i = 0; i < list.length(); i++) {
                        JSONObject o = list.optJSONObject(i);
                        if (o != null && k.equals(o.optString("prayer")) && dayKey(o.optLong("at")) == day) { at = o.optLong("at"); break; }
                    }
                    String low = k.toLowerCase();
                    boolean isNext = k.equals(prayer);
                    boolean past = at != 0 && at <= now;
                    int cell = rid(c, "c_" + low, "id"), nm = rid(c, "n_" + low, "id"), tm = rid(c, "t_" + low, "id");
                    big.setTextViewText(nm, arName(k));
                    big.setTextViewText(tm, at == 0 ? "—" : clock(at));
                    big.setInt(cell, "setBackgroundResource", isNext ? pill : 0);
                    big.setTextColor(nm, past ? 0x66FFFFFF : (isNext ? 0xFFFFFFFF : 0xB3FFFFFF));
                    big.setTextColor(tm, past ? 0x66FFFFFF : 0xFFFFFFFF);
                }
                b.setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                        .setCustomContentView(small)
                        .setCustomBigContentView(big);
            } else {
                // احتياطي بلا تصميم مخصّص: عدّاد النظام العادي
                b.setContentText("الموعد " + clock(best) + " · متبقٍّ")
                        .setShowWhen(true).setWhen(best).setUsesChronometer(true).setChronometerCountDown(true);
            }

            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, b.build());
        } catch (Exception ignored) {}
    }

    private PrayerCountdown() {}
}
