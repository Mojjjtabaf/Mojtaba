package __PKG__;

import android.app.Activity;
import android.app.NotificationManager;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.provider.OpenableColumns;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.annotation.ActivityCallback;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** جسر JS ⇄ أندرويد: window.Capacitor.registerPlugin('AdhanNative') */
@CapacitorPlugin(name = "AdhanNative")
public class AdhanPlugin extends Plugin {

    @Override
    public void load() {
        AdhanService.listener = (isPlaying, prayer) -> {
            JSObject o = new JSObject();
            o.put("playing", isPlaying);
            o.put("prayer", prayer);
            notifyListeners("adhanState", o);
        };
    }

    @PluginMethod
    public void schedule(PluginCall call) {
        JSArray arr = call.getArray("alarms");
        if (arr == null) { call.reject("alarms مطلوبة"); return; }
        int n = AdhanScheduler.scheduleAll(getContext(), arr);
        JSObject r = new JSObject();
        r.put("count", n);
        r.put("exact", AdhanScheduler.canExact(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void cancelAll(PluginCall call) {
        AdhanScheduler.cancelAll(getContext());
        AdhanStore.save(getContext(), new org.json.JSONArray());
        PrayerCountdown.update(getContext());
        call.resolve();
    }

    @PluginMethod
    public void status(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();
        r.put("playing", AdhanService.playing);
        r.put("prayer", AdhanService.current);
        r.put("exact", AdhanScheduler.canExact(c));
        boolean fs = true;
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            fs = nm != null && nm.canUseFullScreenIntent();
        }
        r.put("fullScreen", fs);
        r.put("countdown", PrayerCountdown.enabled(c));
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        r.put("ignoringBattery", pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName()));
        call.resolve(r);
    }

    @PluginMethod
    public void setCountdown(PluginCall call) {
        PrayerCountdown.setEnabled(getContext(), call.getBoolean("enabled", true));
        call.resolve();
    }

    @PluginMethod
    public void requestExactAlarm(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 31) open(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, true);
        call.resolve();
    }

    @PluginMethod
    public void requestFullScreen(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 34) open(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, true);
        call.resolve();
    }

    @PluginMethod
    public void openBatterySettings(PluginCall call) {
        open(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, false);
        call.resolve();
    }

    /* ===== أذان مخصص من ملفات الجهاز ===== */
    private static final long MAX_SOUND = 20L * 1024 * 1024;

    private File soundsDir() {
        File d = new File(getContext().getFilesDir(), "adhan");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** يفتح منتقي الملفات الصوتي في النظام. */
    @PluginMethod
    public void pickSound(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        startActivityForResult(call, i, "pickSoundResult");
    }

    @ActivityCallback
    private void pickSoundResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("cancelled");
            return;
        }
        Uri uri = result.getData().getData();
        File out = null;
        try {
            String display = "أذان";
            long size = -1;
            try (Cursor q = getContext().getContentResolver().query(uri, null, null, null, null)) {
                if (q != null && q.moveToFirst()) {
                    int n = q.getColumnIndex(OpenableColumns.DISPLAY_NAME), z = q.getColumnIndex(OpenableColumns.SIZE);
                    if (n >= 0 && !q.isNull(n)) display = q.getString(n);
                    if (z >= 0 && !q.isNull(z)) size = q.getLong(z);
                }
            }
            if (size > MAX_SOUND) { call.reject("حجم الملف أكبر من 20 ميغابايت"); return; }
            String ext = "mp3";
            int dot = display.lastIndexOf('.');
            if (dot >= 0) {
                String e = display.substring(dot + 1).toLowerCase(Locale.ROOT);
                if (e.matches("mp3|ogg|wav|m4a|aac|opus")) ext = e;
            }
            out = new File(soundsDir(), "custom_" + System.currentTimeMillis() + "." + ext);
            long total = 0;
            try (InputStream in = getContext().getContentResolver().openInputStream(uri);
                 FileOutputStream os = new FileOutputStream(out)) {
                if (in == null) throw new Exception("تعذّرت قراءة الملف");
                byte[] buf = new byte[32 * 1024];
                int r;
                while ((r = in.read(buf)) > 0) {
                    total += r;
                    if (total > MAX_SOUND) throw new Exception("حجم الملف أكبر من 20 ميغابايت");
                    os.write(buf, 0, r);
                }
            }
            // التحقق أن الملف صوتي صالح ومعرفة مدته
            long dur = 0;
            MediaMetadataRetriever mr = new MediaMetadataRetriever();
            try {
                mr.setDataSource(out.getAbsolutePath());
                String d = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                if (d != null) dur = Long.parseLong(d);
            } finally { try { mr.release(); } catch (Exception ignored) {} }
            if (dur <= 0) throw new Exception("الملف ليس صوتاً صالحاً");

            String base = dot > 0 ? display.substring(0, dot) : display;
            JSObject o = new JSObject();
            o.put("file", out.getName());
            o.put("path", out.getAbsolutePath());
            o.put("name", base);
            o.put("duration", dur);
            o.put("size", total);
            call.resolve(o);
        } catch (Exception e) {
            if (out != null) out.delete();
            call.reject(e.getMessage() == null ? "تعذّرت إضافة الملف" : e.getMessage());
        }
    }

    @PluginMethod
    public void deleteSound(PluginCall call) {
        String f = call.getString("file", "");
        if (f != null && f.matches("custom_[0-9]+\\.[a-z0-9]+")) new File(soundsDir(), f).delete();
        call.resolve();
    }

    @PluginMethod
    public void test(PluginCall call) {
        Intent s = new Intent(getContext(), AdhanService.class).setAction(AdhanService.ACTION_PLAY)
                .putExtra("prayer", call.getString("prayer", "Dhuhr"))
                .putExtra("title", call.getString("title", "حان الآن موعد أذان الظهر"))
                .putExtra("body", call.getString("body", "حيّ على الصلاة"))
                .putExtra("sound", call.getString("sound", "adhan_makkah.mp3"))
                .putExtra("color", call.getString("color", "#0d9488"));
        ContextCompat.startForegroundService(getContext(), s);
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getContext().startService(new Intent(getContext(), AdhanService.class).setAction(AdhanService.ACTION_STOP));
        call.resolve();
    }

    /** يُستدعى عند الإقلاع البارد من إشعار الأذان/fullScreenIntent. */
    @PluginMethod
    public void getLaunch(PluginCall call) {
        JSObject r = new JSObject();
        if (getActivity() != null) {
            Intent i = getActivity().getIntent();
            if (i != null && i.hasExtra("adhan_prayer")) {
                r.put("prayer", i.getStringExtra("adhan_prayer"));
                r.put("playing", i.getBooleanExtra("adhan_playing", false) && AdhanService.playing);
                i.removeExtra("adhan_prayer");
                i.removeExtra("adhan_playing");
            }
        }
        call.resolve(r);
    }

    /** يُستدعى عندما يكون التطبيق مفتوحاً (singleTask) ويصله Intent جديد. */
    @Override
    protected void handleOnNewIntent(Intent i) {
        super.handleOnNewIntent(i);
        if (i != null && i.hasExtra("adhan_prayer")) {
            JSObject o = new JSObject();
            o.put("prayer", i.getStringExtra("adhan_prayer"));
            o.put("playing", i.getBooleanExtra("adhan_playing", false) && AdhanService.playing);
            i.removeExtra("adhan_prayer");
            i.removeExtra("adhan_playing");
            notifyListeners("adhanLaunch", o, true);
        }
    }

    private void open(String action, boolean withPackage) {
        try {
            Intent i = new Intent(action);
            if (withPackage) i.setData(Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception ignored) {}
    }
}
