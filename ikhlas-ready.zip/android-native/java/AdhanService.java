package __PKG__;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;
import java.util.Locale;

/**
 * خدمة الأذان: تعمل في المقدّمة (mediaPlayback) فتشغّل الأذان كاملاً،
 * وتعرض إشعاراً بـ fullScreenIntent يفتح شاشة الأذان فوق قفل الشاشة.
 */
public class AdhanService extends Service {
    static final String ACTION_PLAY = "__PKG__.ADHAN_PLAY";
    static final String ACTION_STOP = "__PKG__.ADHAN_STOP";
    static final String CHANNEL = "adhan_fullscreen_v1";
    static final int NOTIF_ID = 4711;

    interface StateListener { void onState(boolean playing, String prayer); }

    static volatile boolean playing = false;
    static volatile String current = null;
    static volatile StateListener listener = null;

    private MediaPlayer mp;
    private AudioManager audio;
    private AudioFocusRequest focusReq;
    private boolean sunrise = false;

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "الأذان", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("تشغيل الأذان وعرض شاشة الأذان عند دخول الوقت");
        ch.setSound(null, null); // الصوت تشغّله الخدمة نفسها
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 300, 150, 300});
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    static Notification build(Context c, String prayer, String title, String body, String color, boolean full) {
        Intent open = new Intent(c, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("adhan_prayer", prayer)
                .putExtra("adhan_playing", full);
        int rc = 100 + (prayer == null ? 0 : Math.abs(prayer.hashCode() % 800));
        PendingIntent pi = PendingIntent.getActivity(c, rc, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        int icon = c.getResources().getIdentifier("ic_stat_icon", "drawable", c.getPackageName());
        if (icon == 0) icon = android.R.drawable.ic_lock_idle_alarm;
        int col;
        try { col = Color.parseColor(color); } catch (Exception e) { col = 0xFF0D9488; }

        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL)
                .setSmallIcon(icon)
                .setColor(col)
                .setContentTitle(title == null || title.isEmpty() ? "حان موعد الأذان" : title)
                .setContentText(body)
                .setCategory(full ? NotificationCompat.CATEGORY_ALARM : NotificationCompat.CATEGORY_REMINDER)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(full)
                .setAutoCancel(!full)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi);
        applyGlass(c, b, prayer, body, col, full);
        if (full) {
            b.setFullScreenIntent(pi, true);
            Intent stop = new Intent(c, AdhanService.class).setAction(ACTION_STOP);
            PendingIntent sp = PendingIntent.getService(c, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            b.addAction(0, "إيقاف الأذان", sp);
        }
        return b.build();
    }

    /** يكسو إشعار الأذان بالتصميم الزجاجي (نفس لغة إشعار العدّ التنازلي). إن غابت ملفات التصميم يبقى الإشعار العادي. */
    private static void applyGlass(Context c, NotificationCompat.Builder b, String prayer, String body, int accent, boolean full) {
        try {
            int ls = c.getResources().getIdentifier("notif_adhan_small", "layout", c.getPackageName());
            int lb = c.getResources().getIdentifier("notif_adhan_big", "layout", c.getPackageName());
            if (ls == 0 || lb == 0) return;
            float d = c.getResources().getDisplayMetrics().density;
            int w = Math.min(c.getResources().getDisplayMetrics().widthPixels, 1100);
            boolean sun = "Sunrise".equals(prayer);
            String kicker = sun ? "طلعت الشمس" : "حان الآن موعد أذان";
            String name = PrayerCountdown.arName(prayer);
            String line = (body == null || body.isEmpty()) ? (sun ? "فاذكر الله" : "حيّ على الصلاة") : body;

            RemoteViews small = new RemoteViews(c.getPackageName(), ls);
            fill(c, small, name, kicker, null, prayer, accent, w, (int) (44 * d), 14 * d, (int) (32 * d));
            RemoteViews big = new RemoteViews(c.getPackageName(), lb);
            fill(c, big, name, kicker, line, prayer, accent, w, (int) (84 * d), 18 * d, (int) (40 * d));

            b.setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                    .setCustomContentView(small)
                    .setCustomBigContentView(big)
                    .setCustomHeadsUpContentView(big);
        } catch (Exception ignored) {}
    }

    private static void fill(Context c, RemoteViews rv, String name, String kicker, String line, String prayer,
                             int accent, int w, int h, float r, int badge) {
        String pkg = c.getPackageName();
        rv.setImageViewBitmap(c.getResources().getIdentifier("g_bg", "id", pkg), GlassArt.card(w, h, r, accent));
        rv.setImageViewBitmap(c.getResources().getIdentifier("g_badge", "id", pkg), GlassArt.badge(badge, accent, prayer));
        rv.setTextViewText(c.getResources().getIdentifier("g_name", "id", pkg), name);
        rv.setTextViewText(c.getResources().getIdentifier("g_kicker", "id", pkg), kicker);
        if (line != null) rv.setTextViewText(c.getResources().getIdentifier("g_body", "id", pkg), line);
    }

    static void postFallback(Context c, Intent i) {
        try {
            ensureChannel(c);
            boolean sun = "Sunrise".equals(i.getStringExtra("prayer"));
            Notification n = build(c, i.getStringExtra("prayer"), i.getStringExtra("title"), i.getStringExtra("body"), i.getStringExtra("color"), !sun);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, n);
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            finish(false, true);
            return START_NOT_STICKY;
        }
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }

        String prayer = intent.getStringExtra("prayer");
        sunrise = "Sunrise".equals(prayer);
        ensureChannel(this);
        Notification n = build(this, prayer, intent.getStringExtra("title"), intent.getStringExtra("body"), intent.getStringExtra("color"), !sunrise);
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(NOTIF_ID, n);
        } catch (Exception e) {
            postFallback(this, intent);
            stopSelf();
            return START_NOT_STICKY;
        }
        current = prayer;
        play(intent.getStringExtra("sound"));
        return START_NOT_STICKY;
    }

    private MediaPlayer newPlayer(boolean sun) {
        MediaPlayer p = new MediaPlayer();
        p.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(sun ? AudioAttributes.USAGE_NOTIFICATION : AudioAttributes.USAGE_ALARM)
                .setContentType(sun ? AudioAttributes.CONTENT_TYPE_SONIFICATION : AudioAttributes.CONTENT_TYPE_MUSIC)
                .build());
        p.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
        return p;
    }

    private void play(String sound) {
        releasePlayer();
        final boolean sun = sunrise;
        mp = newPlayer(sun);

        boolean ok = false;
        // أذان مخصص اختاره المستخدم من ملفاته (محفوظ في files/adhan)
        if (!sun && sound != null && sound.startsWith("custom:")) {
            String fn = sound.substring(7);
            if (fn.matches("custom_[0-9]+\\.[a-z0-9]+")) {
                java.io.File f = new java.io.File(new java.io.File(getFilesDir(), "adhan"), fn);
                if (f.isFile() && f.length() > 0) {
                    try { mp.setDataSource(f.getAbsolutePath()); ok = true; }
                    catch (Exception e) { try { mp.release(); } catch (Exception ignored) {} mp = newPlayer(sun); }
                }
            }
        }
        if (!ok && !sun && sound != null && !sound.isEmpty() && !sound.startsWith("custom:")) {
            String base = sound.replaceAll("(?i)\\.(mp3|ogg|wav)$", "").toLowerCase(Locale.ROOT);
            int res = getResources().getIdentifier(base, "raw", getPackageName());
            if (res != 0) {
                try (AssetFileDescriptor afd = getResources().openRawResourceFd(res)) {
                    mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                    ok = true;
                } catch (Exception ignored) {}
            }
        }
        if (!ok) {
            try {
                mp.setDataSource(this, RingtoneManager.getDefaultUri(sun ? RingtoneManager.TYPE_NOTIFICATION : RingtoneManager.TYPE_ALARM));
                ok = true;
            } catch (Exception ignored) {}
        }
        if (!ok) { finish(sun, false); return; }

        mp.setOnPreparedListener(m -> {
            requestFocus(sun);
            m.start();
            setPlaying(true);
        });
        mp.setOnCompletionListener(m -> finish(sun, false));
        mp.setOnErrorListener((m, w, e) -> { finish(sun, false); return true; });
        try { mp.prepareAsync(); } catch (Exception e) { finish(sun, false); }
    }

    private void requestFocus(boolean sun) {
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audio == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(sun ? AudioAttributes.USAGE_NOTIFICATION : AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setOnAudioFocusChangeListener(f -> {}).build();
            audio.requestAudioFocus(focusReq);
        } else {
            audio.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
        }
    }

    private void abandonFocus() {
        if (audio == null) return;
        if (Build.VERSION.SDK_INT >= 26) { if (focusReq != null) audio.abandonAudioFocusRequest(focusReq); }
        else audio.abandonAudioFocus(null);
        focusReq = null;
    }

    private void setPlaying(boolean on) {
        playing = on;
        StateListener l = listener;
        if (l != null) { try { l.onState(on, current); } catch (Exception ignored) {} }
    }

    private void releasePlayer() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) {}
            try { mp.release(); } catch (Exception ignored) {}
            mp = null;
        }
    }

    /** إنهاء التشغيل. الشروق يُبقي الإشعار، والأذان يزيله. */
    private void finish(boolean keepNotification, boolean userStopped) {
        releasePlayer();
        abandonFocus();
        boolean wasPlaying = playing;
        playing = false;
        if (wasPlaying || userStopped) {
            StateListener l = listener;
            if (l != null) { try { l.onState(false, current); } catch (Exception ignored) {} }
        }
        if (Build.VERSION.SDK_INT >= 24)
            stopForeground(keepNotification ? Service.STOP_FOREGROUND_DETACH : Service.STOP_FOREGROUND_REMOVE);
        else stopForeground(!keepNotification);
        current = null;
        stopSelf();
    }

    @Override public void onDestroy() { releasePlayer(); abandonFocus(); playing = false; super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
