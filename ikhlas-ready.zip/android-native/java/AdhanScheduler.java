package __PKG__;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

/** جدولة منبّهات الأذان الدقيقة عبر AlarmManager (تعمل والتطبيق مغلق وفي وضع Doze). */
final class AdhanScheduler {
    static final String ACTION = "__PKG__.ADHAN_ALARM";

    static boolean canExact(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    private static PendingIntent alarmIntent(Context c, int id, JSONObject o, boolean create) {
        Intent i = new Intent(c, AdhanReceiver.class).setAction(ACTION).setData(Uri.parse("ikhlas://adhan/" + id));
        if (o != null) {
            i.putExtra("prayer", o.optString("prayer"));
            i.putExtra("title", o.optString("title"));
            i.putExtra("body", o.optString("body"));
            i.putExtra("sound", o.optString("sound"));
            i.putExtra("color", o.optString("color"));
        }
        int flags = PendingIntent.FLAG_IMMUTABLE | (create ? PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_NO_CREATE);
        return PendingIntent.getBroadcast(c, id, i, flags);
    }

    static void cancelAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        JSONArray old = AdhanStore.load(c);
        for (int n = 0; n < old.length(); n++) {
            JSONObject o = old.optJSONObject(n);
            if (o == null) continue;
            PendingIntent pi = alarmIntent(c, o.optInt("id"), null, false);
            if (pi != null) { am.cancel(pi); pi.cancel(); }
        }
    }

    static int scheduleAll(Context c, JSONArray list) {
        cancelAll(c);
        AdhanStore.save(c, list);
        int n = arm(c, list);
        PrayerCountdown.update(c);
        return n;
    }

    static int rescheduleFromStore(Context c) {
        int n = arm(c, AdhanStore.load(c));
        PrayerCountdown.update(c);
        return n;
    }

    private static int arm(Context c, JSONArray list) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return 0;
        long now = System.currentTimeMillis();
        int count = 0;
        for (int n = 0; n < list.length(); n++) {
            JSONObject o = list.optJSONObject(n);
            if (o == null) continue;
            long at = o.optLong("at");
            if (at <= now) continue;
            int id = o.optInt("id");
            PendingIntent op = alarmIntent(c, id, o, true);
            try {
                // setAlarmClock: الأدقّ والأوثق، ومستثناة من قيود Doze، ولا تحتاج صلاحية SCHEDULE_EXACT_ALARM
                Intent show = new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                PendingIntent sp = PendingIntent.getActivity(c, 7000 + id, show, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, sp), op);
                count++;
            } catch (SecurityException e) {
                try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op); count++; } catch (Exception ignored) {}
            }
        }
        return count;
    }

    private AdhanScheduler() {}
}
