package __PKG__;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;

public class AdhanReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            AdhanScheduler.rescheduleFromStore(c);
            return;
        }
        if (AdhanScheduler.ACTION.equals(a)) {
            PrayerCountdown.update(c); // ينتقل العدّاد مباشرة إلى الصلاة التي تليها
            Intent s = new Intent(c, AdhanService.class).setAction(AdhanService.ACTION_PLAY).putExtras(i);
            try {
                ContextCompat.startForegroundService(c, s);
            } catch (Exception e) {
                // منع النظام بدء الخدمة: نكتفي بإشعار عالي الأولوية بشاشة كاملة
                AdhanService.postFallback(c, i);
            }
        }
    }
}
