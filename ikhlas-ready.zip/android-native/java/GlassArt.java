package __PKG__;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

/** يرسم خلفية «الزجاج» وشارة الصلاة برمجياً (الإشعارات لا تدعم blur حقيقياً، فنحاكيه بطبقات شفافة ولمعان وحدّ ناعم). */
final class GlassArt {
    static int alpha(int c, int a) { return Color.argb(a, Color.red(c), Color.green(c), Color.blue(c)); }

    static int mix(int a, int b, float t) {
        return Color.rgb((int) (Color.red(a) * (1 - t) + Color.red(b) * t),
                (int) (Color.green(a) * (1 - t) + Color.green(b) * t),
                (int) (Color.blue(a) * (1 - t) + Color.blue(b) * t));
    }

    /** بطاقة زجاجية بلون الصلاة. */
    static Bitmap card(int w, int h, float r, int accent) {
        Bitmap bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        RectF rf = new RectF(0, 0, w, h);
        int base = 0xFF071A1F;
        // 1) جسم داكن مصبوغ بلون الصلاة
        p.setShader(new LinearGradient(0, 0, w, h, alpha(mix(base, accent, .42f), 242), alpha(mix(base, accent, .10f), 242), Shader.TileMode.CLAMP));
        cv.drawRoundRect(rf, r, r, p);
        // 2) وهج ضوئي من الزاوية العليا
        p.setShader(new RadialGradient(w * .90f, h * .02f, Math.max(w, h) * .62f, alpha(accent, 130), alpha(accent, 0), Shader.TileMode.CLAMP));
        cv.drawRoundRect(rf, r, r, p);
        // 3) وهج خافت من الأسفل مقابل الأول
        p.setShader(new RadialGradient(w * .08f, h * 1.05f, Math.max(w, h) * .5f, alpha(mix(accent, Color.WHITE, .3f), 60), alpha(accent, 0), Shader.TileMode.CLAMP));
        cv.drawRoundRect(rf, r, r, p);
        // 4) لمعان الزجاج في النصف العلوي
        p.setShader(new LinearGradient(0, 0, 0, h * .6f, alpha(Color.WHITE, 62), alpha(Color.WHITE, 0), Shader.TileMode.CLAMP));
        cv.drawRoundRect(rf, r, r, p);
        // 5) حدّ زجاجي: أسطع من الأعلى
        float sw = Math.max(2f, h * 0.014f);
        p.setShader(new LinearGradient(0, 0, 0, h, alpha(Color.WHITE, 140), alpha(Color.WHITE, 30), Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(sw);
        cv.drawRoundRect(new RectF(sw / 2, sw / 2, w - sw / 2, h - sw / 2), r, r, p);
        return bm;
    }

    /** شارة دائرية بأيقونة الصلاة: شمس للظهر والعصر، أفق للفجر والشروق والمغرب، هلال للعشاء. */
    static Bitmap badge(int s, int accent, String prayer) {
        Bitmap bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float c = s / 2f;
        p.setShader(new LinearGradient(0, 0, s, s, mix(accent, Color.WHITE, .25f), mix(accent, 0xFF000000, .35f), Shader.TileMode.CLAMP));
        cv.drawCircle(c, c, c - s * .02f, p);
        p.setShader(new LinearGradient(0, 0, 0, s, alpha(Color.WHITE, 150), alpha(Color.WHITE, 20), Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s * .035f);
        cv.drawCircle(c, c, c - s * .03f, p);

        p.setShader(null);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.FILL);
        p.setStrokeCap(Paint.Cap.ROUND);
        String k = prayer == null ? "" : prayer;
        if (k.equals("Isha")) {
            Path a = new Path(), b = new Path();
            a.addCircle(c, c, s * .22f, Path.Direction.CW);
            b.addCircle(c + s * .11f, c - s * .06f, s * .19f, Path.Direction.CW);
            a.op(b, Path.Op.DIFFERENCE);
            cv.drawPath(a, p);
        } else if (k.equals("Dhuhr") || k.equals("Asr")) {
            cv.drawCircle(c, c, s * .14f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s * .05f);
            for (int i = 0; i < 8; i++) {
                double an = Math.PI / 4 * i;
                cv.drawLine((float) (c + Math.cos(an) * s * .23f), (float) (c + Math.sin(an) * s * .23f),
                        (float) (c + Math.cos(an) * s * .31f), (float) (c + Math.sin(an) * s * .31f), p);
            }
        } else { // الفجر، الشروق، المغرب
            float y0 = c + s * .08f;
            cv.drawArc(new RectF(c - s * .17f, y0 - s * .17f, c + s * .17f, y0 + s * .17f), 180, 180, true, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s * .05f);
            cv.drawLine(c - s * .30f, y0 + s * .08f, c + s * .30f, y0 + s * .08f, p);
            for (int deg : new int[]{270, 225, 315}) {
                double an = Math.toRadians(deg);
                cv.drawLine((float) (c + Math.cos(an) * s * .25f), (float) (y0 + Math.sin(an) * s * .25f),
                        (float) (c + Math.cos(an) * s * .32f), (float) (y0 + Math.sin(an) * s * .32f), p);
            }
        }
        return bm;
    }

    private GlassArt() {}
}
