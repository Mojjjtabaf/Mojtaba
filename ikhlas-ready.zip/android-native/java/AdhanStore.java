package __PKG__;

import android.content.Context;
import org.json.JSONArray;

/** يحفظ قائمة المنبّهات لإعادة جدولتها بعد إعادة تشغيل الجهاز أو تحديث التطبيق. */
final class AdhanStore {
    private static final String PREFS = "ikhlas_adhan";
    private static final String KEY = "alarms";

    static void save(Context c, JSONArray a) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply();
    }

    static JSONArray load(Context c) {
        try {
            return new JSONArray(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private AdhanStore() {}
}
