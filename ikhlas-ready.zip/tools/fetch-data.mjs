// شغّله مرة واحدة (Node 18+):  node tools/fetch-data.mjs
// ينزّل المصحف والتفسير الميسّر والأذان إلى مجلداتها، فيعمل التطبيق دون إنترنت
import {writeFile,mkdir} from 'node:fs/promises';
await mkdir('data',{recursive:true});await mkdir('audio/adhan',{recursive:true});await mkdir('android-res/raw',{recursive:true});
const get=async u=>{const r=await fetch(u);if(!r.ok)throw new Error(u+' '+r.status);return r;};
for(const [ed,out] of [['quran-uthmani','data/quran.json'],['ar.muyassar','data/muyassar.json']]){
  const j=await (await get('https://api.alquran.cloud/v1/quran/'+ed)).json();
  await writeFile(out,JSON.stringify(j.data.surahs));console.log(out,j.data.surahs.length,'surahs');
}
const A={makkah:'makkah',madinah:'madinah',alaqsa:'alaqsa',alafasy:'mishary_alafasy',abdulbasit:'abdulbasit'};
for(const [id,f] of Object.entries(A)){
  try{const b=Buffer.from(await (await get(`https://download.quranicaudio.com/adhan/${f}.mp3`)).arrayBuffer());
    await writeFile(`audio/adhan/${id}.mp3`,b);await writeFile(`android-res/raw/adhan_${id}.mp3`,b);console.log('adhan',id);}
  catch(e){console.log('skip',id,e.message);}
}
